%This code will caculate the power spectrum function
clear all
DATA2 = load('DATA02LN.txt');
DATA3 = load('DATA03LN.txt');
DATA4 = load('DATA04LN.txt');
DATA5 = load('DATA05LN.txt');
DATA6 = load('DATA06LN.txt');
DATA7 = load('DATA07LN.txt');
DATA8 = load('DATA08LN.txt');
DATA9 = load('DATA09LN.txt');
DATA10 = load('DATA10LN.txt');
% DATA6 = load('DATA6.txt');
% DATA7 = load('DATA7.txt');
% DATA8 = load('DATA8.txt');
% DATA9 = load('DATA9.txt');
% DATA10 = load('DATA10.txt');
% DATA11 = load('DATA11.txt');
% DATA12 = load('DATA12.txt');
% DATA13 = load('DATA13.txt');
% DATA14 = load('DATA14.txt');
% DATA15 = load('DATA15.txt');
% DATA16 = load('DATA16.txt');
% DATA17 = load('DATA17.txt');
% f1 = DATA1(1,:);
% AMP1 = DATA1(2,:);
f2 = DATA2(1,:);
AMP2 = DATA2(2,:);
f3 = DATA3(1,:);
AMP3 = DATA3(2,:);
f4 = DATA4(1,:);
AMP4 = DATA4(2,:);
f5 = DATA5(1,:);
AMP5 = DATA5(2,:);
f6 = DATA6(1,:);
AMP6 = DATA6(2,:);
f7 = DATA7(1,:);
AMP7 = DATA7(2,:);
f8 = DATA8(1,:);
AMP8 = DATA8(2,:);
f9 = DATA9(1,:);
AMP9 = DATA9(2,:);
f10 = DATA10(1,:);
AMP10 = DATA10(2,:);
% f11 = DATA11(1,:);
% AMP11 = DATA11(2,:);
% f12 = DATA12(1,:);
% AMP12 = DATA12(2,:);
% f13 = DATA13(1,:);
% AMP13 = DATA13(2,:);
% f14 = DATA14(1,:);
% AMP14 = DATA14(2,:);
% f15 = DATA15(1,:);
% AMP15 = DATA15(2,:);
% f16 = DATA16(1,:);
% AMP16 = DATA16(2,:);
% f17 = DATA17(1,:);
% AMP17 = DATA17(2,:);
Nx = length(f2);
figure(1)
plot(f2(1:Nx/2),AMP2(1:Nx/2));
hold on
plot(f4(1:Nx/2),AMP4(1:Nx/2));
hold on
plot(f6(1:Nx/2),AMP6(1:Nx/2));
hold on
plot(f7(1:Nx/2),AMP7(1:Nx/2));
hold on
plot(f10(1:Nx/2),AMP10(1:Nx/2));
% hold on
% plot(f15(1:Nx/2),AMP15(1:Nx/2));
% hold on
% plot(f17(1:Nx/2),AMP17(1:Nx/2));
ylabel('Amplititude')
xlabel('Wavenumber (1/m)')
legend('0.04MPa','0.069MPa','0.12MPa','0.40MPa','0.74MPa')
%%
%Do extract log value
FF2 = f2(1:Nx/2);
AMFF2 = AMP2(1:Nx/2);
FF4 = f4(1:Nx/2);
AMFF4 = AMP4(1:Nx/2);
FF6 = f6(1:Nx/2);
AMFF6 = AMP6(1:Nx/2);
FF7 = f7(1:Nx/2);
AMFF7 = AMP7(1:Nx/2);
FF10 = f10(1:Nx/2);
AMFF10 = AMP10(1:Nx/2);
%%
%Calculate the log value
FF2ln = log10(FF2(2:end));
AMFF2ln = log10(AMFF2(2:end));
FF4ln = log10(FF4(2:end));
AMFF4ln = log10(AMFF4(2:end));
FF6ln = log10(FF6(2:end));
AMFF6ln = log10(AMFF6(2:end));
FF7ln = log10(FF7(2:end));
AMFF7ln = log10(AMFF7(2:end));
FF10ln = log10(FF10(2:end));
AMFF10ln = log10(AMFF10(2:end));
%%
%Do linear fitting
p2 = polyfit(FF2ln,AMFF2ln,1);%The coefficient of the fitting
AMFF2lnN = polyval(p2,FF2ln);  %The fitting value
p4 = polyfit(FF4ln,AMFF4ln,1);%The coefficient of the fitting
AMFF4lnN = polyval(p4,FF4ln);  %The fitting value
p6 = polyfit(FF6ln,AMFF6ln,1);%The coefficient of the fitting
AMFF6lnN = polyval(p6,FF6ln);  %The fitting value
p7 = polyfit(FF7ln,AMFF7ln,1);%The coefficient of the fitting
AMFF7lnN = polyval(p7,FF7ln);  %The fitting value
p10 = polyfit(FF10ln,AMFF10ln,1);%The coefficient of the fitting
AMFF10lnN = polyval(p10,FF10ln);  %The fitting value
%%
%Plot figure
figure(2)
plot(FF2ln,AMFF2ln)
hold on
plot(FF4ln,AMFF4ln)
hold on
plot(FF6ln,AMFF6ln)
hold on
plot(FF7ln,AMFF7ln)
hold on
plot(FF10ln,AMFF10ln)
hold on
%%
plot(FF2ln,AMFF2lnN)
hold on
plot(FF4ln,AMFF4lnN)
hold on
plot(FF6ln,AMFF6lnN)
hold on
plot(FF7ln,AMFF7lnN)
hold on
plot(FF10ln,AMFF10lnN)
xlabel('Wavenumber (Log(m^-1))')
ylabel('Amp.(Log)')
legend('1.19MPa','2.41MPa','3.61MPa','4.71MPa','5.25MPa','1.19MPa fitting','2.41MPa fitting','3.61MPa fitting','4.71MPa fitting','5.25MPa fitting')