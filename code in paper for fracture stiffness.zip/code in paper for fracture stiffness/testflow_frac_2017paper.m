% Modified from Peter K. Kang's main_flow_transport_MC_final.m
% intended to do different realizations of fracture distributions
% by Joseph H.Y. Ma @ NUS, last updated: 16 August 2017

clear all; 
close all;

diary('run_testflow_frac_paper2017.txt')
tic;
%To record the simuluation diary
%%% Define Newtork Dimension and Heterogeniety

Nx = 128; Ny = 128;          % grid numbers 
Lx = 100; Ly = 100;          % domain lengths m

Seed = [1]';
clx_frac = [100 50 20]';%The autocorrelation length dimensionless value
Var_S = [0.01 0.04 0.08]';%The perturbation
%The apt can be approximated by H=exp(-Var_S.^(1/2))  (-ln(H)).^2=Var_S
dist = 4;                                     % 1: Whitte-A,  2: Guassian, 3: Exponential
Offset_ratio = [0 0.5 2.5 3.5]';    % no. of SD compression %The compression location dimensionless value

for L = 1:length(Seed)
    run_count = 0;
    seed = Seed(L);
    for I = 1:length(clx_frac)%We have confirm the autocorrelation length
    for J = 1:length(Var_S)%confirm the perturbation
       for K = 1:length(Offset_ratio)%Confirm the loction of compression
                Clx_frac = clx_frac(I)%The autocorrelation length
                CLx = Lx/Clx_frac; CLy = CLx;% autocorrelation length unit [m]
                var_S = Var_S(J)%The perturbation
                offset_ratio = Offset_ratio(K);
                run_count = run_count + 1;%The time for iteration
        
%%% Define Flow & Transport Simulation Parameters 

mu  = 1e-03;                    % dynamic viscosity of water [Pa.s]
rho = 1000;                    % density of water [kg/m^3]
g = 9.8;                    % gravitatinoal constant [m/s^2] In this simulation, I think this value is useless
P_L = 1e06;                    % pressure at the left boundary (Pa)
P_R = 0;                    % pressure at the right boundary
h = Lx/(Nx-1);              % size of each gridblock [m]
fluxweighted = 1;           % 1 ???
INJ_section = 0;            % where we inject - 0: line injection / i: ith section
nomixing = 0;               % 0: complete mixing, 1: no mixing This is Kang's code

% Generate Random Aperature from Permeability Field

[S2, sigma0, apt, str] = gen_aperture(dist, Nx, Ny, Lx, Ly, CLx, CLy, var_S, offset_ratio, seed);

apt_mean = mean(apt(:));%The mean aperture
apt_var = var(apt(:));%The variance of aperture

perm = (1/12)*apt.^2;%                   % By kapa = d^2/12 in parallel plates%permeability of each node m^2
perm_var = var(perm(:));%The variance of permeability

perm_nozero = perm;
perm_nozero(apt == 0) = NaN;            % neglet closed aperture in statistics
 
perm_geomean = geomean(perm(~isnan(perm_nozero))); % geometric mean of compressed permeability
logperm_var = nanvar(log(perm_nozero(:)));         % variance of log(compressed permeability)

if offset_ratio == 0
   apt0max = max(apt(:));
end

fig = figure('Visible','off');
imagesc(apt);
axis square; cob=colorbar; colormap('hot'); caxis([0 apt0max]);set(get(cob,'title'),'string','m');
title({'Aperature Field of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('Apt_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);

fig = figure('Visible','off'); 
imagesc(log10(perm./1e-09)); 
axis square; cobb=colorbar; colormap('hot');set(get(cobb,'title'),'string','Log[mD]');%unit mD 
title({'log(Permeability) Field of Fracture Surfaces with',[' Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Perm_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);

% SOLVE FOR ELECTRIC (assume normalized potential difference)
%%
%This part can be comment
% K_electric = zeros(Ny,Nx);          % bulk resistivity = inf
% rho = 0.2;                          % brine resistivity = 0.2 ohm.m
% K_electric(apt(:) > 0) = 1/rho;     % formation factor = 1;
% V_L = 1; V_R = 0;                   % boundary electric potential
% 
% [Epmat, fx, fy, Jx, Jy] = flow_solver(Lx, Nx, Ny, K_electric);  % solve for current density J = -1/(F.rho)*grad V%Maybe I can neglect this
% 
% Ix = Jx.*apt.*h;      
% Iy = Jy.*apt.*h;                       % By I = JA
% 
% Itot = abs(Ix)+abs(Iy);
% Iout = sum(Ix(:,end));                 % total outgoing current
% Iout_var = var(Ix(:,end));             % variance of current
% Rsst_apparent = (V_L-V_R)/Iout;        % Resistance of network
% ele_apt = rho*Iout/((V_L-V_R)*Ly/Lx);  % electric aperture, from Brown 1989
% rho_eff = Rsst_apparent/Lx;            % Effective Resistivity
% 
% fname_electric = sprintf('electric_solution_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
% save(fname_electric, 'K_electric', 'Epmat', 'Ix', 'Iy', 'Itot', 'Rsst_apparent', 'ele_apt');
% 
% fig = figure('Visible','off'); 
% imagesc(Itot);
% axis square;  colorbar; 
% title({'Electric Current in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Itot_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
% 
% fig = figure('Visible','off'); 
% imagesc(K_electric);
% axis square;  colorbar; 
% title({'Electric Conductivity in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Ek_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
% 
% fig = figure('Visible','off'); 
% imagesc(Epmat);
% axis square;  colorbar; 
% title({'Electric Potential in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Epmat_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
%%
% SOLVE FOR FLOW

eff_poro = 1.00*ones(Ny,Nx); % fracture The porosity of crack is 100%                

[pmat, fx, fy, qx, qy] = flow_solver(Lx, Nx, Ny, perm/mu);  % solve for Darcy velocity from q = -(k/mu)*grad P%In the flower_solver, K is the conductivity 
 
qtot = abs(qx)+abs(qy);                            % velocity magnitude [m/s]
Qout = sum(qx(:,end).*apt(:,end)*h);               % total out horizontal flux [m^3/s]
qout_var = var(qx(:,end));                         % variance of outgoing velocity
%Perm_apparent = mu*Qout/((P_L-P_R)/Lx);            % overall permeability of netwrok
hyd_apt = (12*mu*Qout/(Ly*(P_L-P_R)/Lx))^(1/3)    % hydraulic aperture, from Brown 1989 [m]
Perm_apparent = hyd_apt^2/12                      % overall netwrok permeability, inverse of Darcy [m^2]
%%  
fname_flow = sprintf('flow_solution_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed); 
save(fname_flow, 'perm', 'pmat', 'fx', 'fy', 'Qout','Perm_apparent','hyd_apt');

fig = figure('Visible','off'); 
imagesc(pmat); 
%This is pressure gradient
axis square; colorbar;
title({'Pressure Field in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Pmat_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);

%%% Generate Total Outgoing Fluxes and Residence Time at Each Node %%%

Qtot = (abs(fx(:,1:end-1))+abs(fx(:,2:end))+abs(fy(1:end-1,:))+abs(fy(2:end,:)))/2;%This is an mean value

residence_T = h^2*eff_poro./Qtot;%It is h^3/(Qtot.*h)unit s
residence_T(isnan(residence_T)) = 0;
residence_T(residence_T==inf) = 0;
Qtot_ud = flipud(Qtot);                           % flip if needed for consistency

fname_Qtot = sprintf('Qtot_residenceT_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
save(fname_Qtot, 'Qtot', 'eff_poro','residence_T');

fig = figure('Visible','off'); 
imagesc(residence_T); 
axis square;  colorbar; 
title({'Residence Time of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('resT_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);

fig = figure('Visible','off'); 
imagesc(Qtot); 
axis square;  colorbar; 
title({'Total Fluxes in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Qtot_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);

% SOLVE FOR TRANSPORT

try
   [node_xy, neighwithpositiveflux, PositiveFluxVector, link_Ttime, node_connectivity] = transport_param_gen(Nx, Ny, fname_flow, fname_Qtot);
   fname_TPparam = sprintf('transport_param_gen_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
   save(fname_TPparam, 'node_xy', 'Nx', 'Ny', 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime', 'node_connectivity');

   [TIME, NODEINDEX, BT_nodes] = Transport_cal(fluxweighted, INJ_section, nomixing, fname_TPparam, Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
   fname_TP = sprintf('Transport_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
   save(fname_TP, 'TIME', 'NODEINDEX', 'BT_nodes');

   [peak_time_modeling, q01, q05, q50, q80, q95, q99, tail_slope, Rsq] = transport_stat(fname_TP, Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed); 
   TPerror = 0;

catch exception
   disp(exception.getReport);
   TPerror = 1;
   q01 = NaN;
   q05 = NaN;
   q25 = NaN;
   q75 = NaN;
   q95 = NaN;
   q99 = NaN;
   tailslope = NaN;
   peak_time_modeling = NaN;
end

%%
%This is about electricity, I think can be annotated
% Current(run_count)      = Iout;
% Current_Var(run_count)  = Iout_var;
% OverallResist(run_count)= Rsst_apparent;
% ElectricApt(run_count)  = ele_apt;
% OverallRho(run_count)   = rho_eff;
%%
CorrLen_frac(run_count) = Clx_frac;
VarS2(run_count)        = var_S;
Offset(run_count)       = offset_ratio;
Sigma0(run_count)       = sigma0;
Apt_mean(run_count)     = apt_mean;
Apt_Var(run_count)      = apt_var;
Flux(run_count)         = Qout;
Outvel_Var(run_count)   = qout_var;
Perm_Var(run_count)     = perm_var;
OverallPerm(run_count)  = Perm_apparent;
HydraulicApt(run_count) = hyd_apt;
Q01(run_count)		= q01;
Q05(run_count)          = q05;
Q50(run_count)          = q50;
Q80(run_count)          = q80;
Q95(run_count)          = q95;
Q99(run_count)		= q99;
TailSlope(run_count)	= tail_slope;
PeakBTtime(run_count)	= peak_time_modeling;
TransportErr(run_count) = TPerror;           
        end
    end
    end


%%
%This is about electricity, I think can be annotate
% Current = Current';
% Current_Var = Current_Var';
% OverallResist = OverallResist';
% OverallRho = OverallRho';
% ElectricApt = ElectricApt';
%%
CorrLen_frac = CorrLen_frac';
VarS2 = VarS2';
Offset = Offset';
Sigma0 = Sigma0';
Apt_mean = Apt_mean';
Apt_Var = Apt_Var';
Perm_Var = Perm_Var';
OverallPerm = OverallPerm';
Flux = Flux';
Outvel_Var = Outvel_Var';
HydraulicApt = HydraulicApt';
Q01 = Q01';
Q05 = Q05';
Q50 = Q50';
Q80 = Q80';
Q95 = Q95';
Q99 = Q99';
TailSlope = TailSlope';
PeakBTtime = PeakBTtime';
TransportErr = TransportErr';

fname = sprintf('paper2017_seed%d.mat',seed);
%%
%In this part, there are something about electricity, I will neglected
% save(fname,'VarS2','CorrLen_frac','Offset','Sigma0','Apt_mean','Apt_Var','Current','Current_Var','OverallResist','OverallRho','ElectricApt','Flux','Outvel_Var','Perm_Var','OverallPerm','HydraulicApt','TransportErr','Q01','Q05','Q50','Q80','Q95','Q99','TailSlope','PeakBTtime','str','seed');
%%
save(fname,'VarS2','CorrLen_frac','Offset','Sigma0','Apt_mean','Apt_Var','Flux','Outvel_Var','Perm_Var','OverallPerm','HydraulicApt','TransportErr','Q01','Q05','Q50','Q80','Q95','Q99','TailSlope','PeakBTtime','str','seed');
end

diary off
toc;
