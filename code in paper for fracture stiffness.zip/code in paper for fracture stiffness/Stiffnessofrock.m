%%
clear
%Two group of data
%All the unit of the stiffness is GPa, and the unit of pressure is 
%%
I = sqrt(-1);
Kf =2.25;%bulk modulus of water
yita = 1e-03;%viscosity
a=100e-06;%the radius of the crack
%Quartz
KdQ = 37;%Bulk modulus
mudQ = 44;%Shear modulus
eQ = 0.01;%Crack density
asp = 0.01;
phic = 4/3.*pi.*asp.*eQ;
KdrQ = 26;%The bulk modulus of dry rock
mudrQ = 31;%The shear modulus of dry rock
PoQ = (3.*KdrQ-2.*mudrQ)./(2.*(3.*KdrQ+mudrQ));
kappa = 1e-19;%Permeability
phi = 0.1;%Porosity
arf =(KdQ-KdrQ)./KdQ;
%MQ1 = ((arf-phi)./KdQ+phi./Kf).^(-1);
MQ1 = KdQ/((1-KdrQ/KdQ)-phi*(1-KdQ/Kf));
%MQ = ((-KdrQ.*Kf+KdQ.*(Kf-Kf.*phi+KdQ.*phi))./(Kf.*KdQ.^2)).^(-1);
%MQ = Kf.*KdQ.^2./(-KdrQ.*Kf.*KdQ.*(Kf-phi.*Kf+KdQ.*phi)); 
MQ = ((arf-phi)./KdQ+phi./Kf).^(-1);
C1 = KdrQ+4/3.*mudrQ+arf.^2.*MQ1;
EXP = (-8:0.01:-1.5);
OMI = 10.^(EXP);
gQ = mudrQ./(KdrQ+4/3.*mudrQ);
CdrQ = KdrQ+4./3.*mudrQ;
KQBH = KdrQ+arf.^2.^MQ1;
CQBH = KQBH+4./3.*mudrQ;
CQ = KdQ+4./3.*mudQ;
k2 = sqrt((sqrt(-1).*OMI.*yita.*CQBH./kappa./MQ./CdrQ));
k2a = real((k2.*a));
HHB = CQBH.*ones(1,121);
rhoQ = 2.65/1000000;
rhof = 1.09/1000000;
rhoR = (1-phi).*rhoQ+phi.*rhof;
RAD001 = [0 pi/4 pi/2];
RAD010 = [0 pi/4 pi/2];
RAD020 = [0 pi/4 pi/2];
RAD050 = [0 pi/4 pi/2];
RAD100 = [0 pi/4 pi/2];
%%
%STADRD deviation = 0.09 um
STCRACK009 = [0.181121137	0.181556635	0.18365581	0.185423032	0.188367295	0.189305867	0.190811206	0.193116474];
STPRE009 = [0	19.44189556	37.8260614	52.44196255	66.50041514	77.41655582	85.31855224	93.05174318];
C22009 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK009+4.*mudQ.*eQ./STCRACK009);
CC22009 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK009))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK009);
ZCRACK009 = eQ./STCRACK009; 
ZCRACK009T = ZCRACK009./(1-PoQ./2);
C44009 = mudQ./(1+mudQ.*ZCRACK009T);%The shear modulus
deltaN009 = CdrQ.*ZCRACK009./(1+CdrQ.*ZCRACK009);
ZCRACK009S = ZCRACK009./(1+Kf.*deltaN009./(CQ.*phic.*(1-deltaN009)).*(1-Kf./KdQ).^(-1));
C11009H = (4.*mudrQ.*(1+mudrQ.*ZCRACK009S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK009S))./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C11001H = CQBH.*ones(1,8);
C1100901 = (4.*mudrQ.*(1+mudrQ.*ZCRACK009)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK009))./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C22009H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C22001H = CQBH.*ones(1,8);
C2200901 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C12009H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C12001H = (CQBH-2.*mudrQ).*ones(1,8);
C1200901 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C66009H = mudrQ./(1+mudrQ.*ZCRACK009T);
KX009 = KdrQ.*(3+4.*mudrQ.*ZCRACK009)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
MX009 = ((1-KX009./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1009 = 1-KX009./KdQ-(2.*mudrQ.*ZCRACK009)./(3+4.*mudrQ.*ZCRACK009).*KX009./KdQ;
a2009 = 1-KX009./KdQ+(6.*mudrQ.*ZCRACK009)./(3+4.*mudrQ.*ZCRACK009).*KX009./KdQ;
%C110010 = C1100101+a1001.^2.*MX001;
%C110010 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK001) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK001) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK001)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK001) + Kf .*(3 .*KdQ.^2.* ZCRACK001 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK001) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK001))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK001 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK001) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK001 + 3.* KdQ.* (-1 + phi).* ZCRACK001));
C110090 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK009)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK009 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK009) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK009 + 3.* KdQ.* (-1 + phi).* ZCRACK009))));
C220090 = C2200901+a2009.^2.*MX009;
C120090 = C1200901+a1009.*a2009.*MX009;
C660090 = mudrQ./(1+mudrQ.*ZCRACK009T);
%%
MPX00902H = ((C11009H-C66009H).*sin(RAD001(2)).^2-(C22009H-C66009H).*cos(RAD001(2)).^2).^2+(C12009H+C66009H).^2.*sin(2.*RAD001(2));
MPX009020 = ((C110090-C660090).*sin(RAD001(2)).^2-(C220090-C660090).*cos(RAD001(2)).^2).^2+(C120090+C660090).^2.*sin(2.*RAD001(2));
C45009H = (C11009H.*sin(RAD001(2)).^2+C22009H.*cos(RAD001(2)).^2+C66009H+sqrt(MPX00902H));
C450090 = (C110090.*sin(RAD001(2)).^2+C220090.*cos(RAD001(2)).^2+C660090+sqrt(MPX009020));
C45009SH = (C11009H.*sin(RAD001(2)).^2+C22009H.*cos(RAD001(2)).^2+C66009H-sqrt(MPX00902H));
C45009S0 = (C110090.*sin(RAD001(2)).^2+C220090.*cos(RAD001(2)).^2+C660090-sqrt(MPX009020));
%%
G009 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T009 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita009L = (C22009H(1)-C220090(1)).^3./(2.*C22009H(1).*C220090(1).^2.*T009.*G009.^2);
tao009L = ((C22009H(1)-C220090(1))./C220090(1)./G009).^2;
fw0019L = (1-cita009L+cita009L.*sqrt(1-sqrt(-1).*OMI.*tao009L./cita009L.^2));
%%
%C11
%CCZ11001L = 1./C11001H(1).*(1+((C11001H(1)-C110010(1))./C110010(1))./fw001L);
CCC11009L = C11009H(1)./(1+((C11009H(1)-C110090(1))./C110090(1))./fw0019L);
Q1C11009L = abs(imag(CCC11009L)./real(CCC11009L));
%%
%C22
%CCZ22001L = 1./C22001H(1).*(1+((C22001H(1)-C220010(1))./C220010(1))./fw001L);
CCC22009L = C22009H(1)./(1+((C22009H(1)-C220090(1))./C220090(1))./fw0019L);
Q1C22009L = abs(imag(CCC22009L)./real(CCC22009L));
%%
%C12
%CCZ12001L = 1./C12001H(1).*(1+((C12001H(1)-C120010(1))./C120010(1))./fw001L);
CCC12009L = C12009H(1)./(1+((C12009H(1)-C120090(1))./C120090(1))./fw0019L);
Q1C12009L = abs(imag(CCC12009L)./real(CCC12009L));
%%
%C66
%CCZ66001L = 1./C66001H(1).*(1+((C66001H(1)-C660010(1))./C660010(1))./fw001L);
CCC66009L = C66009H(1)./(1+((C66009H(1)-C660090(1))./C660090(1))./fw0019L);
Q1C66009L = abs(imag(CCC66009L)./real(CCC66009L));
%%
%C45
CCC45009L = C45009H(1)./(1+((C45009H(1)-C450090(1))./C450090(1))./fw0019L);
Q1C45009L = abs(imag(CCC45009L)./real(CCC45009L));
%%
%C45S
CCC45009SL = C45009SH(1)./(1+((C45009SH(1)-C45009S0(1))./C45009S0(1))./fw0019L);
Q1C45009SL = abs(imag(CCC45009SL)./real(CCC45009SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00901L = ((CCC11009L-CCC66009L).*sin(RAD001(1)).^2-(CCC22009L-CCC66009L).*cos(RAD001(1)).^2).^2+(CCC12009L+CCC66009L).^2.*sin(2.*RAD001(1));
MPX00902L = ((CCC11009L-CCC66009L).*sin(RAD001(2)).^2-(CCC22009L-CCC66009L).*cos(RAD001(2)).^2).^2+(CCC12009L+CCC66009L).^2.*sin(2.*RAD001(2));
MPX00903L = ((CCC11009L-CCC66009L).*sin(RAD001(3)).^2-(CCC22009L-CCC66009L).*cos(RAD001(3)).^2).^2+(CCC12009L+CCC66009L).^2.*sin(2.*RAD001(3));

%P-wave velocity
VpX00901L = (CCC11009L.*sin(RAD001(1)).^2+CCC22009L.*cos(RAD001(1)).^2+CCC66009L+sqrt(MPX00901L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX00102L = (CCC11001L.*sin(RAD001(2)).^2+CCC22001L.*cos(RAD001(2)).^2+CCC66001L+sqrt(MPX00102L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00902L = sqrt(CCC45009L./2./rhoR);
VpX00903L = (CCC11009L.*sin(RAD001(3)).^2+CCC22009L.*cos(RAD001(3)).^2+CCC66009L+sqrt(MPX00903L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00901L = real(1./VpX00901L).^(-1);
Qp00901L = abs(imag(VpX00901L.^2)./real(VpX00901L.^2));
Vp00902L = real(1./VpX00902L).^(-1);
Qp00902L = abs(imag(VpX00902L.^2)./real(VpX00902L.^2));
Vp00903L = real(1./VpX00903L).^(-1);
Qp00903L = abs(imag(VpX00903L.^2)./real(VpX00903L.^2));
%%
%Anisotropy
epxl009L = (VpX00903L.^2-VpX00901L.^2)./(2.*VpX00901L.^2);
deltaV009L = 4.*(VpX00902L./VpX00901L-1)-(VpX00903L./VpX00901L-1);
%S-wave velocity
VsX00901L = (CCC11009L.*sin(RAD001(1)).^2+CCC22009L.*cos(RAD001(1)).^2+CCC66009L-sqrt(MPX00901L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102L = (CCC11001L.*sin(RAD001(2)).^2+CCC22001L.*cos(RAD001(2)).^2+CCC66001L-sqrt(MPX00102L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00902L = sqrt(CCC45009SL./2./rhoR);
VsX00903L = (CCC11009L.*sin(RAD001(3)).^2+CCC22009L.*cos(RAD001(3)).^2+CCC66009L-sqrt(MPX00903L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00901L = real(1./VsX00901L).^(-1);
Qs00901L = abs(imag(VsX00901L.^2)./real(VsX00901L.^2));
Vs00902L = real(1./VsX00902L).^(-1);
Qs00902L = abs(imag(VsX00902L.^2)./real(VsX00902L.^2));
Vs00903L = real(1./VsX00903L).^(-1);
Qs00903L = abs(imag(VsX00903L.^2)./real(VsX00903L.^2));
%%
%Medial Pressure
cita009M = (C22009H(5)-C220090(5)).^3./(2.*C22009H(5).*C220090(5).^2.*T009.*G009.^2);
tao009M = ((C22009H(5)-C220090(5))./C220090(5)./G009).^2;
%%
fw009M = (1-cita009M+cita009M.*sqrt(1-sqrt(-1).*OMI.*tao009M./cita009M.^2));
%C11
CCZ11009M = 1./C11009H(5).*(1+((C11009H(5)-C110090(5))./C110090(5))./fw009M);
CCC11009M = 1./CCZ11009M;
Q1C11009M = abs(imag(CCC11009M)./real(CCC11009M));
%%
%C22
CCZ22009M = 1./C22009H(5).*(1+((C22009H(5)-C220090(5))./C220090(5))./fw009M);
CCC22009M = 1./CCZ22009M;
Q1C22009M = abs(imag(CCC22009M)./real(CCC22009M));
%%
%C12
CCZ12009M = 1./C12009H(5).*(1+((C12009H(5)-C120090(5))./C120090(5))./fw009M);
CCC12009M = 1./CCZ12009M;
Q1C12009M = abs(imag(CCC12009M)./real(CCC12009M));
%%
%C66
CCZ66009M = 1./C66009H(5).*(1+((C66009H(5)-C660090(5))./C660090(5))./fw009M);
CCC66009M = 1./CCZ66009M;
Q1C66009M = abs(imag(CCC66009M)./real(CCC66009M));
%%
%C45
CCC45009M = C45009H(5)./(1+((C45009H(5)-C450090(5))./C450090(5))./fw009M);
Q1C45009M = abs(imag(CCC45009M)./real(CCC45009M));
%%
%C45S
CCC45009SM = C45009SH(5)./(1+((C45009SH(5)-C45009S0(5))./C45009S0(5))./fw009M);
Q1C45009SM = abs(imag(CCC45009SM)./real(CCC45009SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00901M = ((CCC11009M-CCC66009M).*sin(RAD001(1)).^2-(CCC22009M-CCC66009M).*cos(RAD001(1)).^2).^2+(CCC12009M+CCC66009M).^2.*sin(2.*RAD001(1));
MPX00902M = ((CCC11009M-CCC66009M).*sin(RAD001(2)).^2-(CCC22009M-CCC66009M).*cos(RAD001(2)).^2).^2+(CCC12009M+CCC66009M).^2.*sin(2.*RAD001(2));
MPX00903M = ((CCC11009M-CCC66009M).*sin(RAD001(3)).^2-(CCC22009M-CCC66009M).*cos(RAD001(3)).^2).^2+(CCC12009M+CCC66009M).^2.*sin(2.*RAD001(3));
%P-wave velocity
VpX00901M = (CCC11009M.*sin(RAD001(1)).^2+CCC22009M.*cos(RAD001(1)).^2+CCC66009M+sqrt(MPX00901M)).^(1/2).*(2.*rhoR).^(-1/2);
%VpX00102M = (CCC11001M.*sin(RAD001(2)).^2+CCC22001M.*cos(RAD001(2)).^2+CCC66001M+sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00902M = sqrt(CCC45009M./2./rhoR);
VpX00903M = (CCC11009M.*sin(RAD001(3)).^2+CCC22009M.*cos(RAD001(3)).^2+CCC66009M+sqrt(MPX00903M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00901M = real(1./VpX00901M).^(-1);
Qp00901M = abs(imag(VpX00901M.^2)./real(VpX00901M.^2));
Vp00902M = real(1./VpX00902M).^(-1);
Qp00902M = abs(imag(VpX00902M.^2)./real(VpX00902M.^2));
Vp00903M = real(1./VpX00903M).^(-1);
Qp00903M = abs(imag(VpX00903M.^2)./real(VpX00903M.^2));
%%
%Anisotropy
epxl009M = (Vp00903M.^2-Vp00901M.^2)./(2.*Vp00901M.^2);
deltaV009M = 4.*(Vp00902M./Vp00901M-1)-(Vp00903M./Vp00901M-1);
%S-wave velocity
VsX00901M = (CCC11009M.*sin(RAD001(1)).^2+CCC22009M.*cos(RAD001(1)).^2+CCC66009M-sqrt(MPX00901M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102M = (CCC11001M.*sin(RAD001(2)).^2+CCC22001M.*cos(RAD001(2)).^2+CCC66001M-sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00902M = sqrt(CCC45009SM./2./rhoR);
VsX00903M = (CCC11009M.*sin(RAD001(3)).^2+CCC22009M.*cos(RAD001(3)).^2+CCC66009M-sqrt(MPX00903M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00901M = real(1./VsX00901M).^(-1);
Qs00901M = abs(imag(VsX00901M.^2)./real(VsX00901M.^2));
Vs00902M = real(1./VsX00902M).^(-1);
Qs00902M = abs(imag(VsX00902M.^2)./real(VsX00902M.^2));
Vs00903M = real(1./VsX00903M).^(-1);
Qs00903M = abs(imag(VsX00903M.^2)./real(VsX00903M.^2));
%%
%High Pressure
cita009H = (C22009H(8)-C220090(8)).^3./(2.*C22009H(8).*C220090(8).^2.*T009.*G009.^2);
tao009H = ((C22009H(8)-C220090(8))./C220090(8)./G009).^2;
%%
fw009H = (1-cita009H+cita009H.*sqrt(1-sqrt(-1).*OMI.*tao009H./cita009H.^2));
%C11
CCZ11009H = 1./C11009H(8).*(1+((C11009H(8)-C110090(8))./C110090(8))./fw009H);
CCC11009H = 1./CCZ11009H;
Q1C11009H = abs(imag(CCC11009H)./real(CCC11009H));
%%
%C22
CCZ22009H = 1./C22009H(8).*(1+((C22009H(8)-C220090(8))./C220090(8))./fw009H);
CCC22009H = 1./CCZ22009H;
Q1C22009H = abs(imag(CCC22009H)./real(CCC22009H));
%%
%C12
CCZ12009H = 1./C12009H(8).*(1+((C12009H(8)-C120090(8))./C120090(8))./fw009H);
CCC12009H = 1./CCZ12009H;
Q1C12009H = abs(imag(CCC12009H)./real(CCC12009H));
%%
%C66
CCZ66009H = 1./C66009H(8).*(1+((C66009H(8)-C660090(8))./C660090(8))./fw009H);
CCC66009H = 1./CCZ66009H;
Q1C66009H = abs(imag(CCC66009H)./real(CCC66009H));
%%
%C45
CCC45009H = C45009H(8)./(1+((C45009H(8)-C450090(8))./C450090(8))./fw009H);
Q1C45009H = abs(imag(CCC45009H)./real(CCC45009H));
%%
%C45S
CCC45009SH = C45009SH(8)./(1+((C45009SH(8)-C45009S0(8))./C45009S0(8))./fw009H);
Q1C45009SH = abs(imag(CCC45009SH)./real(CCC45009SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00901H = ((CCC11009H-CCC66009H).*sin(RAD001(1)).^2-(CCC22009H-CCC66009H).*cos(RAD001(1)).^2).^2+(CCC12009H+CCC66009H).^2.*sin(2.*RAD001(1));
MPX00902H = ((CCC11009H-CCC66009H).*sin(RAD001(2)).^2-(CCC22009H-CCC66009H).*cos(RAD001(2)).^2).^2+(CCC12009H+CCC66009H).^2.*sin(2.*RAD001(2));
MPX00903H = ((CCC11009H-CCC66009H).*sin(RAD001(3)).^2-(CCC22009H-CCC66009H).*cos(RAD001(3)).^2).^2+(CCC12009H+CCC66009H).^2.*sin(2.*RAD001(3));
%P-wave velocity
VpX00901H = (CCC11009H.*sin(RAD001(1)).^2+CCC22009H.*cos(RAD001(1)).^2+CCC66009H+sqrt(MPX00901H)).^(1/2).*(2.*rhoR).^(-1/2);
%VpX00102H = (CCC11001H.*sin(RAD001(2)).^2+CCC22001H.*cos(RAD001(2)).^2+CCC66001H+sqrt(MPX00102H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00902H = sqrt(CCC45009H./2./rhoR);
VpX00903H = (CCC11009H.*sin(RAD001(3)).^2+CCC22009H.*cos(RAD001(3)).^2+CCC66009H+sqrt(MPX00903H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00901H = real(1./VpX00901H).^(-1);
Qp00901H = abs(imag(VpX00901H.^2)./real(VpX00901H.^2));
Vp00902H = real(1./VpX00902H).^(-1);
Qp00902H = abs(imag(VpX00902H.^2)./real(VpX00902H.^2));
Vp00903H = real(1./VpX00903H).^(-1);
Qp00903H = abs(imag(VpX00903H.^2)./real(VpX00903H.^2));
%%
%Anisotropy
epxl009H = (Vp00903H.^2-Vp00901H.^2)./(2.*Vp00901H.^2);
deltaV009H = 4.*(Vp00902H./Vp00901H-1)-(Vp00903H./Vp00901H-1);
%S-wave velocity
VsX00901H = (CCC11009H.*sin(RAD001(1)).^2+CCC22009H.*cos(RAD001(1)).^2+CCC66009M-sqrt(MPX00901M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102H = (CCC11001H.*sin(RAD001(2)).^2+CCC22001H.*cos(RAD001(2)).^2+CCC66001M-sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00902H = sqrt(CCC45009SM./2./rhoR);
VsX00903H = (CCC11009H.*sin(RAD001(3)).^2+CCC22009H.*cos(RAD001(3)).^2+CCC66009M-sqrt(MPX00903M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00901H = real(1./VsX00901H).^(-1);
Qs00901H = abs(imag(VsX00901H.^2)./real(VsX00901H.^2));
Vs00902H = real(1./VsX00902H).^(-1);
Qs00902H = abs(imag(VsX00902H.^2)./real(VsX00902H.^2));
Vs00903H = real(1./VsX00903H).^(-1);
Qs00903H = abs(imag(VsX00903H.^2)./real(VsX00903H.^2));
%%
%Autocorrelation length = 1um
ZCRACK009C = eQ./STCRACK009; 
deltaN009C = CdrQ.*ZCRACK009C./(1+CdrQ.*ZCRACK009C);
ZCRACK009SC = ZCRACK009C./(1+Kf.*deltaN009C./(CQ.*phic.*(1-deltaN009C)).*(1-Kf./KdQ).^(-1));
C22009HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK009SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK009SC));
C00901C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK009C))./3./(4.*pi+9.*KdrQ.*ZCRACK009C);
KX009C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK009C);
MX009C = KdQ./((1-KX009C./KdQ)-phi.*(1-KdQ./Kf));
a1009C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK009C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK009C));
C0090C = C00901C+a1009C.^2.*MX009C;
G009C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T009C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita009CL = (C22009HC(1)-C0090C(1)).^3./(2.*C22009HC(1).*C0090C(1).^2.*T009C.*G009C.^2);
tao009CL = ((C22009HC(1)-C0090C(1))./C0090C(1)./G009C).^2;
CCZ009CL = 1./C22009HC(1).*(1+((C22009HC(1)-C0090C(1))./C0090C(1))./(1-cita009CL+cita009CL.*sqrt(1-sqrt(-1).*OMI.*tao009CL./cita009CL.^2)));
CCC009CL = 1./CCZ009CL;
Q1C009CL = abs(imag(CCC009CL)./real(CCC009CL));
%
cita009CM = (C22009HC(4)-C0090C(4)).^3./(2.*C22009HC(4).*C0090C(4).^2.*T009C.*G009C.^2);
tao009CM = ((C22009HC(4)-C0090C(4))./C0090C(4)./G009C).^2;
CCZ009CM = 1./C22009HC(4).*(1+((C22009HC(4)-C0090C(4))./C0090C(4))./(1-cita009CM+cita009CM.*sqrt(1-sqrt(-1).*OMI.*tao009CM./cita009CM.^2)));
CCC009CM = 1./CCZ009CM;
Q1C009CM = abs(imag(CCC009CM)./real(CCC009CM));
%
cita009CH = (C22009HC(8)-C0090C(8)).^3./(2.*C22009HC(8).*C0090C(8).^2.*T009C.*G009C.^2);
tao009CH = ((C22009HC(8)-C0090C(8))./C0090C(8)./G009C).^2;
CCZ009CH = 1./C22009HC(8).*(1+((C22009HC(8)-C0090C(8))./C0090C(8))./(1-cita009CH+cita009CH.*sqrt(1-sqrt(-1).*OMI.*tao009CH./cita009CH.^2)));
CCC009CH = 1./CCZ009CH;
Q1C009CH = abs(imag(CCC009CH)./real(CCC009CH));
%%
%SATD deviation = 0.12 um
STCRACK012 = [0.181513566	0.18191209	0.184023852	0.186339735	0.188971469	0.19204208	0.193187116	0.197263254];
STPRE012 = [0	19.51349996	37.99256408	52.70401964	66.91547522	77.921681	86.02689128	93.92902579];
C22012 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK012+4.*mudQ.*eQ./STCRACK012);
CC22012 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK012))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK012);
ZCRACK012 = eQ./STCRACK012; 
ZCRACK012T = ZCRACK012./(1-PoQ./2);
C44012 = mudQ./(1+mudQ.*ZCRACK012T);
deltaN012 = CdrQ.*ZCRACK012./(1+CdrQ.*ZCRACK012);
ZCRACK012S = ZCRACK012./(1+Kf.*deltaN012./(CQ.*phic.*(1-deltaN012)).*(1-Kf./KdQ).^(-1));
C11012H = (4.*mudrQ.*(1+mudrQ.*ZCRACK012S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK012S))./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C1101201 = (4.*mudrQ.*(1+mudrQ.*ZCRACK012)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK012))./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C22012H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C2201201 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C12012H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C1201201 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C66012H = mudrQ./(1+mudrQ.*ZCRACK012T);
KX012 = KdrQ.*(3+4.*mudrQ.*ZCRACK012)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
MX012 = ((1-KX012./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1012 = 1-KX012./KdQ-(2.*mudrQ.*ZCRACK012)./(3+4.*mudrQ.*ZCRACK012).*KX012./KdQ;
a2012 = 1-KX012./KdQ+(6.*mudrQ.*ZCRACK012)./(3+4.*mudrQ.*ZCRACK012).*KX012./KdQ;
%C110100 = C1101001+a1010.^2.*MX010;
%C110100 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK010) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK010) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK010)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK010) + Kf .*(3 .*KdQ.^2.* ZCRACK010 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK010) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK010))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK010 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK010) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK010 + 3.* KdQ.* (-1 + phi).* ZCRACK010));
C110120 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK012)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK012 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK012) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK012 + 3.* KdQ.* (-1 + phi).* ZCRACK012))));
C220120 = C2201201+a2012.^2.*MX012;
C120120 = C1201201+a1012.*a2012.*MX012;
C660120 = mudrQ./(1+mudrQ.*ZCRACK012T);
%%
MPX01202H = ((C11012H-C66012H).*sin(RAD010(2)).^2-(C22012H-C66012H).*cos(RAD010(2)).^2).^2+(C12012H+C66012H).^2.*sin(2.*RAD010(2));
MPX012020 = ((C110120-C660120).*sin(RAD010(2)).^2-(C220120-C660120).*cos(RAD010(2)).^2).^2+(C120120+C660120).^2.*sin(2.*RAD010(2));
C45012H = (C11012H.*sin(RAD010(2)).^2+C22012H.*cos(RAD010(2)).^2+C66012H+sqrt(MPX01202H));
C450120 = (C110120.*sin(RAD010(2)).^2+C220120.*cos(RAD010(2)).^2+C660120+sqrt(MPX012020));
C45012SH = (C11012H.*sin(RAD010(2)).^2+C22012H.*cos(RAD010(2)).^2+C66012H-sqrt(MPX01202H));
C45012S0 = (C110120.*sin(RAD010(2)).^2+C220120.*cos(RAD010(2)).^2+C660120-sqrt(MPX012020));
G012 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T012 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita012L = (C22012H(1)-C220120(1)).^3./(2.*C22012H(1).*C220120(1).^2.*T012.*G012.^2);
tao012L = ((C22012H(1)-C220120(1))./C220120(1)./G012).^2;
%%
fw012L = (1-cita012L+cita012L.*sqrt(1-sqrt(-1).*OMI.*tao012L./cita012L.^2));
%C11
CCZ11012L = 1./C11012H(1).*(1+((C11012H(1)-C110120(1))./C110120(1))./fw012L);
CCC11012L = 1./CCZ11012L;
Q1C11012L = abs(imag(CCC11012L)./real(CCC11012L));
%%
%C22
CCZ22012L = 1./C22012H(1).*(1+((C22012H(1)-C220120(1))./C220120(1))./fw012L);
CCC22012L = 1./CCZ22012L;
Q1C22012L = abs(imag(CCC22012L)./real(CCC22012L));
%%
%C12
CCZ12012L = 1./C12012H(1).*(1+((C12012H(1)-C120120(1))./C120120(1))./fw012L);
CCC12012L = 1./CCZ12012L;
Q1C12012L = abs(imag(CCC12012L)./real(CCC12012L));
%%
%C66
CCZ66012L = 1./C66012H(1).*(1+((C66012H(1)-C660120(1))./C660120(1))./fw012L);
CCC66012L = 1./CCZ66012L;
Q1C66012L = abs(imag(CCC66012L)./real(CCC66012L));
%%
%C45
CCC45012L = C45012H(1)./(1+((C45012H(1)-C450120(1))./C450120(1))./fw012L);
Q1C45012L = abs(imag(CCC45012L)./real(CCC45012L));
%%
%C45S
CCC45012SL = C45012SH(1)./(1+((C45012SH(1)-C45012S0(1))./C45012S0(1))./fw012L);
Q1C45012SL = abs(imag(CCC45012SL)./real(CCC45012SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01201L = ((CCC11012L-CCC66012L).*sin(RAD010(1)).^2-(CCC22012L-CCC66012L).*cos(RAD010(1)).^2).^2+(CCC12012L+CCC66012L).^2.*sin(2.*RAD010(1));
MPX01202L = ((CCC11012L-CCC66012L).*sin(RAD010(2)).^2-(CCC22012L-CCC66012L).*cos(RAD010(2)).^2).^2+(CCC12012L+CCC66012L).^2.*sin(2.*RAD010(2));
MPX01203L = ((CCC11012L-CCC66012L).*sin(RAD010(3)).^2-(CCC22012L-CCC66012L).*cos(RAD010(3)).^2).^2+(CCC12012L+CCC66012L).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01201L = (CCC11012L.*sin(RAD010(1)).^2+CCC22012L.*cos(RAD010(1)).^2+CCC66012L+sqrt(MPX01201L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002L = (CCC11010L.*sin(RAD010(2)).^2+CCC22010L.*cos(RAD010(2)).^2+CCC66010L+sqrt(MPX01002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01202L = sqrt(CCC45012L./2./rhoR);
VpX01203L = (CCC11012L.*sin(RAD010(3)).^2+CCC22012L.*cos(RAD010(3)).^2+CCC66012L+sqrt(MPX01203L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01201L = real(1./VpX01201L).^(-1);
Qp01201L = abs(imag(VpX01201L.^2)./real(VpX01201L.^2));
Vp01202L = real(1./VpX01202L).^(-1);
Qp01202L = abs(imag(VpX01202L.^2)./real(VpX01202L.^2));
Vp01203L = real(1./VpX01203L).^(-1);
Qp01203L = abs(imag(VpX01203L.^2)./real(VpX01203L.^2));
%%
%Anisotropy
epxl012L = (Vp01203L.^2-Vp01201L.^2)./(2.*Vp01201L.^2);
deltaV012L = 4.*(Vp01202L./Vp01201L-1)-(Vp01203L./Vp01201L-1);
%S-wave velocity
VsX01201L = (CCC11012L.*sin(RAD010(1)).^2+CCC22012L.*cos(RAD010(1)).^2+CCC66012L-sqrt(MPX01201L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002L = (CCC11010L.*sin(RAD010(2)).^2+CCC22010L.*cos(RAD010(2)).^2+CCC66010L-sqrt(MPX01002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01202L = sqrt(CCC45012SL./2./rhoR);
VsX01203L = (CCC11012L.*sin(RAD010(3)).^2+CCC22012L.*cos(RAD010(3)).^2+CCC66012L-sqrt(MPX01203L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01201L = real(1./VsX01201L).^(-1);
Qs01201L = abs(imag(VsX01201L.^2)./real(VsX01201L.^2));
Vs01202L = real(1./VsX01202L).^(-1);
Qs01202L = abs(imag(VsX01202L.^2)./real(VsX01202L.^2));
Vs01203L = real(1./VsX01203L).^(-1);
Qs01203L = abs(imag(VsX01203L.^2)./real(VsX01203L.^2));
%%
%Medial Pressure
cita012M = (C22012H(5)-C220120(5)).^3./(2.*C22012H(5).*C220120(5).^2.*T012.*G012.^2);
tao012M = ((C22012H(5)-C220120(5))./C220120(5)./G012).^2;
%%
fw012M = (1-cita012M+cita012M.*sqrt(1-sqrt(-1).*OMI.*tao012M./cita012M.^2));
%C11
CCZ11012M = 1./C11012H(5).*(1+((C11012H(5)-C110120(5))./C110120(5))./fw012M);
CCC11012M = 1./CCZ11012M;
Q1C11012M = abs(imag(CCC11012M)./real(CCC11012M));
%%
%C22
CCZ22012M = 1./C22012H(5).*(1+((C22012H(5)-C220120(5))./C220120(5))./fw012M);
CCC22012M = 1./CCZ22012M;
Q1C22012M = abs(imag(CCC22012M)./real(CCC22012M));
%%
%C12
CCZ12012M = 1./C12012H(5).*(1+((C12012H(5)-C120120(5))./C120120(5))./fw012M);
CCC12012M = 1./CCZ12012M;
Q1C12012M = abs(imag(CCC12012M)./real(CCC12012M));
%%
%C66
CCZ66012M = 1./C66012H(5).*(1+((C66012H(5)-C660120(5))./C660120(5))./fw012M);
CCC66012M = 1./CCZ66012M;
Q1C66012M = abs(imag(CCC66012M)./real(CCC66012M));
%%
%C45
CCC45012M = C45012H(5)./(1+((C45012H(5)-C450120(5))./C450120(5))./fw012M);
Q1C45012M = abs(imag(CCC45012M)./real(CCC45012M));
%%
%C45S
CCC45012SM = C45012SH(5)./(1+((C45012SH(5)-C45012S0(5))./C45012S0(5))./fw012M);
Q1C45012SM = abs(imag(CCC45012SM)./real(CCC45012SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01201M = ((CCC11012M-CCC66012M).*sin(RAD010(1)).^2-(CCC22012M-CCC66012M).*cos(RAD010(1)).^2).^2+(CCC12012M+CCC66012M).^2.*sin(2.*RAD010(1));
MPX01202M = ((CCC11012M-CCC66012M).*sin(RAD010(2)).^2-(CCC22012M-CCC66012M).*cos(RAD010(2)).^2).^2+(CCC12012M+CCC66012M).^2.*sin(2.*RAD010(2));
MPX01203M = ((CCC11012M-CCC66012M).*sin(RAD010(3)).^2-(CCC22012M-CCC66012M).*cos(RAD010(3)).^2).^2+(CCC12012M+CCC66012M).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01201M = (CCC11012M.*sin(RAD010(1)).^2+CCC22012M.*cos(RAD010(1)).^2+CCC66012M+sqrt(MPX01201M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002M = (CCC11010M.*sin(RAD010(2)).^2+CCC22010M.*cos(RAD010(2)).^2+CCC66010M+sqrt(MPX01002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01202M = sqrt(CCC45012M./2./rhoR);
VpX01203M = (CCC11012M.*sin(RAD010(3)).^2+CCC22012M.*cos(RAD010(3)).^2+CCC66012M+sqrt(MPX01203M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01201M = real(1./VpX01201M).^(-1);
Qp01201M = abs(imag(VpX01201M.^2)./real(VpX01201M.^2));
Vp01202M = real(1./VpX01202M).^(-1);
Qp01202M = abs(imag(VpX01202M.^2)./real(VpX01202M.^2));
Vp01203M = real(1./VpX01203M).^(-1);
Qp01203M = abs(imag(VpX01203M.^2)./real(VpX01203M.^2));
%%
%Anisotropy
epxl012M = (Vp01203M.^2-Vp01201M.^2)./(2.*Vp01201M.^2);
deltaV012M = 4.*(Vp01202M./Vp01201M-1)-(Vp01203M./Vp01201M-1);
%S-wave velocity
VsX01201M = (CCC11012M.*sin(RAD010(1)).^2+CCC22012M.*cos(RAD010(1)).^2+CCC66012M-sqrt(MPX01201M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002M = (CCC11010M.*sin(RAD010(2)).^2+CCC22010M.*cos(RAD010(2)).^2+CCC66010M-sqrt(MPX01002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01202M = sqrt(CCC45012SM./2./rhoR);
VsX01203M = (CCC11012M.*sin(RAD010(3)).^2+CCC22012M.*cos(RAD010(3)).^2+CCC66012M-sqrt(MPX01203M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01201M = real(1./VsX01201M).^(-1);
Qs01201M = abs(imag(VsX01201M.^2)./real(VsX01201M.^2));
Vs01202M = real(1./VsX01202M).^(-1);
Qs01202M = abs(imag(VsX01202M.^2)./real(VsX01202M.^2));
Vs01203M = real(1./VsX01203M).^(-1);
Qs01203M = abs(imag(VsX01203M.^2)./real(VsX01203M.^2));
%%
%High Pressure
cita012H = (C22012H(8)-C220120(8)).^3./(2.*C22012H(8).*C220120(8).^2.*T012.*G012.^2);
tao012H = ((C22012H(8)-C220120(8))./C220120(8)./G012).^2;
%%
fw012H = (1-cita012H+cita012H.*sqrt(1-sqrt(-1).*OMI.*tao012H./cita012H.^2));
%C11
CCZ11012H = 1./C11012H(8).*(1+((C11012H(8)-C110120(8))./C110120(8))./fw012H);
CCC11012H = 1./CCZ11012H;
Q1C11012H = abs(imag(CCC11012H)./real(CCC11012H));
%%
%C22
CCZ22012H = 1./C22012H(8).*(1+((C22012H(8)-C220120(8))./C220120(8))./fw012H);
CCC22012H = 1./CCZ22012H;
Q1C22012H = abs(imag(CCC22012H)./real(CCC22012H));
%%
%C12
CCZ12012H = 1./C12012H(8).*(1+((C12012H(8)-C120120(8))./C120120(8))./fw012H);
CCC12012H = 1./CCZ12012H;
Q1C12012H = abs(imag(CCC12012H)./real(CCC12012H));
%%
%C66
CCZ66012H = 1./C66012H(8).*(1+((C66012H(8)-C660120(8))./C660120(8))./fw012H);
CCC66012H = 1./CCZ66012H;
Q1C66012H = abs(imag(CCC66012H)./real(CCC66012H));
%%
%C45
CCC45012H = C45012H(8)./(1+((C45012H(8)-C450120(8))./C450120(8))./fw012H);
Q1C45012H = abs(imag(CCC45012H)./real(CCC45012H));
%%
%C45S
CCC45012SH = C45012SH(8)./(1+((C45012SH(8)-C45012S0(8))./C45012S0(8))./fw012H);
Q1C45012SH = abs(imag(CCC45012SH)./real(CCC45012SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01201H = ((CCC11012H-CCC66012H).*sin(RAD010(1)).^2-(CCC22012H-CCC66012H).*cos(RAD010(1)).^2).^2+(CCC12012H+CCC66012H).^2.*sin(2.*RAD010(1));
MPX01202H = ((CCC11012H-CCC66012H).*sin(RAD010(2)).^2-(CCC22012H-CCC66012H).*cos(RAD010(2)).^2).^2+(CCC12012H+CCC66012H).^2.*sin(2.*RAD010(2));
MPX01203H = ((CCC11012H-CCC66012H).*sin(RAD010(3)).^2-(CCC22012H-CCC66012H).*cos(RAD010(3)).^2).^2+(CCC12012H+CCC66012H).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01201H = (CCC11012H.*sin(RAD010(1)).^2+CCC22012H.*cos(RAD010(1)).^2+CCC66012H+sqrt(MPX01201H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002H = (CCC11010H.*sin(RAD010(2)).^2+CCC22010H.*cos(RAD010(2)).^2+CCC66010H+sqrt(MPX01002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01202H = sqrt(CCC45012H./2./rhoR);
VpX01203H = (CCC11012H.*sin(RAD010(3)).^2+CCC22012H.*cos(RAD010(3)).^2+CCC66012H+sqrt(MPX01203H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01201H = real(1./VpX01201H).^(-1);
Qp01201H = abs(imag(VpX01201H.^2)./real(VpX01201H.^2));
Vp01202H = real(1./VpX01202H).^(-1);
Qp01202H = abs(imag(VpX01202H.^2)./real(VpX01202H.^2));
Vp01203H = real(1./VpX01203H).^(-1);
Qp01203H = abs(imag(VpX01203H.^2)./real(VpX01203H.^2));
%%
%Anisotropy
epxl012H = (Vp01203H.^2-Vp01201H.^2)./(2.*Vp01201H.^2);
deltaV012H = 4.*(Vp01202H./Vp01201H-1)-(Vp01203H./Vp01201H-1);
%S-wave velocity
VsX01201H = (CCC11012H.*sin(RAD010(1)).^2+CCC22012H.*cos(RAD010(1)).^2+CCC66012H-sqrt(MPX01201H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002H = (CCC11010H.*sin(RAD010(2)).^2+CCC22010H.*cos(RAD010(2)).^2+CCC66010H-sqrt(MPX01002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01202H = sqrt(CCC45012SH./2./rhoR);
VsX01203H = (CCC11012H.*sin(RAD010(3)).^2+CCC22012H.*cos(RAD010(3)).^2+CCC66012H-sqrt(MPX01203H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01201H = real(1./VsX01201H).^(-1);
Qs01201H = abs(imag(VsX01201H.^2)./real(VsX01201H.^2));
Vs01202H = real(1./VsX01202H).^(-1);
Qs01202H = abs(imag(VsX01202H.^2)./real(VsX01202H.^2));
Vs01203H = real(1./VsX01203H).^(-1);
Qs01203H = abs(imag(VsX01203H.^2)./real(VsX01203H.^2));
%%
%Satnde deviation = 12um
ZCRACK012C = eQ./STCRACK012; 
deltaN012C = CdrQ.*ZCRACK012C./(1+CdrQ.*ZCRACK012C);
ZCRACK012SC = ZCRACK012C./(1+Kf.*deltaN012C./(CQ.*phic.*(1-deltaN012C)).*(1-Kf./KdQ).^(-1));
C22012HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK012SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK012SC));
C0121C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK012C))./3./(4.*pi+9.*KdrQ.*ZCRACK012C);
KX012C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK012C);
MX012C = KdQ./((1-KX012C./KdQ)-phi.*(1-KdQ./Kf));
a1012C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK012C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK012C));
C0120C = C0121C+a1012C.^2.*MX012C;
G012C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T012C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita012CL = (C22012HC(1)-C0120C(1)).^3./(2.*C22012HC(1).*C0120C(1).^2.*T012C.*G012C.^2);
tao012CL = ((C22012HC(1)-C0120C(1))./C0120C(1)./G012C).^2;
CCZ012CL = 1./C22012HC(1).*(1+((C22012HC(1)-C0120C(1))./C0120C(1))./(1-cita012CL+cita012CL.*sqrt(1-sqrt(-1).*OMI.*tao012CL./cita012CL.^2)));
CCC012CL = 1./CCZ012CL;
Q1C012CL = abs(imag(CCC012CL)./real(CCC012CL));
%
cita012CM = (C22012HC(4)-C0120C(4)).^3./(2.*C22012HC(4).*C0120C(4).^2.*T012C.*G012C.^2);
tao012CM = ((C22012HC(4)-C0120C(4))./C0120C(4)./G012C).^2;
CCZ012CM = 1./C22012HC(4).*(1+((C22012HC(4)-C0120C(4))./C0120C(4))./(1-cita012CM+cita012CM.*sqrt(1-sqrt(-1).*OMI.*tao012CM./cita012CM.^2)));
CCC012CM = 1./CCZ012CM;
Q1C012CM = abs(imag(CCC012CM)./real(CCC012CM));
%
cita012CH = (C22012HC(8)-C0120C(8)).^3./(2.*C22012HC(8).*C0120C(8).^2.*T012C.*G012C.^2);
tao012CH = ((C22012HC(8)-C0120C(8))./C0120C(8)./G012C).^2;
CCZ012CH = 1./C22012HC(8).*(1+((C22012HC(8)-C0120C(8))./C0120C(8))./(1-cita012CH+cita012CH.*sqrt(1-sqrt(-1).*OMI.*tao012CH./cita012CH.^2)));
CCC012CH = 1./CCZ012CH;
Q1C012CH = abs(imag(CCC012CH)./real(CCC012CH));
%%
%Standard deviation = 15 um
STCRACK015 =[0.181141985	0.180572766	0.184285274	0.18903144	0.196526546	0.204316272	0.211834543	0.221078143];
STPRE015 = [0	18.66429633	36.20711337	50.35218326	64.27980069	75.43814693	83.88548075	92.45214821];
C22015 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK015+4.*mudQ.*eQ./STCRACK015);
CC22015 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK015))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK015);
ZCRACK015 = eQ./STCRACK015; 
ZCRACK015T = ZCRACK015./(1-PoQ./2);
C44015 = mudQ./(1+mudQ.*ZCRACK015T);
deltaN015 = CdrQ.*ZCRACK015./(1+CdrQ.*ZCRACK015);
ZCRACK015S = ZCRACK015./(1+Kf.*deltaN015./(CQ.*phic.*(1-deltaN015)).*(1-Kf./KdQ).^(-1));
C11015H = (4.*mudrQ.*(1+mudrQ.*ZCRACK015S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK015S))./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C1101501 = (4.*mudrQ.*(1+mudrQ.*ZCRACK015)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK015))./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C22015H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C2201501 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C12015H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C1201501 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C66015H = mudrQ./(1+mudrQ.*ZCRACK015T);
KX015 = KdrQ.*(3+4.*mudrQ.*ZCRACK015)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
MX015 = ((1-KX015./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1015 = 1-KX015./KdQ-(2.*mudrQ.*ZCRACK015)./(3+4.*mudrQ.*ZCRACK015).*KX015./KdQ;
a2015 = 1-KX015./KdQ+(6.*mudrQ.*ZCRACK015)./(3+4.*mudrQ.*ZCRACK015).*KX015./KdQ;
%C110200 = C1102001+a1020.^2.*MX020;
%C110200 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK020) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK020) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK020)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK020) + Kf .*(3 .*KdQ.^2.* ZCRACK020 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK020) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK020))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK020 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK020) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK020 + 3.* KdQ.* (-1 + phi).* ZCRACK020));
C110150 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK015)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK015 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK015) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK015 + 3.* KdQ.* (-1 + phi).* ZCRACK015))));
C220150 = C2201501+a2015.^2.*MX015;
C120150 = C1201501+a1015.*a2015.*MX015;
C660150 = mudrQ./(1+mudrQ.*ZCRACK015T);
%%
MPX01502H = ((C11015H-C66015H).*sin(RAD020(2)).^2-(C22015H-C66015H).*cos(RAD020(2)).^2).^2+(C12015H+C66015H).^2.*sin(2.*RAD020(2));
MPX015020 = ((C110150-C660150).*sin(RAD020(2)).^2-(C220150-C660150).*cos(RAD020(2)).^2).^2+(C120150+C660150).^2.*sin(2.*RAD020(2));
C45015H = (C11015H.*sin(RAD020(2)).^2+C22015H.*cos(RAD020(2)).^2+C66015H+sqrt(MPX01502H));
C450150 = (C110150.*sin(RAD020(2)).^2+C220150.*cos(RAD020(2)).^2+C660150+sqrt(MPX015020));
C45015SH = (C11015H.*sin(RAD020(2)).^2+C22015H.*cos(RAD020(2)).^2+C66015H-sqrt(MPX01502H));
C45015S0 = (C110150.*sin(RAD020(2)).^2+C220150.*cos(RAD020(2)).^2+C660150-sqrt(MPX015020));
%%
G015 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T015 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita015L = (C22015H(1)-C220150(1)).^3./(2.*C22015H(1).*C220150(1).^2.*T015.*G015.^2);
tao015L = ((C22015H(1)-C220150(1))./C220150(1)./G015).^2;
%%
fw015L = (1-cita015L+cita015L.*sqrt(1-sqrt(-1).*OMI.*tao015L./cita015L.^2));
%C11
CCZ11015L = 1./C11015H(1).*(1+((C11015H(1)-C110150(1))./C110150(1))./fw015L);
CCC11015L = 1./CCZ11015L;
Q1C11015L = abs(imag(CCC11015L)./real(CCC11015L));
%%
%C22
CCZ22015L = 1./C22015H(1).*(1+((C22015H(1)-C220150(1))./C220150(1))./fw015L);
CCC22015L = 1./CCZ22015L;
Q1C22015L = abs(imag(CCC22015L)./real(CCC22015L));
%%
%C12
CCZ12015L = 1./C12015H(1).*(1+((C12015H(1)-C120150(1))./C120150(1))./fw015L);
CCC12015L = 1./CCZ12015L;
Q1C12015L = abs(imag(CCC12015L)./real(CCC12015L));
%%
%C66
CCZ66015L = 1./C66015H(1).*(1+((C66015H(1)-C660150(1))./C660150(1))./fw015L);
CCC66015L = 1./CCZ66015L;
Q1C66015L = abs(imag(CCC66015L)./real(CCC66015L));
%%
%C45
CCC45015L = C45015H(1)./(1+((C45015H(1)-C450150(1))./C450150(1))./fw015L);
Q1C45015L = abs(imag(CCC45015L)./real(CCC45015L));
%%
%C45S
CCC45015SL = C45015SH(1)./(1+((C45015SH(1)-C45015S0(1))./C45015S0(1))./fw015L);
Q1C45015SL = abs(imag(CCC45015SL)./real(CCC45015SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01501L = ((CCC11015L-CCC66015L).*sin(RAD020(1)).^2-(CCC22015L-CCC66015L).*cos(RAD020(1)).^2).^2+(CCC12015L+CCC66015L).^2.*sin(2.*RAD020(1));
MPX01502L = ((CCC11015L-CCC66015L).*sin(RAD020(2)).^2-(CCC22015L-CCC66015L).*cos(RAD020(2)).^2).^2+(CCC12015L+CCC66015L).^2.*sin(2.*RAD020(2));
MPX01503L = ((CCC11015L-CCC66015L).*sin(RAD020(3)).^2-(CCC22015L-CCC66015L).*cos(RAD020(3)).^2).^2+(CCC12015L+CCC66015L).^2.*sin(2.*RAD020(3));

%P-wave velocity
VpX01501L = (CCC11015L.*sin(RAD020(1)).^2+CCC22015L.*cos(RAD020(1)).^2+CCC66015L+sqrt(MPX01501L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002L = (CCC11020L.*sin(RAD020(2)).^2+CCC22020L.*cos(RAD020(2)).^2+CCC66020L+sqrt(MPX02002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01502L = sqrt(CCC45015L./2./rhoR);
VpX01503L = (CCC11015L.*sin(RAD020(3)).^2+CCC22015L.*cos(RAD020(3)).^2+CCC66015L+sqrt(MPX01503L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01501L = real(1./VpX01501L).^(-1);
Qp01501L = abs(imag(VpX01501L.^2)./real(VpX01501L.^2));
Vp01502L = real(1./VpX01502L).^(-1);
Qp01502L = abs(imag(VpX01502L.^2)./real(VpX01502L.^2));
Vp01503L = real(1./VpX01503L).^(-1);
Qp01503L = abs(imag(VpX01503L.^2)./real(VpX01503L.^2));
%%
%Anisotropy
epxl015L = (Vp01503L.^2-Vp01501L.^2)./(2.*Vp01501L.^2);
deltaV015L = 4.*(Vp01502L./Vp01501L-1)-(Vp01503L./Vp01501L-1);
%S-wave velocity
VsX01501L = (CCC11015L.*sin(RAD020(1)).^2+CCC22015L.*cos(RAD020(1)).^2+CCC66015L-sqrt(MPX01501L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002L = (CCC11020L.*sin(RAD020(2)).^2+CCC22020L.*cos(RAD020(2)).^2+CCC66020L-sqrt(MPX02002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01502L = sqrt(CCC45015SL./2./rhoR);
VsX01503L = (CCC11015L.*sin(RAD020(3)).^2+CCC22015L.*cos(RAD020(3)).^2+CCC66015L-sqrt(MPX01503L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01501L = real(1./VsX01501L).^(-1);
Qs01501L = abs(imag(VsX01501L.^2)./real(VsX01501L.^2));
Vs01502L = real(1./VsX01502L).^(-1);
Qs01502L = abs(imag(VsX01502L.^2)./real(VsX01502L.^2));
Vs01503L = real(1./VsX01503L).^(-1);
Qs01503L = abs(imag(VsX01503L.^2)./real(VsX01503L.^2));
%%
%Medial Pressure
cita015M = (C22015H(5)-C220150(5)).^3./(2.*C22015H(5).*C220150(5).^2.*T015.*G015.^2);
tao015M = ((C22015H(5)-C220150(5))./C220150(5)./G015).^2;
%%
fw015M = (1-cita015M+cita015M.*sqrt(1-sqrt(-1).*OMI.*tao015M./cita015M.^2));
%C11
CCZ11015M = 1./C11015H(5).*(1+((C11015H(5)-C110150(5))./C110150(5))./fw015M);
CCC11015M = 1./CCZ11015M;
Q1C11015M = abs(imag(CCC11015M)./real(CCC11015M));
%%
%C22
CCZ22015M = 1./C22015H(5).*(1+((C22015H(5)-C220150(5))./C220150(5))./fw015M);
CCC22015M = 1./CCZ22015M;
Q1C22015M = abs(imag(CCC22015M)./real(CCC22015M));
%%
%C12
CCZ12015M = 1./C12015H(5).*(1+((C12015H(5)-C120150(5))./C120150(5))./fw015M);
CCC12015M = 1./CCZ12015M;
Q1C12015M = abs(imag(CCC12015M)./real(CCC12015M));
%%
%C66
CCZ66015M = 1./C66015H(5).*(1+((C66015H(5)-C660150(5))./C660150(5))./fw015M);
CCC66015M = 1./CCZ66015M;
Q1C66015M = abs(imag(CCC66015M)./real(CCC66015M));
%%
%C45
CCC45015M = C45015H(5)./(1+((C45015H(5)-C450150(5))./C450150(5))./fw015M);
Q1C45015M = abs(imag(CCC45015M)./real(CCC45015M));
%%
%C45S
CCC45015SM = C45015SH(5)./(1+((C45015SH(5)-C45015S0(5))./C45015S0(5))./fw015M);
Q1C45015SM = abs(imag(CCC45015SM)./real(CCC45015SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01501M = ((CCC11015M-CCC66015M).*sin(RAD020(1)).^2-(CCC22015M-CCC66015M).*cos(RAD020(1)).^2).^2+(CCC12015M+CCC66015M).^2.*sin(2.*RAD020(1));
MPX01502M = ((CCC11015M-CCC66015M).*sin(RAD020(2)).^2-(CCC22015M-CCC66015M).*cos(RAD020(2)).^2).^2+(CCC12015M+CCC66015M).^2.*sin(2.*RAD020(2));
MPX01503M = ((CCC11015M-CCC66015M).*sin(RAD020(3)).^2-(CCC22015M-CCC66015M).*cos(RAD020(3)).^2).^2+(CCC12015M+CCC66015M).^2.*sin(2.*RAD020(3));
%P-wave velocity
VpX01501M = (CCC11015M.*sin(RAD020(1)).^2+CCC22015M.*cos(RAD020(1)).^2+CCC66015M+sqrt(MPX01501M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002M = (CCC11020M.*sin(RAD020(2)).^2+CCC22020M.*cos(RAD020(2)).^2+CCC66020M+sqrt(MPX02002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01502M = sqrt(CCC45015M./2./rhoR);
VpX01503M = (CCC11015M.*sin(RAD020(3)).^2+CCC22015M.*cos(RAD020(3)).^2+CCC66015M+sqrt(MPX01503M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01501M = real(1./VpX01501M).^(-1);
Qp01501M = abs(imag(VpX01501M.^2)./real(VpX01501M.^2));
Vp01502M = real(1./VpX01502M).^(-1);
Qp01502M = abs(imag(VpX01502M.^2)./real(VpX01502M.^2));
Vp01503M = real(1./VpX01503M).^(-1);
Qp01503M = abs(imag(VpX01503M.^2)./real(VpX01503M.^2));
%%
%Anisotropy
epxl015M = (Vp01503M.^2-Vp01501M.^2)./(2.*Vp01501M.^2);
deltaV015M = 4.*(Vp01502M./Vp01501M-1)-(Vp01503M./Vp01501M-1);
%S-wave velocity
VsX01501M = (CCC11015M.*sin(RAD020(1)).^2+CCC22015M.*cos(RAD020(1)).^2+CCC66015M-sqrt(MPX01501M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002M = (CCC11020M.*sin(RAD020(2)).^2+CCC22020M.*cos(RAD020(2)).^2+CCC66020M-sqrt(MPX02002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01502M = sqrt(CCC45015SM./2./rhoR);
VsX01503M = (CCC11015M.*sin(RAD020(3)).^2+CCC22015M.*cos(RAD020(3)).^2+CCC66015M-sqrt(MPX01503M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01501M = real(1./VsX01501M).^(-1);
Qs01501M = abs(imag(VsX01501M.^2)./real(VsX01501M.^2));
Vs01502M = real(1./VsX01502M).^(-1);
Qs01502M = abs(imag(VsX01502M.^2)./real(VsX01502M.^2));
Vs01503M = real(1./VsX01503M).^(-1);
Qs01503M = abs(imag(VsX01503M.^2)./real(VsX01503M.^2));
%%
%High Pressure
cita015H = (C22015H(8)-C220150(8)).^3./(2.*C22015H(8).*C220150(8).^2.*T015.*G015.^2);
tao015H = ((C22015H(8)-C220150(8))./C220150(8)./G015).^2;
%%
fw015H = (1-cita015H+cita015H.*sqrt(1-sqrt(-1).*OMI.*tao015H./cita015H.^2));
%C11
CCZ11015H = 1./C11015H(8).*(1+((C11015H(8)-C110150(8))./C110150(8))./fw015H);
CCC11015H = 1./CCZ11015H;
Q1C11015H = abs(imag(CCC11015H)./real(CCC11015H));
%%
%C22
CCZ22015H = 1./C22015H(8).*(1+((C22015H(8)-C220150(8))./C220150(8))./fw015H);
CCC22015H = 1./CCZ22015H;
Q1C22015H = abs(imag(CCC22015H)./real(CCC22015H));
%%
%C12
CCZ12015H = 1./C12015H(8).*(1+((C12015H(8)-C120150(8))./C120150(8))./fw015H);
CCC12015H = 1./CCZ12015H;
Q1C12015H = abs(imag(CCC12015H)./real(CCC12015H));
%%
%C66
CCZ66015H = 1./C66015H(8).*(1+((C66015H(8)-C660150(8))./C660150(8))./fw015H);
CCC66015H = 1./CCZ66015H;
Q1C66015H = abs(imag(CCC66015H)./real(CCC66015H));
%%
%C45
CCC45015H = C45015H(8)./(1+((C45015H(8)-C450150(8))./C450150(8))./fw015H);
Q1C45015H = abs(imag(CCC45015H)./real(CCC45015H));
%%
%C45S
CCC45015SH = C45015SH(8)./(1+((C45015SH(8)-C45015S0(8))./C45015S0(8))./fw015H);
Q1C45015SH = abs(imag(CCC45015SH)./real(CCC45015SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01501H = ((CCC11015H-CCC66015H).*sin(RAD020(1)).^2-(CCC22015H-CCC66015H).*cos(RAD020(1)).^2).^2+(CCC12015H+CCC66015H).^2.*sin(2.*RAD020(1));
MPX01502H = ((CCC11015H-CCC66015H).*sin(RAD020(2)).^2-(CCC22015H-CCC66015H).*cos(RAD020(2)).^2).^2+(CCC12015H+CCC66015H).^2.*sin(2.*RAD020(2));
MPX01503H = ((CCC11015H-CCC66015H).*sin(RAD020(3)).^2-(CCC22015H-CCC66015H).*cos(RAD020(3)).^2).^2+(CCC12015H+CCC66015H).^2.*sin(2.*RAD020(3));
%P-wave velocity
VpX01501H = (CCC11015H.*sin(RAD020(1)).^2+CCC22015H.*cos(RAD020(1)).^2+CCC66015H+sqrt(MPX01501H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002H = (CCC11020H.*sin(RAD020(2)).^2+CCC22020H.*cos(RAD020(2)).^2+CCC66020H+sqrt(MPX02002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01502H = sqrt(CCC45015H./2./rhoR);
VpX01503H = (CCC11015H.*sin(RAD020(3)).^2+CCC22015H.*cos(RAD020(3)).^2+CCC66015H+sqrt(MPX01503H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01501H = real(1./VpX01501H).^(-1);
Qp01501H = abs(imag(VpX01501H.^2)./real(VpX01501H.^2));
Vp01502H = real(1./VpX01502H).^(-1);
Qp01502H = abs(imag(VpX01502H.^2)./real(VpX01502H.^2));
Vp01503H = real(1./VpX01503H).^(-1);
Qp01503H = abs(imag(VpX01503H.^2)./real(VpX01503H.^2));
%%
%Anisotropy
epxl015H = (Vp01503H.^2-Vp01501H.^2)./(2.*Vp01501H.^2);
deltaV015H = 4.*(Vp01502H./Vp01501H-1)-(Vp01503H./Vp01501H-1);
%S-wave velocity
VsX01501H = (CCC11015H.*sin(RAD020(1)).^2+CCC22015H.*cos(RAD020(1)).^2+CCC66015H-sqrt(MPX01501H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002H = (CCC11020H.*sin(RAD020(2)).^2+CCC22020H.*cos(RAD020(2)).^2+CCC66020H-sqrt(MPX02002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01502H = sqrt(CCC45015SH./2./rhoR);
VsX01503H = (CCC11015H.*sin(RAD020(3)).^2+CCC22015H.*cos(RAD020(3)).^2+CCC66015H-sqrt(MPX01503H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01501H = real(1./VsX01501H).^(-1);
Qs01501H = abs(imag(VsX01501H.^2)./real(VsX01501H.^2));
Vs01502H = real(1./VsX01502H).^(-1);
Qs01502H = abs(imag(VsX01502H.^2)./real(VsX01502H.^2));
Vs01503H = real(1./VsX01503H).^(-1);
Qs01503H = abs(imag(VsX01503H.^2)./real(VsX01503H.^2));
%%
%Autocorrelation length = 20um
ZCRACK015C = eQ./STCRACK015; 
deltaN015C = CdrQ.*ZCRACK015C./(1+CdrQ.*ZCRACK015C);
ZCRACK015SC = ZCRACK015C./(1+Kf.*deltaN015C./(CQ.*phic.*(1-deltaN015C)).*(1-Kf./KdQ).^(-1));
C22015HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK015SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK015SC));
C01501C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK015C))./3./(4.*pi+9.*KdrQ.*ZCRACK015C);
KX150C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK015C);
MX015C = KdQ./((1-KX150C./KdQ)-phi.*(1-KdQ./Kf));
a1015C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK015C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK015C));
C0150C = C01501C+a1015C.^2.*MX015C;
G015C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T015C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita015CL = (C22015HC(1)-C0150C(1)).^3./(2.*C22015HC(1).*C0150C(1).^2.*T015C.*G015C.^2);
tao015CL = ((C22015HC(1)-C0150C(1))./C0150C(1)./G015C).^2;
CCZ015CL = 1./C22015HC(1).*(1+((C22015HC(1)-C0150C(1))./C0150C(1))./(1-cita015CL+cita015CL.*sqrt(1-sqrt(-1).*OMI.*tao015CL./cita015CL.^2)));
CCC015CL = 1./CCZ015CL;
Q1C015CL = abs(imag(CCC015CL)./real(CCC015CL));
%%
%Standard deviation = 18 um
STCRACK018 = [0.181449338	0.184171997	0.191793571	0.206086462	0.223029084	0.246847672	0.265947629	0.288354652];
STPRE018 = [0	16.94588722	33.4105782	47.06687841	61.20508011	72.84122143	82.10503146	91.50629119];
C22018 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK018+4.*mudQ.*eQ./STCRACK018);
CC22018 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK018))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK018);
ZCRACK018 = eQ./STCRACK018; 
ZCRACK018T = ZCRACK018./(1-PoQ./2);
C44018 = mudQ./(1+mudQ.*ZCRACK018T);
deltaN018 = CdrQ.*ZCRACK018./(1+CdrQ.*ZCRACK018);
ZCRACK018S = ZCRACK018./(1+Kf.*deltaN018./(CQ.*phic.*(1-deltaN018)).*(1-Kf./KdQ).^(-1));
C11018H = (4.*mudrQ.*(1+mudrQ.*ZCRACK018S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK018S))./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C1101801 = (4.*mudrQ.*(1+mudrQ.*ZCRACK018)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK018))./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C22018H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C2201801 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C12018H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C1201801 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C66018H = mudrQ./(1+mudrQ.*ZCRACK018T);
KX018 = KdrQ.*(3+4.*mudrQ.*ZCRACK018)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
MX018 = ((1-KX018./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1018 = 1-KX018./KdQ-(2.*mudrQ.*ZCRACK018)./(3+4.*mudrQ.*ZCRACK018).*KX018./KdQ;
a2018 = 1-KX018./KdQ+(6.*mudrQ.*ZCRACK018)./(3+4.*mudrQ.*ZCRACK018).*KX018./KdQ;
%C110500 = C1105001+a1050.^2.*MX050;
%C110500 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK050) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK050) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK050)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK050) + Kf .*(3 .*KdQ.^2.* ZCRACK050 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK050) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK050))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK050 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK050) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK050 + 3.* KdQ.* (-1 + phi).* ZCRACK050));
C110180 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK018)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK018 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK018) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK018 + 3.* KdQ.* (-1 + phi).* ZCRACK018))));
C220180 = C2201801+a2018.^2.*MX018;
C120180 = C1201801+a1018.*a2018.*MX018;
C660180 = mudrQ./(1+mudrQ.*ZCRACK018T);
%%
MPX01802H = ((C11018H-C66018H).*sin(RAD050(2)).^2-(C22018H-C66018H).*cos(RAD050(2)).^2).^2+(C12018H+C66018H).^2.*sin(2.*RAD050(2));
MPX018020 = ((C110180-C660180).*sin(RAD050(2)).^2-(C220180-C660180).*cos(RAD050(2)).^2).^2+(C120180+C660180).^2.*sin(2.*RAD050(2));
C45018H = (C11018H.*sin(RAD050(2)).^2+C22018H.*cos(RAD050(2)).^2+C66018H+sqrt(MPX01802H));
C450180 = (C110180.*sin(RAD050(2)).^2+C220180.*cos(RAD050(2)).^2+C660180+sqrt(MPX018020));
C45018SH = (C11018H.*sin(RAD050(2)).^2+C22018H.*cos(RAD050(2)).^2+C66018H-sqrt(MPX01802H));
C45018S0 = (C110180.*sin(RAD050(2)).^2+C220180.*cos(RAD050(2)).^2+C660180-sqrt(MPX018020));
%%
G018 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T018 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita018L = (C22018H(1)-C220180(1)).^3./(2.*C22018H(1).*C220180(1).^2.*T018.*G018.^2);
tao018L = ((C22018H(1)-C220180(1))./C220180(1)./G018).^2;
%%
fw018L = (1-cita018L+cita018L.*sqrt(1-sqrt(-1).*OMI.*tao018L./cita018L.^2));
%C11
CCZ11018L = 1./C11018H(1).*(1+((C11018H(1)-C110180(1))./C110180(1))./fw018L);
CCC11018L = 1./CCZ11018L;
Q1C11018L = abs(imag(CCC11018L)./real(CCC11018L));
%%
%C22
CCZ22018L = 1./C22018H(1).*(1+((C22018H(1)-C220180(1))./C220180(1))./fw018L);
CCC22018L = 1./CCZ22018L;
Q1C22018L = abs(imag(CCC22018L)./real(CCC22018L));
%%
%C12
CCZ12018L = 1./C12018H(1).*(1+((C12018H(1)-C120180(1))./C120180(1))./fw018L);
CCC12018L = 1./CCZ12018L;
Q1C12018L = abs(imag(CCC12018L)./real(CCC12018L));
%%
%C66
CCZ66018L = 1./C66018H(1).*(1+((C66018H(1)-C660180(1))./C660180(1))./fw018L);
CCC66018L = 1./CCZ66018L;
Q1C66018L = abs(imag(CCC66018L)./real(CCC66018L));
%%
%C45
CCC45018L = C45018H(1)./(1+((C45018H(1)-C450180(1))./C450180(1))./fw018L);
Q1C45018L = abs(imag(CCC45018L)./real(CCC45018L));
%%
%C45S
CCC45018SL = C45018SH(1)./(1+((C45018SH(1)-C45018S0(1))./C45018S0(1))./fw018L);
Q1C45018SL = abs(imag(CCC45018SL)./real(CCC45018SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01801L = ((CCC11018L-CCC66018L).*sin(RAD050(1)).^2-(CCC22018L-CCC66018L).*cos(RAD050(1)).^2).^2+(CCC12018L+CCC66018L).^2.*sin(2.*RAD050(1));
MPX01802L = ((CCC11018L-CCC66018L).*sin(RAD050(2)).^2-(CCC22018L-CCC66018L).*cos(RAD050(2)).^2).^2+(CCC12018L+CCC66018L).^2.*sin(2.*RAD050(2));
MPX01803L = ((CCC11018L-CCC66018L).*sin(RAD050(3)).^2-(CCC22018L-CCC66018L).*cos(RAD050(3)).^2).^2+(CCC12018L+CCC66018L).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX05001L = (CCC11018L.*sin(RAD050(1)).^2+CCC22018L.*cos(RAD050(1)).^2+CCC66018L+sqrt(MPX01801L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002L = (CCC11050L.*sin(RAD050(2)).^2+CCC22050L.*cos(RAD050(2)).^2+CCC66050L+sqrt(MPX05002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01802L = sqrt(CCC45018L./2./rhoR);
VpX01803L = (CCC11018L.*sin(RAD050(3)).^2+CCC22018L.*cos(RAD050(3)).^2+CCC66018L+sqrt(MPX01803L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01801L = real(1./VpX05001L).^(-1);
Qp01801L = abs(imag(VpX05001L.^2)./real(VpX05001L.^2));
Vp01802L = real(1./VpX01802L).^(-1);
Qp01802L = abs(imag(VpX01802L.^2)./real(VpX01802L.^2));
Vp01803L = real(1./VpX01803L).^(-1);
Qp01803L = abs(imag(VpX01803L.^2)./real(VpX01803L.^2));
%%
%Anisotropy
epxl018L = (Vp01803L.^2-Vp01801L.^2)./(2.*Vp01801L.^2);
deltaV018L = 4.*(Vp01802L./Vp01801L-1)-(Vp01803L./Vp01801L-1);
%S-wave velocity
VsX01801L = (CCC11018L.*sin(RAD050(1)).^2+CCC22018L.*cos(RAD050(1)).^2+CCC66018L-sqrt(MPX01801L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002L = (CCC11050L.*sin(RAD050(2)).^2+CCC22050L.*cos(RAD050(2)).^2+CCC66050L-sqrt(MPX05002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01802L = sqrt(CCC45018SL./2./rhoR);
VsX01803L = (CCC11018L.*sin(RAD050(3)).^2+CCC22018L.*cos(RAD050(3)).^2+CCC66018L-sqrt(MPX01803L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01801L = real(1./VsX01801L).^(-1);
Qs01801L = abs(imag(VsX01801L.^2)./real(VsX01801L.^2));
Vs01802L = real(1./VsX01802L).^(-1);
Qs01802L = abs(imag(VsX01802L.^2)./real(VsX01802L.^2));
Vs01803L = real(1./VsX01803L).^(-1);
Qs01803L = abs(imag(VsX01803L.^2)./real(VsX01803L.^2));
%%
%Medial Pressure
cita018M = (C22018H(5)-C220180(5)).^3./(2.*C22018H(5).*C220180(5).^2.*T018.*G018.^2);
tao018M = ((C22018H(5)-C220180(5))./C220180(5)./G018).^2;
%%
fw018M = (1-cita018M+cita018M.*sqrt(1-sqrt(-1).*OMI.*tao018M./cita018M.^2));
%C11
CCZ11018M = 1./C11018H(5).*(1+((C11018H(5)-C110180(5))./C110180(5))./fw018M);
CCC11018M = 1./CCZ11018M;
Q1C11018M = abs(imag(CCC11018M)./real(CCC11018M));
%%
%C22
CCZ22018M = 1./C22018H(5).*(1+((C22018H(5)-C220180(5))./C220180(5))./fw018M);
CCC22018M = 1./CCZ22018M;
Q1C22018M = abs(imag(CCC22018M)./real(CCC22018M));
%%
%C12
CCZ12018M = 1./C12018H(5).*(1+((C12018H(5)-C120180(5))./C120180(5))./fw018M);
CCC12018M = 1./CCZ12018M;
Q1C12018M = abs(imag(CCC12018M)./real(CCC12018M));
%%
%C66
CCZ66018M = 1./C66018H(5).*(1+((C66018H(5)-C660180(5))./C660180(5))./fw018M);
CCC66018M = 1./CCZ66018M;
Q1C66018M = abs(imag(CCC66018M)./real(CCC66018M));
%%
%C45
CCC45050M = C45018H(5)./(1+((C45018H(5)-C450180(5))./C450180(5))./fw018M);
Q1C45050M = abs(imag(CCC45050M)./real(CCC45050M));
%%
%C45S
CCC45018SM = C45018SH(5)./(1+((C45018SH(5)-C45018S0(5))./C45018S0(5))./fw018M);
Q1C45018SM = abs(imag(CCC45018SM)./real(CCC45018SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01801M = ((CCC11018M-CCC66018M).*sin(RAD050(1)).^2-(CCC22018M-CCC66018M).*cos(RAD050(1)).^2).^2+(CCC12018M+CCC66018M).^2.*sin(2.*RAD050(1));
MPX01802M = ((CCC11018M-CCC66018M).*sin(RAD050(2)).^2-(CCC22018M-CCC66018M).*cos(RAD050(2)).^2).^2+(CCC12018M+CCC66018M).^2.*sin(2.*RAD050(2));
MPX01803M = ((CCC11018M-CCC66018M).*sin(RAD050(3)).^2-(CCC22018M-CCC66018M).*cos(RAD050(3)).^2).^2+(CCC12018M+CCC66018M).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX01801M = (CCC11018M.*sin(RAD050(1)).^2+CCC22018M.*cos(RAD050(1)).^2+CCC66018M+sqrt(MPX01801M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002M = (CCC11050M.*sin(RAD050(2)).^2+CCC22050M.*cos(RAD050(2)).^2+CCC66050M+sqrt(MPX05002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01802M = sqrt(CCC45050M./2./rhoR);
VpX01803M = (CCC11018M.*sin(RAD050(3)).^2+CCC22018M.*cos(RAD050(3)).^2+CCC66018M+sqrt(MPX01803M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01801M = real(1./VpX01801M).^(-1);
Qp01801M = abs(imag(VpX01801M.^2)./real(VpX01801M.^2));
Vp01802M = real(1./VpX01802M).^(-1);
Qp01802M = abs(imag(VpX01802M.^2)./real(VpX01802M.^2));
Vp01803M = real(1./VpX01803M).^(-1);
Qp01803M = abs(imag(VpX01803M.^2)./real(VpX01803M.^2));
%%
%Anisotropy
epxl018M = (Vp01803M.^2-Vp01801M.^2)./(2.*Vp01801M.^2);
deltaV018M = 4.*(Vp01802M./Vp01801M-1)-(Vp01803M./Vp01801M-1);
%S-wave velocity
VsX01801M = (CCC11018M.*sin(RAD050(1)).^2+CCC22018M.*cos(RAD050(1)).^2+CCC66018M-sqrt(MPX01801M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002M = (CCC11050M.*sin(RAD050(2)).^2+CCC22050M.*cos(RAD050(2)).^2+CCC66050M-sqrt(MPX05002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01802M = sqrt(CCC45018SM./2./rhoR);
VsX01803M = (CCC11018M.*sin(RAD050(3)).^2+CCC22018M.*cos(RAD050(3)).^2+CCC66018M-sqrt(MPX01803M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01801M = real(1./VsX01801M).^(-1);
Qs01801M = abs(imag(VsX01801M.^2)./real(VsX01801M.^2));
Vs01802M = real(1./VsX01802M).^(-1);
Qs01802M = abs(imag(VsX01802M.^2)./real(VsX01802M.^2));
Vs01803M = real(1./VsX01803M).^(-1);
Qs01803M = abs(imag(VsX01803M.^2)./real(VsX01803M.^2));
%%
%High Pressure
cita018H = (C22018H(8)-C220180(8)).^3./(2.*C22018H(8).*C220180(8).^2.*T018.*G018.^2);
tao018H = ((C22018H(8)-C220180(8))./C220180(8)./G018).^2;
%%
fw018H = (1-cita018H+cita018H.*sqrt(1-sqrt(-1).*OMI.*tao018H./cita018H.^2));
%C11
CCZ11018H = 1./C11018H(8).*(1+((C11018H(8)-C110180(8))./C110180(8))./fw018H);
CCC11018H = 1./CCZ11018H;
Q1C11018H = abs(imag(CCC11018H)./real(CCC11018H));
%%
%C22
CCZ22018H = 1./C22018H(8).*(1+((C22018H(8)-C220180(8))./C220180(8))./fw018H);
CCC22018H = 1./CCZ22018H;
Q1C22018H = abs(imag(CCC22018H)./real(CCC22018H));
%%
%C12
CCZ12018H = 1./C12018H(8).*(1+((C12018H(8)-C120180(8))./C120180(8))./fw018H);
CCC12018H = 1./CCZ12018H;
Q1C12018H = abs(imag(CCC12018H)./real(CCC12018H));
%%
%C66
CCZ66018H = 1./C66018H(8).*(1+((C66018H(8)-C660180(8))./C660180(8))./fw018H);
CCC66018H = 1./CCZ66018H;
Q1C66018H = abs(imag(CCC66018H)./real(CCC66018H));
%%
%C45
CCC45018H = C45018H(8)./(1+((C45018H(8)-C450180(8))./C450180(8))./fw018H);
Q1C45018H = abs(imag(CCC45018H)./real(CCC45018H));
%%
%C45S
CCC45018SH = C45018SH(8)./(1+((C45018SH(8)-C45018S0(8))./C45018S0(8))./fw018H);
Q1C45018SH = abs(imag(CCC45018SH)./real(CCC45018SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01801H = ((CCC11018H-CCC66018H).*sin(RAD050(1)).^2-(CCC22018H-CCC66018H).*cos(RAD050(1)).^2).^2+(CCC12018H+CCC66018H).^2.*sin(2.*RAD050(1));
MPX01802H = ((CCC11018H-CCC66018H).*sin(RAD050(2)).^2-(CCC22018H-CCC66018H).*cos(RAD050(2)).^2).^2+(CCC12018H+CCC66018H).^2.*sin(2.*RAD050(2));
MPX01803H = ((CCC11018H-CCC66018H).*sin(RAD050(3)).^2-(CCC22018H-CCC66018H).*cos(RAD050(3)).^2).^2+(CCC12018H+CCC66018H).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX01801H = (CCC11018H.*sin(RAD050(1)).^2+CCC22018H.*cos(RAD050(1)).^2+CCC66018H+sqrt(MPX01801H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002H = (CCC11050H.*sin(RAD050(2)).^2+CCC22050H.*cos(RAD050(2)).^2+CCC66050H+sqrt(MPX05002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01802H = sqrt(CCC45018H./2./rhoR);
VpX01803H = (CCC11018H.*sin(RAD050(3)).^2+CCC22018H.*cos(RAD050(3)).^2+CCC66018H+sqrt(MPX01803H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01801H = real(1./VpX01801H).^(-1);
Qp01801H = abs(imag(VpX01801H.^2)./real(VpX01801H.^2));
Vp01802H = real(1./VpX01802H).^(-1);
Qp01802H = abs(imag(VpX01802H.^2)./real(VpX01802H.^2));
Vp01803H = real(1./VpX01803H).^(-1);
Qp01803H = abs(imag(VpX01803H.^2)./real(VpX01803H.^2));
%%
%Anisotropy
epxl018H = (Vp01803H.^2-Vp01801H.^2)./(2.*Vp01801H.^2);
deltaV018H = 4.*(Vp01802H./Vp01801H-1)-(Vp01803H./Vp01801H-1);
%S-wave velocity
VsX01801H = (CCC11018H.*sin(RAD050(1)).^2+CCC22018H.*cos(RAD050(1)).^2+CCC66018H-sqrt(MPX01801H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002H = (CCC11050H.*sin(RAD050(2)).^2+CCC22050H.*cos(RAD050(2)).^2+CCC66050H-sqrt(MPX05002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01802H = sqrt(CCC45018SH./2./rhoR);
VsX01803H = (CCC11018H.*sin(RAD050(3)).^2+CCC22018H.*cos(RAD050(3)).^2+CCC66018H-sqrt(MPX01803H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01801H = real(1./VsX01801H).^(-1);
Qs01801H = abs(imag(VsX01801H.^2)./real(VsX01801H.^2));
Vs01802H = real(1./VsX01802H).^(-1);
Qs01802H = abs(imag(VsX01802H.^2)./real(VsX01802H.^2));
Vs01803H = real(1./VsX01803H).^(-1);
Qs01803H = abs(imag(VsX01803H.^2)./real(VsX01803H.^2));
%%
%Autocorrelation length = 50um
ZCRACK018C = eQ./STCRACK018; 
deltaN018C = CdrQ.*ZCRACK018C./(1+CdrQ.*ZCRACK018C);
ZCRACK018SC = ZCRACK018C./(1+Kf.*deltaN018C./(CQ.*phic.*(1-deltaN018C)).*(1-Kf./KdQ).^(-1));
C22018HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK018SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK018SC));
C01801C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK018C))./3./(4.*pi+9.*KdrQ.*ZCRACK018C);
KX018C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK018C);
MX018C = KdQ./((1-KX018C./KdQ)-phi.*(1-KdQ./Kf));
a1018C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK018C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK018C));
C0180C = C01801C+a1018C.^2.*MX018C;
G018C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T018C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita018CL = (C22018HC(1)-C0180C(1)).^3./(2.*C22018HC(1).*C0180C(1).^2.*T018C.*G018C.^2);
tao018CL = ((C22018HC(1)-C0180C(1))./C0180C(1)./G018C).^2;
CCZ018CL = 1./C22018HC(1).*(1+((C22018HC(1)-C0180C(1))./C0180C(1))./(1-cita018CL+cita018CL.*sqrt(1-sqrt(-1).*OMI.*tao018CL./cita018CL.^2)));
CCC018CL = 1./CCZ018CL;
Q1C018CL = abs(imag(CCC018CL)./real(CCC018CL));
%%
%%
% %Autocorrelation length 100 um
% STCRACK100 = [0.025196418	0.057455017	0.078283414	0.097636374	0.111761283	0.125227575	0.13297916	0.143853479];
% STPRE100 = [0	1.005983145	2.869487138	5.397357205	7.748816672	10.41647968	12.39357412	14.46656013];
% C22100 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK100+4.*mudQ.*eQ./STCRACK100);
% CC22100 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK100))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK100);
% ZCRACK100 = eQ./STCRACK100; 
% C44100 = mudQ./(1+mudQ.*ZCRACK100);
% deltaN100 = CdrQ.*ZCRACK100./(1+CdrQ.*ZCRACK100);
% ZCRACK100S = ZCRACK100./(1+Kf.*deltaN100./(CQ.*phic.*(1-deltaN100)).*(1-Kf./KdQ).^(-1));
% C11100H = (4.*mudrQ.*(1+mudrQ.*ZCRACK100S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK100S))./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
% C1110001 = (4.*mudrQ.*(1+mudrQ.*ZCRACK100)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK100))./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
% C22100H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
% C2210001 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
% C12100H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
% C1210001 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
% C66100H = mudrQ./(1+mudrQ.*ZCRACK100);
% KX100 = KdrQ.*(3+4.*mudrQ.*ZCRACK100)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
% MX100 = ((1-KX100./KdQ-phi)/KdQ+phi./Kf).^(-1);
% a1100 = 1-KX100./KdQ-(2.*mudrQ.*ZCRACK100)./(3+4.*mudrQ.*ZCRACK100).*KX100./KdQ;
% a2100 = 1-KX100./KdQ+(6.*mudrQ.*ZCRACK100)./(3+4.*mudrQ.*ZCRACK100).*KX100./KdQ;
% %C111000 = C1110001+a1100.^2.*MX100;
% %C111000 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK100) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK100) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK100)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK100) + Kf .*(3 .*KdQ.^2.* ZCRACK100 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK100) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK100))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK100 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK100) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK100 + 3.* KdQ.* (-1 + phi).* ZCRACK100));
% C111000 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK100)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK100 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK100) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK100 + 3.* KdQ.* (-1 + phi).* ZCRACK100))));
% C221000 = C2210001+a2100.^2.*MX100;
% C121000 = C1210001+a1100.*a2100.*MX100;
% C661000 = mudrQ./(1+mudrQ.*ZCRACK100);
% %%
% MPX10002H = ((C11100H-C66100H).*sin(RAD100(2)).^2-(C22100H-C66100H).*cos(RAD100(2)).^2).^2+(C12100H+C66100H).^2.*sin(2.*RAD100(2));
% MPX100020 = ((C111000-C661000).*sin(RAD100(2)).^2-(C221000-C661000).*cos(RAD100(2)).^2).^2+(C121000+C661000).^2.*sin(2.*RAD100(2));
% C45100H = (C11100H.*sin(RAD100(2)).^2+C22100H.*cos(RAD100(2)).^2+C66100H+sqrt(MPX10002H));
% C451000 = (C111000.*sin(RAD100(2)).^2+C221000.*cos(RAD100(2)).^2+C661000+sqrt(MPX100020));
% C45100SH = (C11100H.*sin(RAD100(2)).^2+C22100H.*cos(RAD100(2)).^2+C66100H-sqrt(MPX10002H));
% C45100S0 = (C111000.*sin(RAD100(2)).^2+C221000.*cos(RAD100(2)).^2+C661000-sqrt(MPX100020));
% %
% G100 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
% T100 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
% %%
% %Lower pressure
% cita100L = (C22100H(1)-C221000(1)).^3./(2.*C22100H(1).*C221000(1).^2.*T100.*G100.^2);
% tao100L = ((C22100H(1)-C221000(1))./C221000(1)./G100).^2;
% %%
% fw100L = (1-cita100L+cita100L.*sqrt(1-sqrt(-1).*OMI.*tao100L./cita100L.^2));
% %C11
% CCZ11100L = 1./C11100H(1).*(1+((C11100H(1)-C111000(1))./C111000(1))./fw100L);
% CCC11100L = 1./CCZ11100L;
% Q1C11100L = abs(imag(CCC11100L)./real(CCC11100L));
% %%
% %C22
% CCZ22100L = 1./C22100H(1).*(1+((C22100H(1)-C221000(1))./C221000(1))./fw100L);
% CCC22100L = 1./CCZ22100L;
% Q1C22100L = abs(imag(CCC22100L)./real(CCC22100L));
% %%
% %C12
% CCZ12100L = 1./C12100H(1).*(1+((C12100H(1)-C121000(1))./C121000(1))./fw100L);
% CCC12100L = 1./CCZ12100L;
% Q1C12100L = abs(imag(CCC12100L)./real(CCC12100L));
% %%
% %C66
% CCZ66100L = 1./C66100H(1).*(1+((C66100H(1)-C661000(1))./C661000(1))./fw100L);
% CCC66100L = 1./CCZ66100L;
% Q1C66100L = abs(imag(CCC66100L)./real(CCC66100L));
% %%
% %C45
% CCC45100L = C45100H(1)./(1+((C45100H(1)-C451000(1))./C451000(1))./fw100L);
% Q1C45100L = abs(imag(CCC45100L)./real(CCC45100L));
% %%
% %C45S
% CCC45100SL = C45100SH(1)./(1+((C45100SH(1)-C45100S0(1))./C45100S0(1))./fw100L);
% Q1C45100SL = abs(imag(CCC45100SL)./real(CCC45100SL));
% %%
% %Calculate the P-wave and S-wave velocity in low pressure
% MPX10001L = ((CCC11100L-CCC66100L).*sin(RAD100(1)).^2-(CCC22100L-CCC66100L).*cos(RAD100(1)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(1));
% MPX10002L = ((CCC11100L-CCC66100L).*sin(RAD100(2)).^2-(CCC22100L-CCC66100L).*cos(RAD100(2)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(2));
% MPX10003L = ((CCC11100L-CCC66100L).*sin(RAD100(3)).^2-(CCC22100L-CCC66100L).*cos(RAD100(3)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(3));
% 
% %P-wave velocity
% VpX10001L = (CCC11100L.*sin(RAD100(1)).^2+CCC22100L.*cos(RAD100(1)).^2+CCC66100L+sqrt(MPX10001L)).^(1/2).*(2.*rhoR).^(-1/2);
% % VpX10002L = (CCC11100L.*sin(RAD100(2)).^2+CCC22100L.*cos(RAD100(2)).^2+CCC66100L+sqrt(MPX10002L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002L = sqrt(CCC45100L./2./rhoR);
% VpX10003L = (CCC11100L.*sin(RAD100(3)).^2+CCC22100L.*cos(RAD100(3)).^2+CCC66100L+sqrt(MPX10003L)).^(1/2).*(2.*rhoR).^(-1/2);
% Vp10001L = real(1./VpX10001L).^(-1);
% Qp10001L = abs(imag(VpX10001L.^2)./real(VpX10001L.^2));
% Vp10002L = real(1./VpX10002L).^(-1);
% Qp10002L = abs(imag(VpX10002L.^2)./real(VpX10002L.^2));
% Vp10003L = real(1./VpX10003L).^(-1);
% Qp10003L = abs(imag(VpX10003L.^2)./real(VpX10003L.^2));
% %%
% %Anisotropy
% epxl100L = (Vp10003L.^2-Vp10001L.^2)./(2.*Vp10001L.^2);
% deltaV100L = 4.*(Vp10002L./Vp10001L-1)-(Vp10003L./Vp10001L-1);
% %S-wave velocity
% VsX10001L = (CCC11100L.*sin(RAD100(1)).^2+CCC22100L.*cos(RAD100(1)).^2+CCC66100L-sqrt(MPX10001L)).^(1/2).*(2.*rhoR).^(-1/2);
% %VsX10002L = (CCC11100L.*sin(RAD100(2)).^2+CCC22100L.*cos(RAD100(2)).^2+CCC66100L-sqrt(MPX10002L)).^(1/2).*(2.*rhoR).^(-1/2);
% VsX10002L = sqrt(CCC45100SL./2./rhoR);
% VsX10003L = (CCC11100L.*sin(RAD100(3)).^2+CCC22100L.*cos(RAD100(3)).^2+CCC66100L-sqrt(MPX10003L)).^(1/2).*(2.*rhoR).^(-1/2);
% Vs10001L = real(1./VsX10001L).^(-1);
% Qs10001L = abs(imag(VsX10001L.^2)./real(VsX10001L.^2));
% Vs10002L = real(1./VsX10002L).^(-1);
% Qs10002L = abs(imag(VsX10002L.^2)./real(VsX10002L.^2));
% Vs10003L = real(1./VsX10003L).^(-1);
% Qs10003L = abs(imag(VsX10003L.^2)./real(VsX10003L.^2));
% 
% %%
% %Medial Pressure
% cita100M = (C22100H(4)-C221000(4)).^3./(2.*C22100H(4).*C221000(4).^2.*T100.*G100.^2);
% tao100M = ((C22100H(4)-C221000(4))./C221000(4)./G100).^2;
% %%
% fw100M = (1-cita100M+cita100M.*sqrt(1-sqrt(-1).*OMI.*tao100M./cita100M.^2));
% %C11
% CCZ11100M = 1./C11100H(4).*(1+((C11100H(4)-C111000(4))./C111000(4))./fw100M);
% CCC11100M = 1./CCZ11100M;
% Q1C11100M = abs(imag(CCC11100M)./real(CCC11100M));
% %%
% %C22
% CCZ22100M = 1./C22100H(4).*(1+((C22100H(4)-C221000(4))./C221000(4))./fw100M);
% CCC22100M = 1./CCZ22100M;
% Q1C22100M = abs(imag(CCC22100M)./real(CCC22100M));
% %%
% %C12
% CCZ12100M = 1./C12100H(4).*(1+((C12100H(4)-C121000(4))./C121000(4))./fw100M);
% CCC12100M = 1./CCZ12100M;
% Q1C12100M = abs(imag(CCC12100M)./real(CCC12100M));
% %%
% %C66
% CCZ66100M = 1./C66100H(4).*(1+((C66100H(4)-C661000(4))./C661000(4))./fw100M);
% CCC66100M = 1./CCZ66100M;
% Q1C66100M = abs(imag(CCC66100M)./real(CCC66100M));
% %%
% %C45
% CCC45100M = C45100H(4)./(1+((C45100H(4)-C451000(4))./C451000(4))./fw100M);
% Q1C45100M = abs(imag(CCC45100M)./real(CCC45100M));
% %%
% %C45S
% CCC45100SM = C45100SH(4)./(1+((C45100SH(4)-C45100S0(4))./C45100S0(4))./fw100M);
% Q1C45100SM = abs(imag(CCC45100SM)./real(CCC45100SM));
% %%
% %Calculate the P-wave and S-wave velocity in low pressure
% MPX10001M = ((CCC11100M-CCC66100M).*sin(RAD100(1)).^2-(CCC22100M-CCC66100M).*cos(RAD100(1)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(1));
% MPX10002M = ((CCC11100M-CCC66100M).*sin(RAD100(2)).^2-(CCC22100M-CCC66100M).*cos(RAD100(2)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(2));
% MPX10003M = ((CCC11100M-CCC66100M).*sin(RAD100(3)).^2-(CCC22100M-CCC66100M).*cos(RAD100(3)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(3));
% 
% %P-wave velocity
% VpX10001M = (CCC11100M.*sin(RAD100(1)).^2+CCC22100M.*cos(RAD100(1)).^2+CCC66100M+sqrt(MPX10001M)).^(1/2).*(2.*rhoR).^(-1/2);
% % VpX10002M = (CCC11100M.*sin(RAD100(2)).^2+CCC22100M.*cos(RAD100(2)).^2+CCC66100M+sqrt(MPX10002M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002M = sqrt(CCC45100M./2./rhoR);
% VpX10003M = (CCC11100M.*sin(RAD100(3)).^2+CCC22100M.*cos(RAD100(3)).^2+CCC66100M+sqrt(MPX10003M)).^(1/2).*(2.*rhoR).^(-1/2);
% Vp10001M = real(1./VpX10001M).^(-1);
% Qp10001M = abs(imag(VpX10001M.^2)./real(VpX10001M.^2));
% Vp10002M = real(1./VpX10002M).^(-1);
% Qp10002M = abs(imag(VpX10002M.^2)./real(VpX10002M.^2));
% Vp10003M = real(1./VpX10003M).^(-1);
% Qp10003M = abs(imag(VpX10003M.^2)./real(VpX10003M.^2));
% %%
% %Anisotropy
% epxl100M = (Vp10003M.^2-Vp10001M.^2)./(2.*Vp10001M.^2);
% deltaV100M = 4.*(Vp10002M./Vp10001M-1)-(Vp10003M./Vp10001M-1);
% %S-wave velocity
% VsX10001M = (CCC11100M.*sin(RAD100(1)).^2+CCC22100M.*cos(RAD100(1)).^2+CCC66100M-sqrt(MPX10001M)).^(1/2).*(2.*rhoR).^(-1/2);
% %VsX10002M = (CCC11100M.*sin(RAD100(2)).^2+CCC22100M.*cos(RAD100(2)).^2+CCC66100M-sqrt(MPX10002M)).^(1/2).*(2.*rhoR).^(-1/2);
% VsX10002M = sqrt(CCC45100SM./2./rhoR);
% VsX10003M = (CCC11100M.*sin(RAD100(3)).^2+CCC22100M.*cos(RAD100(3)).^2+CCC66100M-sqrt(MPX10003M)).^(1/2).*(2.*rhoR).^(-1/2);
% Vs10001M = real(1./VsX10001M).^(-1);
% Qs10001M = abs(imag(VsX10001M.^2)./real(VsX10001M.^2));
% Vs10002M = real(1./VsX10002M).^(-1);
% Qs10002M = abs(imag(VsX10002M.^2)./real(VsX10002M.^2));
% Vs10003M = real(1./VsX10003M).^(-1);
% Qs10003M = abs(imag(VsX10003M.^2)./real(VsX10003M.^2));
% %%
% %High Pressure
% cita100H = (C22100H(8)-C221000(8)).^3./(2.*C22100H(8).*C221000(8).^2.*T100.*G100.^2);
% tao100H = ((C22100H(8)-C221000(8))./C221000(8)./G100).^2;
% %%
% fw100H = (1-cita100H+cita100H.*sqrt(1-sqrt(-1).*OMI.*tao100H./cita100H.^2));
% %C11
% CCZ11100H = 1./C11100H(8).*(1+((C11100H(8)-C111000(8))./C111000(8))./fw100H);
% CCC11100H = 1./CCZ11100H;
% Q1C11100H = abs(imag(CCC11100H)./real(CCC11100H));
% %%
% %C22
% CCZ22100H = 1./C22100H(8).*(1+((C22100H(8)-C221000(8))./C221000(8))./fw100H);
% CCC22100H = 1./CCZ22100H;
% Q1C22100H = abs(imag(CCC22100H)./real(CCC22100H));
% %%
% %C12
% CCZ12100H = 1./C12100H(8).*(1+((C12100H(8)-C121000(8))./C121000(8))./fw100H);
% CCC12100H = 1./CCZ12100H;
% Q1C12100H = abs(imag(CCC12100H)./real(CCC12100H));
% %%
% %C66
% CCZ66100H = 1./C66100H(8).*(1+((C66100H(8)-C661000(8))./C661000(8))./fw100H);
% CCC66100H = 1./CCZ66100H;
% Q1C66100H = abs(imag(CCC66100H)./real(CCC66100H));
% %%
% %C45
% CCC45100H = C45100H(8)./(1+((C45100H(8)-C451000(8))./C451000(8))./fw100H);
% Q1C45100H = abs(imag(CCC45100H)./real(CCC45100H));
% %%
% %C45S
% CCC45100SH = C45100SH(8)./(1+((C45100SH(8)-C45100S0(8))./C45100S0(8))./fw100H);
% Q1C45100SH = abs(imag(CCC45100SH)./real(CCC45100SH));
% %%
% %Calculate the P-wave and S-wave velocity in low pressure
% MPX10001H = ((CCC11100H-CCC66100H).*sin(RAD100(1)).^2-(CCC22100H-CCC66100H).*cos(RAD100(1)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(1));
% MPX10002H = ((CCC11100H-CCC66100H).*sin(RAD100(2)).^2-(CCC22100H-CCC66100H).*cos(RAD100(2)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(2));
% MPX10003H = ((CCC11100H-CCC66100H).*sin(RAD100(3)).^2-(CCC22100H-CCC66100H).*cos(RAD100(3)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(3));
% 
% %P-wave velocity
% VpX10001H = (CCC11100H.*sin(RAD100(1)).^2+CCC22100H.*cos(RAD100(1)).^2+CCC66100H+sqrt(MPX10001H)).^(1/2).*(2.*rhoR).^(-1/2);
% % VpX10002H = (CCC11100H.*sin(RAD100(2)).^2+CCC22100H.*cos(RAD100(2)).^2+CCC66100H+sqrt(MPX10002H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002H = sqrt(CCC45100H./2./rhoR);
% VpX10003H = (CCC11100H.*sin(RAD100(3)).^2+CCC22100H.*cos(RAD100(3)).^2+CCC66100H+sqrt(MPX10003H)).^(1/2).*(2.*rhoR).^(-1/2);
% Vp10001H = real(1./VpX10001H).^(-1);
% Qp10001H = abs(imag(VpX10001H.^2)./real(VpX10001H.^2));
% Vp10002H = real(1./VpX10002H).^(-1);
% Qp10002H = abs(imag(VpX10002H.^2)./real(VpX10002H.^2));
% Vp10003H = real(1./VpX10003H).^(-1);
% Qp10003H = abs(imag(VpX10003H.^2)./real(VpX10003H.^2));
% %%
% %Anisotropy
% epxl100H = (Vp10003H.^2-Vp10001H.^2)./(2.*Vp10001H.^2);
% deltaV100H = 4.*(Vp10002H./Vp10001H-1)-(Vp10003H./Vp10001H-1);
% %S-wave velocity
% VsX10001H = (CCC11100H.*sin(RAD100(1)).^2+CCC22100H.*cos(RAD100(1)).^2+CCC66100H-sqrt(MPX10001H)).^(1/2).*(2.*rhoR).^(-1/2);
% %VsX10002H = (CCC11100H.*sin(RAD100(2)).^2+CCC22100H.*cos(RAD100(2)).^2+CCC66100H-sqrt(MPX10002H)).^(1/2).*(2.*rhoR).^(-1/2);
% VsX10002H = sqrt(CCC45100SH./2./rhoR);
% VsX10003H = (CCC11100H.*sin(RAD100(3)).^2+CCC22100H.*cos(RAD100(3)).^2+CCC66100H-sqrt(MPX10003H)).^(1/2).*(2.*rhoR).^(-1/2);
% Vs10001H = real(1./VsX10001H).^(-1);
% Qs10001H = abs(imag(VsX10001H.^2)./real(VsX10001H.^2));
% Vs10002H = real(1./VsX10002H).^(-1);
% Qs10002H = abs(imag(VsX10002H.^2)./real(VsX10002H.^2));
% Vs10003H = real(1./VsX10003H).^(-1);
% Qs10003H = abs(imag(VsX10003H.^2)./real(VsX10003H.^2));
% %%
% %Autocorrelation length = 100um
% ZCRACK100C = eQ./STCRACK100; 
% deltaN100C = CdrQ.*ZCRACK100C./(1+CdrQ.*ZCRACK100C);
% ZCRACK100SC = ZCRACK100C./(1+Kf.*deltaN100C./(CQ.*phic.*(1-deltaN100C)).*(1-Kf./KdQ).^(-1));
% C22100HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK100SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK100SC));
% C10001C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK100C))./3./(4.*pi+9.*KdrQ.*ZCRACK100C);
% KX100C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK100C);
% MX100C = KdQ./((1-KX100C./KdQ)-phi.*(1-KdQ./Kf));
% a1100C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK100C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK100C));
% C1000C = C10001C+a1100C.^2.*MX100C;
% G100C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
% T100C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
% cita100CL = (C22100HC(1)-C1000C(1)).^3./(2.*C22100HC(1).*C1000C(1).^2.*T100C.*G100C.^2);
% tao100CL = ((C22100HC(1)-C1000C(1))./C1000C(1)./G100C).^2;
% CCZ100CL = 1./C22100HC(1).*(1+((C22100HC(1)-C1000C(1))./C1000C(1))./(1-cita100CL+cita100CL.*sqrt(1-sqrt(-1).*OMI.*tao100CL./cita100CL.^2)));
% CCC100CL = 1./CCZ100CL;
% Q1C100CL = abs(imag(CCC100CL)./real(CCC100CL));
%%
%%
%Plot the figure
figure(1)
plot(STPRE009,C22009)
hold on
plot(STPRE012,C22012)
hold on
plot(STPRE015,C22015)
hold on
plot(STPRE018,C22018)
% hold on
% plot(STPRE100,C22100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(11)
plot(STPRE009,CC22009)
hold on
plot(STPRE012,CC22012)
hold on
plot(STPRE015,CC22015)
hold on
plot(STPRE018,CC22018)
% hold on
% plot(STPRE100,CC22100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(201)
plot(STPRE009,C44009)
hold on
plot(STPRE012,C44012)
hold on
plot(STPRE015,C44015)
hold on
plot(STPRE018,C44018)
% hold on
% plot(STPRE100,C44100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
PREEX = (1:1:90);%The Pressure for simulation
%Standard deviation = 0.09 um
TOE009 = polyfit(STPRE009,C22009,1);
C22009TO = polyval(TOE009,PREEX);
%Standard deviation = 0.12 um
TOE012 = polyfit(STPRE012,C22012,1);
C22012TO = polyval(TOE012,PREEX);
%Standard deviation = 0.15 um
TOE015 = polyfit(STPRE015,C22015,1);
C22015TO = polyval(TOE015,PREEX);
%Standard deviation = 0.18 um
TOE018 = polyfit(STPRE018,C22018,1);
C22018TO = polyval(TOE018,PREEX);
%Autocorrelation length = 100 um
% TOE100 = polyfit(STPRE100,C22100,1);
% C22100TO = polyval(TOE100,PREEX);
%%
%S-wave-Axial
%Standard deviation = 0.09 um
TOES009 = polyfit(STPRE009,C44009,1);
C44009TO = polyval(TOES009,PREEX);
%Standard deviation = 0.12 um
TOES012 = polyfit(STPRE012,C44012,1);
C44012TO = polyval(TOES012,PREEX);
%Standard deviation = 0.18 um
TOES015 = polyfit(STPRE015,C44015,1);
C44015TO = polyval(TOES015,PREEX);
%Standard deviation = 0.18 um
TOES018 = polyfit(STPRE018,C44018,1);
C44018TO = polyval(TOES018,PREEX);
% %Autocorrelation length = 100 um
% TOES100 = polyfit(STPRE100,C44100,1);
% C44100TO = polyval(TOES100,PREEX);
%%
%Confining pressure
%Do linear fitting
%Standard deviation = 0.09 um
TOE009C = polyfit(STPRE009,CC22009,1);
C22009TOC = polyval(TOE009C,PREEX);
%Standard deviation = 0.12 um
TOE012C = polyfit(STPRE012,CC22012,1);
C22012TOC = polyval(TOE012C,PREEX);
%Standard deviation = 0.15 um
TOE015C = polyfit(STPRE015,CC22015,1);
C22015TOC = polyval(TOE015C,PREEX);
%Standard deviation = 0.18 um
TOE018C = polyfit(STPRE018,CC22018,1);
C22018TOC = polyval(TOE018C,PREEX);
% %Autocorrelation length = 100 um
% TOE100C = polyfit(STPRE100,CC22100,1);
% C22100TOC = polyval(TOE100C,PREEX);
%%
%plot the Figure
figure(2)
plot(PREEX,C22009TO)
hold on
plot(PREEX,C22012TO)
hold on
plot(PREEX,C22015TO)
hold on
plot(PREEX,C22018TO)
% hold on
% plot(PREEX,C22100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%plot the Figure
figure(21)
plot(PREEX,C22009TOC)
hold on
plot(PREEX,C22012TOC)
hold on
plot(PREEX,C22015TOC)
hold on
plot(PREEX,C22018TOC)
% hold on
% plot(PREEX,C22100TOC)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(202)
plot(PREEX,C44009TO)
hold on
plot(PREEX,C44012TO)
hold on
plot(PREEX,C44015TO)
hold on
plot(PREEX,C44018TO)
% hold on
% plot(PREEX,C44100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Halite
% KdH = 24.8;%Bulk modulus
% mudH = 14.9;%Shear modulus
% eH = 0.001;%Crack density
% %Autocorrelation length = 01 um
% STCRACKYY001 = [0.00079251	0.000931332	0.004120363	0.007793148	0.020579987	0.038499424	0.051049309	0.06419595];
% STPREYY001 = [0	0.202737285	0.355327594	0.931704087	1.630869606	3.365054813	5.46356364	8.213693503];
% C22YY001 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY001+4.*mudH.*eH./STCRACKYY001);
% CC22YY001 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY001))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY001));
% ZCRACKYY001 = eH./STCRACKYY001;
% C44YY001 = mudH./(1+mudH.*ZCRACKYY001);%The shear modulus
% %Autocorrelation length = 10 um
% STCRACKYY010 = [0.005469845	0.015377379	0.02303006	0.031004413	0.041231686	0.055593398	0.062841233	0.072040536];
% STPREYY010 = [0	0.356415558	1.151989885	2.333955441	3.515672137	5.096625839	6.552226966	8.187464377];
% C22YY010 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY010+4.*mudH.*eH./STCRACKYY010);
% CC22YY010 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY010))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY010));
% ZCRACKYY010 = eH./STCRACKYY010;
% C44YY010 = mudH./(1+mudH.*ZCRACKYY010);%The shear modulus
% %Autocorrelation length = 20 um
% STCRACKYY020 =[0.00846169	0.0200158	0.027861821	0.035602755	0.041007088	0.046395757	0.051646188	0.057789789];
% STPREYY020 = [0	0.556028013	1.590818916	2.995307749	4.307608278	5.780010667	6.870309792	8.073653803];
% C22YY020 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY020+4.*mudH.*eH./STCRACKYY020);
% CC22YY020 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY020))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY020));
% ZCRACKYY020 = eH./STCRACKYY020;
% C44YY020 = mudH./(1+mudH.*ZCRACKYY020);%The shear modulus
% %Autocorrelation length = 50 um
% STCRACKYY050 = [0.011195278	0.023972153	0.032299883	0.039735595	0.044594887	0.050018095	0.053076109	0.056905667];
% STPREYY050 = [0	0.739579318	1.984545642	3.621491968	5.092293829	6.698810821	7.876329835	9.102209186];
% C22YY050 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY050+4.*mudH.*eH./STCRACKYY050);
% CC22YY050 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY050))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY050));
% ZCRACKYY050 = eH./STCRACKYY050;
% C44YY050 = mudH./(1+mudH.*ZCRACKYY050);%The shear modulus
% %Autocorrelation length 100 um
% STCRACKYY100 = [0.012098863	0.028967392	0.03912266	0.04728462	0.052366583	0.058368551	0.063901518	0.069749457];
% STPREYY100 = [0	0.641507466	1.870219591	3.501215296	4.951223978	6.520227688	7.669820925	8.920581553];
% C22YY100 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY100+4.*mudH.*eH./STCRACKYY100);
% CC22YY100 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY100))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY100));
% ZCRACKYY100 = eH./STCRACKYY100;
% C44YY100 = mudH./(1+mudH.*ZCRACKYY100);%The shear modulus
% %%
% %Plot stiffness
% figure(3)
% plot(STPREYY001,C22YY001)
% hold on
% plot(STPREYY010,C22YY010)
% hold on
% plot(STPREYY020,C22YY020)
% hold on
% plot(STPREYY050,C22YY050)
% hold on
% plot(STPREYY100,C22YY100)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
% %Plot stiffness
% figure(31)
% plot(STPREYY001,CC22YY001)
% hold on
% plot(STPREYY010,CC22YY010)
% hold on
% plot(STPREYY020,CC22YY020)
% hold on
% plot(STPREYY050,CC22YY050)
% hold on
% plot(STPREYY100,CC22YY100)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
% %%
% figure(203)
% plot(STPREYY001,C44YY001)
% hold on
% plot(STPREYY010,C44YY010)
% hold on
% plot(STPREYY020,C44YY020)
% hold on
% plot(STPREYY050,C44YY050)
% hold on
% plot(STPREYY100,C44YY100)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
% %%
% %Caculate the third-order elastic constant
% %Do linear fitting Yanyan
% PREEXYY = (1:0.1:8);%The Pressure for simulation
% %Autocorrelation length = 1 um
% TOEYY001 = polyfit(STPREYY001,C22YY001,1);
% STFYY001TO = polyval(TOEYY001,PREEXYY);
% %Autocorrelation length = 10 um
% TOEYY010 = polyfit(STPREYY010,C22YY010,1);
% STFYY010TO = polyval(TOEYY010,PREEXYY);
% %Autocorrelation length = 20 um
% TOEYY020 = polyfit(STPREYY020,C22YY020,1);
% STFYY020TO = polyval(TOEYY020,PREEXYY);
% %Autocorrelation length = 50 um
% TOEYY050 = polyfit(STPREYY050,C22YY050,1);
% STFYY050TO = polyval(TOEYY050,PREEXYY);
% %Autocorrelation length = 100 um
% TOEYY100 = polyfit(STPREYY100,C22YY100,1);
% STFYY100TO = polyval(TOEYY100,PREEXYY);
% %%
% %Shear
% %Autocorrelation length = 1 um
% TOEYYS001 = polyfit(STPREYY001,C44YY001,1);
% STFYYS001TO = polyval(TOEYYS001,PREEXYY);
% %Autocorrelation length = 10 um
% TOEYYS010 = polyfit(STPREYY010,C44YY010,1);
% STFYYS010TO = polyval(TOEYYS010,PREEXYY);
% %Autocorrelation length = 20 um
% TOEYYS020 = polyfit(STPREYY020,C44YY020,1);
% STFYYS020TO = polyval(TOEYYS020,PREEXYY);
% %Autocorrelation length = 50 um
% TOEYYS050 = polyfit(STPREYY050,C44YY050,1);
% STFYYS050TO = polyval(TOEYYS050,PREEXYY);
% %Autocorrelation length = 100 um
% TOEYYS100 = polyfit(STPREYY100,C44YY100,1);
% STFYYS100TO = polyval(TOEYYS100,PREEXYY);
% %%
% %Confining pressure
% %Autocorrelation length = 1 um
% TOEYY001C = polyfit(STPREYY001,CC22YY001,1);
% STFYY001TOC = polyval(TOEYY001C,PREEXYY);
% %Autocorrelation length = 10 um
% TOEYY010C = polyfit(STPREYY010,CC22YY010,1);
% STFYY010TOC = polyval(TOEYY010C,PREEXYY);
% %Autocorrelation length = 20 um
% TOEYY020C = polyfit(STPREYY020,CC22YY020,1);
% STFYY020TOC = polyval(TOEYY020C,PREEXYY);
% %Autocorrelation length = 50 um
% TOEYY050C = polyfit(STPREYY050,CC22YY050,1);
% STFYY050TOC = polyval(TOEYY050C,PREEXYY);
% %Autocorrelation length = 100 um
% TOEYY100C = polyfit(STPREYY100,CC22YY100,1);
% STFYY100TOC = polyval(TOEYY100C,PREEXYY);
% %%
% %plot the Figure
% figure(4)
% plot(PREEXYY,STFYY001TO)
% hold on
% plot(PREEXYY,STFYY010TO)
% hold on
% plot(PREEXYY,STFYY020TO)
% hold on
% plot(PREEXYY,STFYY050TO)
% hold on
% plot(PREEXYY,STFYY100TO)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
% %plot the Figure
% figure(41)
% plot(PREEXYY,STFYY001TOC)
% hold on
% plot(PREEXYY,STFYY010TOC)
% hold on
% plot(PREEXYY,STFYY020TOC)
% hold on
% plot(PREEXYY,STFYY050TOC)
% hold on
% plot(PREEXYY,STFYY100TOC)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
% %%
% figure(204)
% plot(PREEXYY,STFYYS001TO)
% hold on
% plot(PREEXYY,STFYYS010TO)
% hold on
% plot(PREEXYY,STFYYS020TO)
% hold on
% plot(PREEXYY,STFYYS050TO)
% hold on
% plot(PREEXYY,STFYYS100TO)
% legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Stiffness (GPa)')
%%
%deal with the third-order elastic constant
AUTOL = [0.09 0.12 0.15 0.18];%Autocorrelation length
TOEQA = 1000.*[TOE009(1) TOE012(1) TOE015(1) TOE018(1)];%Third-order elastic constant for quartz for axial stress
TOEQC = 1000.*[TOE009C(1) TOE012C(1) TOE015C(1) TOE018C(1)];%Third-order elastic constant for quartz for confining stress
% TOEYYA = 1000.*[TOEYY001(1) TOEYY010(1) TOEYY020(1) TOEYY050(1) TOEYY100(1)];%Third-order elastic constant for Yanyan for axial stress
% TOEYYC = 1000.*[TOEYY001C(1) TOEYY010C(1) TOEYY020C(1) TOEYY050C(1) TOEYY100C(1)];%Third-order elastic constant for Yanyan for confining stress
%%
TOEQAS = 1000.*[TOES009(1) TOES012(1) TOES015(1) TOES018(1)];%Third-order elastic constant for quartz for axial stres
% TOEYYAS = 1000.*[TOEYYS001(1) TOEYYS010(1) TOEYYS020(1) TOEYYS050(1) TOEYYS100(1)];%Third-order elastic constant for Yanyan for axial stress
%%
% figure(5)
% plot(AUTOL,TOEQA)
% % hold on
% % plot(AUTOL,TOEYYA)
% legend('Quartz','Yanyan')
% xlabel('Autocorrelation length (um)')
% ylabel('Third-order elastic constant')
% figure(6)
% plot(AUTOL,TOEQC)
% hold on
% plot(AUTOL,TOEYYC)
% legend('Quartz','Yanyan')
% xlabel('Autocorrelation length (um)')
% ylabel('Third-order elastic constant')
%%
% figure(205)
% plot(AUTOL,TOEQAS)
% hold on
% plot(AUTOL,TOEYYAS)
% legend('Quartz','Yanyan')
% xlabel('Autocorrelation length (um)')
% ylabel('Third-order elastic constant')
%%
%All the things will be modified
% %%
% %to deal with dissipation
% figure(100)
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC010L)
% hold on
% plot(log10(k2a),CCC020L)
% hold on
% plot(log10(k2a),CCC050L)
% hold on
% plot(log10(k2a),CCC100L)
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with dissipation
% figure(101)
% plot(log10(k2a),CCC001CL)
% hold on
% plot(log10(k2a),CCC010CL)
% hold on
% plot(log10(k2a),CCC020CL)
% hold on
% plot(log10(k2a),CCC050CL)
% hold on
% plot(log10(k2a),CCC100CL)
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with attenuation
% figure(102)
% plot(log10(k2a),log10(Q1C22001L))
% hold on
% plot(log10(k2a),log10(Q1C010L))
% hold on
% plot(log10(k2a),log10(Q1C020L))
% hold on
% plot(log10(k2a),log10(Q1C050L))
% hold on
% plot(log10(k2a),log10(Q1C100L))
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with attenuation
% figure(103)
% plot(log10(k2a),log10(Q1C001CL))
% hold on
% plot(log10(k2a),log10(Q1C010CL))
% hold on
% plot(log10(k2a),log10(Q1C020CL))
% hold on
% plot(log10(k2a),log10(Q1C050CL))
% hold on
% plot(log10(k2a),log10(Q1C100CL))
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(104)
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC001M)
% hold on
% plot(log10(k2a),CCC001H)
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(105)
% plot(log10(k2a),log10(Q1C22001L))
% hold on
% plot(log10(k2a),log10(Q1C001M))
% hold on
% plot(log10(k2a),log10(Q1C001H))
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %
% figure(106)
% plot(log10(k2a),CCC001CL)
% hold on
% plot(log10(k2a),CCC001CM)
% hold on
% plot(log10(k2a),CCC001CH)
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(107)
% plot(log10(k2a),log10(Q1C001CL))
% hold on
% plot(log10(k2a),log10(Q1C001CM))
% hold on
% plot(log10(k2a),log10(Q1C001CH))
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %%
% %
% figure(301)
% plot(log10(k2a),CCC11001L)
% hold on
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC66001L)
% hold on
% plot(log10(k2a),HHB)
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
%%
% figure(101)
% plot(log10(k2a),real(CCC11009L))
% hold on
% plot(log10(k2a),real(CCC22009L))
% hold on
% plot(log10(k2a),real(CCC66009L))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% figure(102)
% plot(log10(k2a),real(CCC11009M))
% hold on
% plot(log10(k2a),real(CCC22009M))
% hold on
% plot(log10(k2a),real(CCC66009M))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% figure(103)
% plot(log10(k2a),real(CCC11009H))
% hold on
% plot(log10(k2a),real(CCC22009H))
% hold on
% plot(log10(k2a),real(CCC66009H))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
figure(104)
plot(log10(k2a),real(CCC11009L))
hold on
plot(log10(k2a),real(CCC11009M))
hold on
plot(log10(k2a),real(CCC11009H))
legend('C11L','C11M','C11H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(105)
plot(log10(k2a),real(CCC22009L))
hold on
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22009H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(106)
plot(log10(k2a),real(CCC66009L))
hold on
plot(log10(k2a),real(CCC66009M))
hold on
plot(log10(k2a),real(CCC66009H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
%%
%Attenuation
% figure(107)
% plot(log10(k2a),log10(Q1C11009L))
% hold on
% plot(log10(k2a),log10(Q1C22009L))
% hold on
% plot(log10(k2a),log10(Q1C66009L))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %
% figure(108)
% plot(log10(k2a),log10(Q1C11009M))
% hold on
% plot(log10(k2a),log10(Q1C22009M))
% hold on
% plot(log10(k2a),log10(Q1C66009M))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %
% figure(109)
% plot(log10(k2a),log10(Q1C11009H))
% hold on
% plot(log10(k2a),log10(Q1C22009H))
% hold on
% plot(log10(k2a),log10(Q1C66009H))
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
%%
%plot Velocity
% figure(110)
% plot(log10(k2a),Vp10001L)
% hold on
% plot(log10(k2a),Vp10002L)
% hold on
% plot(log10(k2a),Vp10003L)
% legend('0','pi/4','pi/2')
% xlabel('Frequency (Log(k2a))')
% ylabel('Velocity')
% figure(111)
% plot(log10(k2a),log10(Qp10001H))
% hold on
% plot(log10(k2a),log10(Qp10002H))
% hold on
% plot(log10(k2a),log10(Qp10003H))
% legend('0','pi/4','pi/2')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
%%
%Plot the variation of compliance  of the fracture
figure(112)
plot(STPRE009,ZCRACK009)
hold on
plot(STPRE012,ZCRACK012)
hold on
plot(STPRE015,ZCRACK015)
hold on
plot(STPRE018,ZCRACK018)
% hold on
% plot(STPRE100,ZCRACK100)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('Compliance (GPa^-1)')
close all
figure(113)
plot(STPRE009,C220090)
hold on
plot(STPRE012,C220120)
hold on
plot(STPRE015,C220150)
hold on
plot(STPRE018,C220180)
% hold on
% plot(STPRE100,C221000)
%legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(114)
plot(STPRE009,C660090)
hold on
plot(STPRE012,C660120)
hold on
plot(STPRE015,C660150)
hold on
plot(STPRE018,C660180)
% hold on
% plot(STPRE100,C661000)
%legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
figure(115)
plot(STPRE009,C22009H)
hold on
plot(STPRE012,C22012H)
hold on
plot(STPRE015,C22015H)
hold on
plot(STPRE018,C22018H)
% hold on
% plot(STPRE100,C22100H)
%legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(116)
plot(STPRE009,C66009H)
hold on
plot(STPRE012,C66012H)
hold on
plot(STPRE015,C66015H)
hold on
plot(STPRE018,C66018H)
% hold on
% plot(STPRE100,C66100H)
%legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
%PREEX = (1:0.1:15);%The Pressure for simulation
%low frequency
%P-wave
%Standard deviation = 0.09 um
%High pressure
TOE0090HP = polyfit(STPRE009(4:8),C220090(4:8),1);
C220090TOHP = polyval(TOE0090HP,STPRE009);
COC220090HP = min(min(corrcoef(C220090, C220090TOHP)));
%Low pressure
TOE0090LP = polyfit(STPRE009(1:3),C220090(1:3),1);
C220090TOLP = polyval(TOE0090LP,STPRE009);
COC220090LP = min(min(corrcoef(C220090, C220090TOLP)));
%%
%Standard deviation = 0.12 um
%High pressure
TOE0120HP = polyfit(STPRE012(4:8),C220120(4:8),1);
C220120TOHP = polyval(TOE0120HP,STPRE012);
COC220120HP = min(min(corrcoef(C220120, C220120TOHP)));
%Low pressure
TOE0120LP = polyfit(STPRE012(1:3),C220120(1:3),1);
C220120TOLP = polyval(TOE0120LP,STPRE012);
COC220120LP = min(min(corrcoef(C220120, C220120TOLP)));
%%
%Standard deviation = 0.15 um
%High pressure
TOE0150HP = polyfit(STPRE015(4:8),C220150(4:8),1);
C220150TOHP = polyval(TOE0150HP,STPRE015);
COC220150HP = min(min(corrcoef(C220150, C220150TOHP)));
%Low pressure
TOE0150LP = polyfit(STPRE015(1:3),C220150(1:3),1);
C220150TOLP = polyval(TOE0150LP,STPRE015);
COC220150LP = min(min(corrcoef(C220150, C220150TOLP)));
%%
%Standard deviation = 0.18 um
%High pressure
TOE0180HP = polyfit(STPRE018(4:8),C220180(4:8),1);
C220180TOHP = polyval(TOE0180HP,STPRE018);
COC220180HP = min(min(corrcoef(C220180, C220180TOHP)));
%Low pressure
TOE0180LP = polyfit(STPRE018(1:3),C220180(1:3),1);
C220180TOLP = polyval(TOE0180LP,STPRE018);
COC220180LP = min(min(corrcoef(C220180, C220180TOLP)));
% %Autocorrelation length = 100 um
% TOE1000 = polyfit(STPRE100,C221000,1);
% C221000TO = polyval(TOE1000,STPRE100);
% COC221000 = min(min(corrcoef(C221000, C221000TO)));
%%
%S-wave-Axial
%low frequency
%Standard deviation = 0.09 um
%High pressure
TOES0090HP = polyfit(STPRE009(4:8),C660090(4:8),1);
C660090TOHP = polyval(TOES0090HP,STPRE009);
COC66009HP = min(min(corrcoef(C660090, C660090TOHP)));
%Low pressure
TOES0090LP = polyfit(STPRE009(1:3),C660090(1:3),1);
C660090TOLP = polyval(TOES0090LP,STPRE009);
COC66009LP = min(min(corrcoef(C660090, C660090TOLP)));
%%
%Standard deviation = 0.12 um
%High pressure
TOES0120HP = polyfit(STPRE012(4:8),C660120(4:8),1);
C660120TOHP = polyval(TOES0120HP,STPRE012);
COC66012HP = min(min(corrcoef(C660120, C660120TOHP)));
%Low pressure
TOES0120LP = polyfit(STPRE012(1:3),C660120(1:3),1);
C660120TOLP = polyval(TOES0120LP,STPRE012);
COC66012LP = min(min(corrcoef(C660120, C660120TOLP)));
%%
%Standard deviation length = 0.15 um
%High pressure
TOES0150HP = polyfit(STPRE015(4:8),C660150(4:8),1);
C660150TOHP = polyval(TOES0150HP,STPRE015);
COC66015HP = min(min(corrcoef(C660150, C660150TOHP)));
%Low pressure
TOES0150LP = polyfit(STPRE015(1:3),C660150(1:3),1);
C660150TOLP = polyval(TOES0150LP,STPRE015);
COC66015LP = min(min(corrcoef(C660150, C660150TOLP)));
%%
%Standard deviation = 0.18 um
%High pressure
TOES0180HP = polyfit(STPRE018(4:8),C660180(4:8),1);
C660180TOHP = polyval(TOES0180HP,STPRE018);
COC66018HP = min(min(corrcoef(C660180, C660180TOHP)));
%Low pressure
TOES0180LP = polyfit(STPRE018(1:3),C660180(1:3),1);
C660180TOLP = polyval(TOES0180LP,STPRE018);
COC66018LP = min(min(corrcoef(C660180, C660180TOLP)));
% %Autocorrelation length = 100 um
% TOES1000 = polyfit(STPRE100,C661000,1);
% C661000TO = polyval(TOES1000,STPRE100);
% COC66100 = min(min(corrcoef(C661000, C661000TO)));
%%
%High frequency
%P-wave
%Standard deviation = 0.09 um
%High pressure
TOE009HHP = polyfit(STPRE009(4:8),C22009H(4:8),1);
C22009HTOHP = polyval(TOE009HHP,STPRE009);
COC22009HHP = min(min(corrcoef(C22009H, C22009HTOHP)));
%Low pressure
TOE009HLP = polyfit(STPRE009(1:3),C22009H(1:3),1);
C22009HTOLP = polyval(TOE009HLP,STPRE009);
COC22009HLP = min(min(corrcoef(C22009H, C22009HTOLP)));
%%
%Standard deviation = 0.12 um
%High pressure
TOE012HHP = polyfit(STPRE012(4:8),C22012H(4:8),1);
C22012HTOHP = polyval(TOE012HHP,STPRE012);
COC22012HHP = min(min(corrcoef(C22012H, C22012HTOHP)));
%Low pressure
TOE012HLP = polyfit(STPRE012(1:3),C22012H(1:3),1);
C22012HTOLP = polyval(TOE012HLP,STPRE012);
COC22012HLP = min(min(corrcoef(C22012H, C22012HTOLP)));
%%
%Standard deviation = 0.15 um
%High pressure
TOE015HHP = polyfit(STPRE015(4:8),C22015H(4:8),1);
C22015HTOHP = polyval(TOE015HHP,STPRE015);
COC22015HHP = min(min(corrcoef(C22015H, C22015HTOHP)));
%Low pressure
TOE015HLP = polyfit(STPRE015(1:3),C22015H(1:3),1);
C22015HTOLP = polyval(TOE015HLP,STPRE015);
COC22015HLP = min(min(corrcoef(C22015H, C22015HTOLP)));
%%
%Standard deviation = 0.18 um
%High pressure
TOE018HHP = polyfit(STPRE018(4:8),C22018H(4:8),1);
C22018HTOHP = polyval(TOE018HHP,STPRE018);
COC22018HHP = min(min(corrcoef(C22018H, C22018HTOHP)));
%Low pressure
TOE018HLP = polyfit(STPRE018(1:3),C22018H(1:3),1);
C22018HTOLP = polyval(TOE018HLP,STPRE018);
COC22018HLP = min(min(corrcoef(C22018H, C22018HTOLP)));
% TOE100H = polyfit(STPRE100,C22100H,1);
% C22100HTO = polyval(TOE100H,STPRE100);
% COC22100H = min(min(corrcoef(C22100H, C22100HTO)));
%%
%S-wave-Axial
%low frequency
%Standard deviation = 0.09 um
%High pressure
TOES009HHP = polyfit(STPRE009(4:8),C66009H(4:8),1);
C66009HTOHP = polyval(TOES009HHP,STPRE009);
COC66009HHP = min(min(corrcoef(C66009H, C66009HTOHP)));
%Low pressure
TOES009HLP = polyfit(STPRE009(1:3),C66009H(1:3),1);
C66009HTOLP = polyval(TOES009HLP,STPRE009);
COC66009HLP = min(min(corrcoef(C66009H, C66009HTOLP)));
%%
%Standard deviation = 0.12 um
%High pressure
TOES012HHP = polyfit(STPRE012(4:8),C66012H(4:8),1);
C66012HTOHP = polyval(TOES012HHP,STPRE012);
COC66012HHP = min(min(corrcoef(C66012H, C66012HTOHP)));
%Low pressure
TOES012HLP = polyfit(STPRE012(1:3),C66012H(1:3),1);
C66012HTOLP = polyval(TOES012HLP,STPRE012);
COC66012HLP = min(min(corrcoef(C66012H, C66012HTOLP)));
%%
%Standard deviaion = 0.15 um
%High pressure
TOES015HHP = polyfit(STPRE015(4:8),C66015H(4:8),1);
C66015HTOHP = polyval(TOES015HHP,STPRE015);
COC66015HHP = min(min(corrcoef(C66015H, C66015HTOHP)));
%Low pressure
TOES015HLP = polyfit(STPRE015(1:3),C66015H(1:3),1);
C66015HTOLP = polyval(TOES015HLP,STPRE015);
COC66015HLP = min(min(corrcoef(C66015H, C66015HTOLP)));
%%
%Standard deviation = 0.18 um
%High pressure
TOES018HHP = polyfit(STPRE018(4:8),C66018H(4:8),1);
C66018HTOHP = polyval(TOES018HHP,STPRE018);
COC66018HHP = min(min(corrcoef(C66018H, C66018HTOHP)));
%Low pressure
TOES018HLP = polyfit(STPRE018(1:3),C66018H(1:3),1);
C66018HTOLP = polyval(TOES018HLP,STPRE018);
COC66018HLP = min(min(corrcoef(C66018H, C66018HTOLP)));
%%
% %Autocorrelation length = 100 um
% TOES100H = polyfit(STPRE100,C66100H,1);
% C66100HTO = polyval(TOES100H,STPRE100);
% COC66100H = min(min(corrcoef(C66100H, C66100HTO)));
%%

SD = [0.09 0.12 0.15 0.18];%Autocorrelation length
%Low pressure 0-40MPa
LP = [40 40 40 40];
%High pressure 50-90MPa
HP = [90 90 90 90];
%Pressure point
PP = [40 90];
[SSD,PPD] = meshgrid(SD,PP);
%High pressure
TOELFHP = 1000.*[TOE0090HP(1) TOE0120HP(1) TOE0150HP(1) TOE0180HP(1)];
TOEHFHP = 1000.*[TOE009HHP(1) TOE012HHP(1) TOE015HHP(1) TOE018HHP(1)];
TOESLFHP = 1000.*[TOES0090HP(1) TOES0120HP(1) TOES0150HP(1) TOES0180HP(1)];
TOESHFHP = 1000.*[TOES009HHP(1) TOES012HHP(1) TOES015HHP(1) TOES018HHP(1)];
%Low pressure
TOELFLP = 1000.*[TOE0090LP(1) TOE0120LP(1) TOE0150LP(1) TOE0180LP(1)];
TOEHFLP = 1000.*[TOE009HLP(1) TOE012HLP(1) TOE015HLP(1) TOE018HLP(1)];
TOESLFLP = 1000.*[TOES0090LP(1) TOES0120LP(1) TOES0150LP(1) TOES0180LP(1)];
TOESHFLP = 1000.*[TOES009HLP(1) TOES012HLP(1) TOES015HLP(1) TOES018HLP(1)];
%%
%Model the 3oECs
%Low frequency
TOELF = [TOELFLP
    TOELFHP];
TOESLF = [TOESLFLP
    TOESLFHP];
%%
%High frequency
TOEHF = [TOEHFLP
    TOEHFHP];
TOESHF = [TOESHFLP
    TOESHFHP];
%%
figure(117)
plot(SD,TOELFHP)
hold on
plot(SD,TOEHFHP)
legend('Low-frequency','High-frequency')
xlabel('SSD (um)')
ylabel('3oECs')
figure(118)
plot(SD,TOESLFHP)
hold on
plot(SD,TOESHFHP)
legend('Low-frequency','High-frequency')
xlabel('SSD (um)')
ylabel('3oECs')
%%
%close all
%deal with the dispersion and attenuation
figure(119)
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22012M))
hold on
plot(log10(k2a),real(CCC22015M))
hold on
plot(log10(k2a),real(CCC22018M))
% hold on
% plot(log10(k2a),real(CCC22100L))
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(120)
plot(log10(k2a),log10(Q1C22009M))
hold on
plot(log10(k2a),log10(Q1C22012M))
hold on
plot(log10(k2a),log10(Q1C22015M))
hold on
plot(log10(k2a),log10(Q1C22018M))
% hold on
% plot(log10(k2a),log10(Q1C22100L))
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%deal with the dispersion and attenuation
% figure(121)
% plot(log10(k2a),real(CCC11009L))
% hold on
% plot(log10(k2a),real(CCC11012L))
% hold on
% plot(log10(k2a),real(CCC11015L))
% hold on
% plot(log10(k2a),real(CCC11018L))
% % hold on
% % plot(log10(k2a),real(CCC11100L))
% legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('P-wave modulus (GPa)')
% %
% figure(122)
% plot(log10(k2a),log10(Q1C11009L))
% hold on
% plot(log10(k2a),log10(Q1C11012L))
% hold on
% plot(log10(k2a),log10(Q1C11015L))
% hold on
% plot(log10(k2a),log10(Q1C11018L))
% % hold on
% % plot(log10(k2a),log10(Q1C11100L))
% legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('Attenuation (Log)')
%%
%deal with the dispersion and attenuation
% figure(123)
% plot(log10(k2a),real(CCC45009L./2))
% hold on
% plot(log10(k2a),real(CCC45012L./2))
% hold on
% plot(log10(k2a),real(CCC45015L./2))
% hold on
% plot(log10(k2a),real(CCC45018L./2))
% hold on
% plot(log10(k2a),real(CCC45100L./2))
% legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('P-wave modulus (GPa)')
% %
% figure(124)
% plot(log10(k2a),log10(Q1C45009L))
% hold on
% plot(log10(k2a),log10(Q1C45012L))
% hold on
% plot(log10(k2a),log10(Q1C45015L))
% hold on
% plot(log10(k2a),log10(Q1C45018L))
% hold on
% plot(log10(k2a),log10(Q1C45100L))
% legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('Attenuation (Log)')
%%
%the attenuation and dispersion for different surface
figure(125)
plot(log10(k2a),real(CCC22009L))
hold on
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22009H))
legend('Confining pressure 0MPa','Confining pressure 70MPa','Confining pressure 90MPa')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(126)
plot(log10(k2a),log10(Q1C22009L))
hold on
plot(log10(k2a),log10(Q1C22009M))
hold on
plot(log10(k2a),log10(Q1C22009H))
legend('Confining pressure 0MPa','Confining pressure 70MPa','Confining pressure 90MPa')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%the attenuation and dispersion for different surface
figure(127)
plot(log10(k2a),real(CCC22018L))
hold on
plot(log10(k2a),real(CCC22018M))
hold on
plot(log10(k2a),real(CCC22018H))
legend('Confining pressure 0MPa','Confining pressure 70MPa','Confining pressure 90MPa')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(128)
plot(log10(k2a),log10(Q1C22018L))
hold on
plot(log10(k2a),log10(Q1C22018M))
hold on
plot(log10(k2a),log10(Q1C22018H))
legend('Confining pressure 0MPa','Confining pressure 70MPa','Confining pressure 90MPa')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
% %Anisotropy
% figure(129)
% plot(log10(k2a),real(epxl009L))
% hold on
% plot(log10(k2a),real(deltaV009L))
% % hold on
% % plot(log10(k2a),real(epxl020L))
% % hold on
% % plot(log10(k2a),real(deltaV020L))
% % hold on
% % plot(log10(k2a),real(epxl050L))
% % hold on
% % plot(log10(k2a),real(deltaV050L))
% legend('eee','ddd')
% xlabel('log10(k2a)')
% ylabel('Anisotropy')
%%

%%
%the dispersion of third-order elastic constant
%low SD = 0.09um
cita009 = (C22009H-C220090).^3./(2.*C22009H.*(C220090.^2).*T009.*(G009.^2));
tao009 = ((C22009H-C220090)./(C220090.*G009)).^2;
fw009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
fw009(i,:) = (1-cita009(i)+cita009(i).*sqrt(1-I.*OMI.*tao009(i)./cita009(i).^2));
end
%%
%C22
CCC22009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC22009(i,:) = C22009H(i)./(1+((C22009H(i)-C220090(i))./C220090(i))./fw009(i,:));
end
Q1C22009 = abs(imag(CCC22009)./real(CCC22009));
CC22009 = real(CCC22009);
TOE22009LP = zeros(1,length(OMI));
TOE22009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22009MLP = polyfit(STPRE009(1:3),CC22009(1:3,i),1);
TOE22009LP(i) = 1000.*TOE22009MLP(1);
TOE22009MHP = polyfit(STPRE009(4:8),CC22009(4:8,i),1);
TOE22009HP(i) = 1000.*TOE22009MHP(1);
end
%%
%C11
CCC11009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC11009(i,:) = C11009H(i)./(1+((C11009H(i)-C110090(i))./C110090(i))./fw009(i,:));
end
Q1C11009 = abs(imag(CCC11009)./real(CCC11009));
CC11009 = real(CCC11009);
TOE11009LP = zeros(1,length(OMI));
TOE11009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE11009MLP = polyfit(STPRE009(1:3),CC11009(1:3,i),1);
TOE11009LP(i) = 1000.*TOE11009MLP(1);
TOE11009MHP = polyfit(STPRE009(4:8),CC11009(4:8,i),1);
TOE11009HP(i) = 1000.*TOE11009MHP(1);
end
%%
%C12
CCC12009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC12009(i,:) = C12009H(i)./(1+((C12009H(i)-C120090(i))./C120090(i))./fw009(i,:));
end
Q1C12009 = abs(imag(CCC12009)./real(CCC12009));
CC12009 = real(CCC12009);
TOE12009LP = zeros(1,length(OMI));
TOE12009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE12009MLP = polyfit(STPRE009(1:3),CC12009(1:3,i),1);
TOE12009LP(i) = 1000.*TOE12009MLP(1);
TOE12009MHP = polyfit(STPRE009(4:8),CC12009(4:8,i),1);
TOE12009HP(i) = 1000.*TOE12009MHP(1);
end
%%
%C45
CCC45009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC45009(i,:) = C45009H(i)./(1+((C45009H(i)-C450090(i))./C450090(i))./fw009(i,:));
end
Q1C45009 = abs(imag(CCC45009)./real(CCC45009));
CC45009 = real(CCC45009);
TOE45009LP = zeros(1,length(OMI));
TOE45009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE45009MLP = polyfit(STPRE009(1:3),CC45009(1:3,i)./2,1);
TOE45009LP(i) = 1000.*TOE45009MLP(1);
TOE45009MHP = polyfit(STPRE009(4:8),CC45009(4:8,i)./2,1);
TOE45009HP(i) = 1000.*TOE45009MHP(1);
end
%%
%C66
CCC66009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC66009(i,:) = C66009H(i)./(1+((C66009H(i)-C660090(i))./C660090(i))./fw009(i,:));
end
Q1C66009 = abs(imag(CCC66009)./real(CCC66009));
CC66009 = real(CCC66009);
TOE66009LP = zeros(1,length(OMI));
TOE66009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66009MLP = polyfit(STPRE009(1:3),CC66009(1:3,i),1);
TOE66009LP(i) = 1000.*TOE66009MLP(1);
TOE66009MHP = polyfit(STPRE009(4:8),CC66009(4:8,i),1);
TOE66009HP(i) = 1000.*TOE66009MHP(1);
end
epsl009 = real(CCC11009-CCC22009)./(2.*real(CCC22009));
deltaVV009 = (real(CCC12009+CCC66009).^2-real(CCC22009-CCC66009).^2)./(2.*real(CCC22009).*real(CCC22009-CCC66009));
%%
%the dispersion of third-order elastic constant
%low SD = 0.12um
cita012 = (C22012H-C220120).^3./(2.*C22012H.*C220120.^2.*T012.*G012.^2);
tao012 = ((C22012H-C220120)./C220120./G012).^2;
fw012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
fw012(i,:) = (1-cita012(i)+cita012(i).*sqrt(1-sqrt(-1).*OMI.*tao012(i)./cita012(i).^2));
end
%%
%C22
CCC22012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC22012(i,:) = C22012H(i)./(1+((C22012H(i)-C220120(i))./C220120(i))./fw012(i,:));
end
Q1C22012 = abs(imag(CCC22012)./real(CCC22012));
CC22012 = real(CCC22012);
TOE22012LP = zeros(1,length(OMI));
TOE22012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22012MLP = polyfit(STPRE012(1:3),CC22012(1:3,i),1);
TOE22012LP(i) = 1000.*TOE22012MLP(1);
TOE22012MHP = polyfit(STPRE012(4:8),CC22012(4:8,i),1);
TOE22012HP(i) = 1000.*TOE22012MHP(1);
end
%%
%C11
CCC11012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC11012(i,:) = C11012H(i)./(1+((C11012H(i)-C110120(i))./C110120(i))./fw012(i,:));
end
Q1C11012 = abs(imag(CCC11012)./real(CCC11012));
CC11012 = real(CCC11012);
TOE11012LP = zeros(1,length(OMI));
TOE11012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE11012MLP = polyfit(STPRE012(1:3),CC11012(1:3,i),1);
TOE11012LP(i) = 1000.*TOE11012MLP(1);
TOE11012MHP = polyfit(STPRE012(4:8),CC11012(4:8,i),1);
TOE11012HP(i) = 1000.*TOE11012MHP(1);
end
%%
%C12
CCC12012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC12012(i,:) = C12012H(i)./(1+((C12012H(i)-C120120(i))./C120120(i))./fw012(i,:));
end
Q1C12012 = abs(imag(CCC12012)./real(CCC12012));
CC12012 = real(CCC12012);
TOE12012LP = zeros(1,length(OMI));
TOE12012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE12012MLP = polyfit(STPRE012(1:3),CC12012(1:3,i),1);
TOE12012LP(i) = 1000.*TOE12012MLP(1);
TOE12012MHP = polyfit(STPRE012(4:8),CC12012(4:8,i),1);
TOE12012HP(i) = 1000.*TOE12012MHP(1);
end
%%
%C45
CCC45012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC45012(i,:) = C45012H(i)./(1+((C45012H(i)-C450120(i))./C450120(i))./fw012(i,:));
end
Q1C45012 = abs(imag(CCC45012)./real(CCC45012));
CC45012 = real(CCC45012);
TOE45012LP = zeros(1,length(OMI));
TOE45012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE45012MLP = polyfit(STPRE012(1:3),CC45012(1:3,i)./2,1);
TOE45012LP(i) = 1000.*TOE45012MLP(1);
TOE45012MHP = polyfit(STPRE012(4:8),CC45012(4:8,i)./2,1);
TOE45012HP(i) = 1000.*TOE45012MHP(1);
end
%%
%C66
CCC66012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC66012(i,:) = C66012H(i)./(1+((C66012H(i)-C660120(i))./C660120(i))./fw012(i,:));
end
Q1C66012 = abs(imag(CCC66012)./real(CCC66012));
CC66012 = real(CCC66012);
TOE66012LP = zeros(1,length(OMI));
TOE66012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66012MLP = polyfit(STPRE012(1:3),CC66012(1:3,i),1);
TOE66012LP(i) = 1000.*TOE66012MLP(1);
TOE66012MHP = polyfit(STPRE012(4:8),CC66012(4:8,i),1);
TOE66012HP(i) = 1000.*TOE66012MHP(1);
end
epsl012 = real(CCC11012-CCC22012)./(2.*real(CCC22012));
deltaVV012 = (real(CCC12012+CCC66012).^2-real(CCC22012-CCC66012).^2)./(2.*real(CCC22012).*real(CCC22012-CCC66012));
%%
%the dispersion of third-order elastic constant
%low SD = 0.15um
cita015 = (C22015H-C220150).^3./(2.*C22015H.*C220150.^2.*T015.*G015.^2);
tao015 = ((C22015H-C220150)./C220150./G015).^2;
fw015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
fw015(i,:) = (1-cita015(i)+cita015(i).*sqrt(1-sqrt(-1).*OMI.*tao015(i)./cita015(i).^2));
end
%%
%C22
CCC22015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC22015(i,:) = C22015H(i)./(1+((C22015H(i)-C220150(i))./C220150(i))./fw015(i,:));
end
Q1C22015 = abs(imag(CCC22015)./real(CCC22015));
CC22015 = real(CCC22015);
TOE22015LP = zeros(1,length(OMI));
TOE22015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22015MLP = polyfit(STPRE015(1:3),CC22015(1:3,i),1);
TOE22015LP(i) = 1000.*TOE22015MLP(1);
TOE22015MHP = polyfit(STPRE015(4:8),CC22015(4:8,i),1);
TOE22015HP(i) = 1000.*TOE22015MHP(1);
end
%%
%C11
CCC11015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC11015(i,:) = C11015H(i)./(1+((C11015H(i)-C110150(i))./C110150(i))./fw015(i,:));
end
Q1C11015 = abs(imag(CCC11015)./real(CCC11015));
CC11015 = real(CCC11015);
TOE11015LP = zeros(1,length(OMI));
TOE11015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE11015MLP = polyfit(STPRE015(1:3),CC11015(1:3,i),1);
TOE11015LP(i) = 1000.*TOE11015MLP(1);
TOE11015MHP = polyfit(STPRE015(4:8),CC11015(4:8,i),1);
TOE11015HP(i) = 1000.*TOE11015MHP(1);
end
%%
%C12
CCC12015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC12015(i,:) = C12015H(i)./(1+((C12015H(i)-C120150(i))./C120150(i))./fw015(i,:));
end
Q1C12015 = abs(imag(CCC12015)./real(CCC12015));
CC12015 = real(CCC12015);
TOE12015LP = zeros(1,length(OMI));
TOE12015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE12015MLP = polyfit(STPRE015(1:3),CC12015(1:3,i),1);
TOE12015LP(i) = 1000.*TOE12015MLP(1);
TOE12015MHP = polyfit(STPRE015(4:8),CC12015(4:8,i),1);
TOE12015HP(i) = 1000.*TOE12015MHP(1);
end
%%
%C45
CCC45015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC45015(i,:) = C45015H(i)./(1+((C45015H(i)-C450150(i))./C450150(i))./fw015(i,:));
end
Q1C45015 = abs(imag(CCC45015)./real(CCC45015));
CC45015 = real(CCC45015);
TOE45015LP = zeros(1,length(OMI));
TOE45015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE45015MLP = polyfit(STPRE015(1:3),CC45015(1:3,i)./2,1);
TOE45015LP(i) = 1000.*TOE45015MLP(1);
TOE45015MHP = polyfit(STPRE015(4:8),CC45015(4:8,i)./2,1);
TOE45015HP(i) = 1000.*TOE45015MHP(1);
end
%%
%C66
CCC66015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC66015(i,:) = C66015H(i)./(1+((C66015H(i)-C660150(i))./C660150(i))./fw015(i,:));
end
Q1C66015 = abs(imag(CCC66015)./real(CCC66015));
CC66015 = real(CCC66015);
TOE66015LP = zeros(1,length(OMI));
TOE66015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66015MLP = polyfit(STPRE015(1:3),CC66015(1:3,i),1);
TOE66015LP(i) = 1000.*TOE66015MLP(1);
TOE66015MHP = polyfit(STPRE015(4:8),CC66015(4:8,i),1);
TOE66015HP(i) = 1000.*TOE66015MHP(1);
end
epsl015 = real(CCC11015-CCC22015)./(2.*real(CCC22015));
deltaVV015 = (real(CCC12015+CCC66015).^2-real(CCC22015-CCC66015).^2)./(2.*real(CCC22015).*real(CCC22015-CCC66015));
%%
%the dispersion of third-order elastic constant
%low SD = 0.18um
cita018 = (C22018H-C220180).^3./(2.*C22018H.*C220180.^2.*T018.*G018.^2);
tao018 = ((C22018H-C220180)./C220180./G018).^2;
fw018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
fw018(i,:) = (1-cita018(i)+cita018(i).*sqrt(1-sqrt(-1).*OMI.*tao018(i)./cita018(i).^2));
end
%%
%C22
CCC22018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
CCC22018(i,:) = C22018H(i)./(1+((C22018H(i)-C220180(i))./C220180(i))./fw018(i,:));
end
Q1C22018 = abs(imag(CCC22018)./real(CCC22018));
CC22018 = real(CCC22018);
TOE22018LP = zeros(1,length(OMI));
TOE22018HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22018MLP = polyfit(STPRE018(1:3),CC22018(1:3,i),1);
TOE22018LP(i) = 1000.*TOE22018MLP(1);
TOE22018MHP = polyfit(STPRE018(4:8),CC22018(4:8,i),1);
TOE22018HP(i) = 1000.*TOE22018MHP(1);
end
%%
%C11
CCC11018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
CCC11018(i,:) = C11018H(i)./(1+((C11018H(i)-C110180(i))./C110180(i))./fw018(i,:));
end
Q1C11018 = abs(imag(CCC11018)./real(CCC11018));
CC11018 = real(CCC11018);
TOE11018LP = zeros(1,length(OMI));
TOE11018HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE11018MLP = polyfit(STPRE018(1:3),CC11018(1:3,i),1);
TOE11018LP(i) = 1000.*TOE11018MLP(1);
TOE11018MHP = polyfit(STPRE018(4:8),CC11018(4:8,i),1);
TOE11018HP(i) = 1000.*TOE11018MHP(1);
end
%%
%C12
CCC12018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
CCC12018(i,:) = C12018H(i)./(1+((C12018H(i)-C120180(i))./C120180(i))./fw018(i,:));
end
Q1C12018 = abs(imag(CCC12018)./real(CCC12018));
CC12018 = real(CCC12018);
TOE12018LP = zeros(1,length(OMI));
TOE12018HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE12018MLP = polyfit(STPRE018(1:3),CC11018(1:3,i),1);
TOE12018LP(i) = 1000.*TOE12018MLP(1);
TOE12018MHP = polyfit(STPRE018(4:8),CC11018(4:8,i),1);
TOE12018HP(i) = 1000.*TOE12018MHP(1);
end
%%
%C45
CCC45018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
CCC45018(i,:) = C45018H(i)./(1+((C45018H(i)-C450180(i))./C450180(i))./fw018(i,:));
end
Q1C45018 = abs(imag(CCC45018)./real(CCC45018));
CC45018 = real(CCC45018);
TOE45018LP = zeros(1,length(OMI));
TOE45018HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE45018MLP = polyfit(STPRE018(1:3),CC45018(1:3,i)./2,1);
TOE45018LP(i) = 1000.*TOE45018MLP(1);
TOE45018MHP = polyfit(STPRE018(4:8),CC45018(4:8,i)./2,1);
TOE45018HP(i) = 1000.*TOE45018MHP(1);
end
%%
%C66
% CCC66018 = zeros(length(STCRACK018),length(OMI));
% for i = 1:length(STCRACK018)
% CCC66018(i,:) = C66018H(i)./(1+((C66018H(i)-C660180(i))./C660180(i))./fw018(i,:));
% end
% Q1C66018 = abs(imag(CCC66018)./real(CCC66018));
% CC66018 = real(CCC66018);
% TOE66018 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE66018M = polyfit(STPRE018,CC66018(:,i),1);
% TOE66018(i) = 1000.*TOE66018M(1);
% end
% epsl018 = real(CCC11018-CCC22018)./(2.*real(CCC22018));
% deltaVV018 = (real(CCC12018+CCC66018).^2-real(CCC22018-CCC66018).^2)./(2.*real(CCC22018).*real(CCC22018-CCC66018));
% %%
% % the dispersion of third-order elastic constant
% % low Aut L = 100um
% % cita100 = (C22100H-C221000).^3./(2.*C22100H.*C221000.^2.*T100.*G100.^2);
% % tao100 = ((C22100H-C221000)./C221000./G100).^2;
% % fw100 = zeros(length(STCRACK100),length(OMI));
% % for i = 1:length(STCRACK100)
% % fw100(i,:) = (1-cita100(i)+cita100(i).*sqrt(1-sqrt(-1).*OMI.*tao100(i)./cita100(i).^2));
% % end
% %%
% %C22
% CCC22100 = zeros(length(STCRACK100),length(OMI));
% for i = 1:length(STCRACK100)
% CCC22100(i,:) = C22100H(i)./(1+((C22100H(i)-C221000(i))./C221000(i))./fw100(i,:));
% end
% Q1C22100 = abs(imag(CCC22100)./real(CCC22100));
% CC22100 = real(CCC22100);
% TOE22100 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE22100M = polyfit(STPRE100,CC22100(:,i),1);
% TOE22100(i) = 1000.*TOE22100M(1);
% end
% %%
% %C11
% CCC11100 = zeros(length(STCRACK100),length(OMI));
% for i = 1:length(STCRACK100)
% CCC11100(i,:) = C11100H(i)./(1+((C11100H(i)-C111000(i))./C111000(i))./fw100(i,:));
% end
% Q1C11100 = abs(imag(CCC11100)./real(CCC11100));
% CC11100 = real(CCC11100);
% TOE11100 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE11100M = polyfit(STPRE100,CC11100(:,i),1);
% TOE11100(i) = 1000.*TOE11100M(1);
% end
% %%
% %C12
% CCC12100 = zeros(length(STCRACK100),length(OMI));
% for i = 1:length(STCRACK100)
% CCC12100(i,:) = C12100H(i)./(1+((C12100H(i)-C121000(i))./C121000(i))./fw100(i,:));
% end
% Q1C12100 = abs(imag(CCC12100)./real(CCC12100));
% CC12100 = real(CCC12100);
% TOE12100 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE12100M = polyfit(STPRE100,CC12100(:,i),1);
% TOE12100(i) = 1000.*TOE12100M(1);
% end
% %%
% %C45
% CCC45100 = zeros(length(STCRACK100),length(OMI));
% for i = 1:length(STCRACK100)
% CCC45100(i,:) = C45100H(i)./(1+((C45100H(i)-C451000(i))./C451000(i))./fw100(i,:));
% end
% Q1C45100 = abs(imag(CCC45100)./real(CCC45100));
% CC45100 = real(CCC45100);
% TOE45100 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE45100M = polyfit(STPRE100,CC45100(:,i)./2,1);
% TOE45100(i) = 1000.*TOE45100M(1);
% end
% %%
% %C66
% CCC66100 = zeros(length(STCRACK100),length(OMI));
% for i = 1:length(STCRACK100)
% CCC66100(i,:) = C66100H(i)./(1+((C66100H(i)-C661000(i))./C661000(i))./fw100(i,:));
% end
% Q1C66100 = abs(imag(CCC66100)./real(CCC66100));
% CC66100 = real(CCC66100);
% TOE66100 = zeros(1,length(OMI));
% for i = 1:length(OMI)
% TOE66100M = polyfit(STPRE100,CC66100(:,i),1);
% TOE66100(i) = 1000.*TOE66100M(1);
% end
% epsl100 = real(CCC11100-CCC22100)./(2.*real(CCC22100));
% deltaVV100 = (real(CCC12100+CCC66100).^2-real(CCC22100-CCC66100).^2)./(2.*real(CCC22100).*real(CCC22100-CCC66100));
%%
figure(130)
plot(log10(k2a),TOE22009LP)
hold on
plot(log10(k2a),TOE22012LP)
hold on
plot(log10(k2a),TOE22015LP)
hold on
plot(log10(k2a),TOE22018LP)
% hold on
% plot(log10(k2a),TOE22100)
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
ylabel('3oECs')
figure(1301)
plot(log10(k2a),TOE22009HP)
hold on
plot(log10(k2a),TOE22012HP)
hold on
plot(log10(k2a),TOE22015HP)
hold on
plot(log10(k2a),TOE22018HP)
% hold on
% plot(log10(k2a),TOE22100)
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
ylabel('3oECs')
% 
% %
% figure(131)
% plot(log10(k2a),real(CCC22001L))
% hold on
% plot(log10(k2a),real(CCC22001M))
% hold on
% plot(log10(k2a),real(CCC22001H))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('P-wave modulus (GPa)')
% figure(132)
% plot(log10(k2a),log10(Q1C22001L))
% hold on
% plot(log10(k2a),log10(Q1C22001M))
% hold on
% plot(log10(k2a),log10(Q1C22001H))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Attenuation (Log)')
% figure(133)
% plot(log10(k2a),real(CCC22050L))
% hold on
% plot(log10(k2a),real(CCC22050M))
% hold on
% plot(log10(k2a),real(CCC22050H))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('P-wave modulus (GPa)')
% figure(134)
% plot(log10(k2a),log10(Q1C22050L))
% hold on
% plot(log10(k2a),log10(Q1C22050M))
% hold on
% plot(log10(k2a),log10(Q1C22050H))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Attenuation (Log)')
figure(131)
plot(STPRE009,ZCRACK009)
hold on
plot(STPRE012,ZCRACK012)
hold on
plot(STPRE015,ZCRACK015)
hold on
plot(STPRE018,ZCRACK018)
% hold on
% plot(STPRE100,ZCRACK100)
legend('SSD = 0.09um','SSD = 0.12um','SSD = 0.15um','SSD = 0.18um')
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('Complinace (GPa^-1)')
% figure(132)
% plot(STPRE009,C220090)
% hold on
% plot(STPRE015,C220150)
% hold on
% plot(STPRE100,C221000)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(133)
% plot(STPRE009,C110090)
% hold on
% plot(STPRE015,C110150)
% hold on
% plot(STPRE100,C111000)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(134)
% plot(STPRE009,C450090./2)
% hold on
% plot(STPRE015,C450150./2)
% hold on
% plot(STPRE100,C451000./2)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(135)
% plot(STPRE009,C22009H)
% hold on
% plot(STPRE015,C22015H)
% hold on
% plot(STPRE100,C22100H)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(136)
% plot(STPRE009,C11009H)
% hold on
% plot(STPRE015,C11015H)
% hold on
% plot(STPRE100,C11100H)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(137)
% plot(STPRE009,C45009H./2)
% hold on
% plot(STPRE015,C45015H./2)
% hold on
% plot(STPRE100,C45100H./2)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('Pressure (MPa)')
% ylabel('Elastic modulus (GPa)')
% figure(138)
% plot(log10(k2a),CC22009(1,:))
% hold on
% plot(log10(k2a),CC22009(4,:))
% hold on
% plot(log10(k2a),CC22009(8,:))
% hold on
% plot(log10(k2a),CC45009(1,:)./2)
% hold on
% plot(log10(k2a),CC45009(4,:)./2)
% hold on
% plot(log10(k2a),CC45009(8,:)./2)
% hold on
% plot(log10(k2a),CC11009(1,:))
% hold on
% plot(log10(k2a),CC11009(4,:))
% hold on
% plot(log10(k2a),CC11009(8,:))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Elastic modulus (GPa)')
% figure(139)
% plot(log10(k2a),log10(Q1C22009(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C22009(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C22009(8,:)))
% hold on
% plot(log10(k2a),log10(Q1C45009(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C45009(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C45009(8,:)))
% hold on
% plot(log10(k2a),log10(Q1C11009(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C11009(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C11009(8,:)))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Attenuation')
% figure(140)
% plot(log10(k2a),CC22100(1,:))
% hold on
% plot(log10(k2a),CC22100(4,:))
% hold on
% plot(log10(k2a),CC22100(8,:))
% hold on
% plot(log10(k2a),CC45100(1,:)./2)
% hold on
% plot(log10(k2a),CC45100(4,:)./2)
% hold on
% plot(log10(k2a),CC45100(8,:)./2)
% hold on
% plot(log10(k2a),CC11100(1,:))
% hold on
% plot(log10(k2a),CC11100(4,:))
% hold on
% plot(log10(k2a),CC11100(8,:))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Elastic modulus (GPa)')
% figure(141)
% plot(log10(k2a),log10(Q1C22100(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C22100(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C22100(8,:)))
% hold on
% plot(log10(k2a),log10(Q1C45100(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C45100(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C45100(8,:)))
% hold on
% plot(log10(k2a),log10(Q1C11100(1,:)))
% hold on
% plot(log10(k2a),log10(Q1C11100(4,:)))
% hold on
% plot(log10(k2a),log10(Q1C11100(8,:)))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Attenuation')
%%
%Do fit again
%%
%C22 low frequency
%Autocorrelation length = 1 um
% TOE220010 = polyfit(STPRE009,C220090,1);
% C220090TO = polyval(TOE220010,STPRE009);
% COC220090 = min(min(corrcoef(C220090, C220090TO)));
% %Autocorrelation length = 20 um
% TOE220200 = polyfit(STPRE015,C220150,1);
% C220150TO = polyval(TOE220200,STPRE015);
% COC220150 = min(min(corrcoef(C220150, C220150TO)));
% %Autocorrelation length = 100 um
% TOE221000 = polyfit(STPRE100,C221000,1);
% C221000TO = polyval(TOE221000,STPRE100);
% COC221000 = min(min(corrcoef(C221000, C221000TO)));
% %C22 high frequency
% %Autocorrelation length = 1 um
% TOE22001H = polyfit(STPRE009,C22009H,1);
% C22009HTO = polyval(TOE22001H,STPRE009);
% COC22009H = min(min(corrcoef(C22009H, C22009HTO)));
% %Autocorrelation length = 20 um
% TOE22020H = polyfit(STPRE015,C22015H,1);
% C22015HTO = polyval(TOE22020H,STPRE015);
% COC22015H = min(min(corrcoef(C22015H, C22015HTO)));
% %Autocorrelation length = 100 um
% TOE22100H = polyfit(STPRE100,C22100H,1);
% C22100HTO = polyval(TOE22100H,STPRE100);
% COC22100H = min(min(corrcoef(C22100H, C22100HTO)));
% %%
% %C11 low frequency
% %Autocorrelation length = 1 um
% TOE110010 = polyfit(STPRE009,C110090,1);
% C110010TO = polyval(TOE110010,STPRE009);
% COC110010 = min(min(corrcoef(C110090, C110010TO)));
% %Autocorrelation length = 20 um
% TOE110200 = polyfit(STPRE015,C110150,1);
% C110200TO = polyval(TOE110200,STPRE015);
% COC110200 = min(min(corrcoef(C110150, C110200TO)));
% %Autocorrelation length = 100 um
% TOE111000 = polyfit(STPRE100,C111000,1);
% C111000TO = polyval(TOE111000,STPRE100);
% COC111000 = min(min(corrcoef(C111000, C111000TO)));
% %C11 high frequency
% %Autocorrelation length = 1 um
% TOE11001H = polyfit(STPRE009,C11009H,1);
% C11001HTO = polyval(TOE11001H,STPRE009);
% COC11001H = min(min(corrcoef(C11009H, C11001HTO)));
% %Autocorrelation length = 20 um
% TOE11020H = polyfit(STPRE015,C11015H,1);
% C11020HTO = polyval(TOE11020H,STPRE015);
% COC11020H = min(min(corrcoef(C11015H, C11020HTO)));
% %Autocorrelation length = 100 um
% TOE11100H = polyfit(STPRE100,C11100H,1);
% C11100HTO = polyval(TOE11100H,STPRE100);
% COC11100H = min(min(corrcoef(C11100H, C11100HTO)));
% %%
% %C45 low frequency
% %Autocorrelation length = 1 um
% TOE4520010 = polyfit(STPRE009,C450090./2,1);
% C4520010TO = polyval(TOE4520010,STPRE009);
% COC4520010 = min(min(corrcoef(C450090./2, C4520010TO)));
% %Autocorrelation length = 20 um
% TOE4520200 = polyfit(STPRE015,C450150./2,1);
% C4520200TO = polyval(TOE4520200,STPRE015);
% COC4520200 = min(min(corrcoef(C450150./2, C4520200TO)));
% %Autocorrelation length = 100 um
% TOE4521000 = polyfit(STPRE100,C451000./2,1);
% C4521000TO = polyval(TOE4521000,STPRE100);
% COC4521000 = min(min(corrcoef(C451000./2, C4521000TO)));
% %C45 high frequency
% %Autocorrelation length = 1 um
% TOE452001H = polyfit(STPRE009,C45009H./2,1);
% C452001HTO = polyval(TOE452001H,STPRE009);
% COC452001H = min(min(corrcoef(C45009H./2, C452001HTO)));
% %Autocorrelation length = 20 um
% TOE452020H = polyfit(STPRE015,C45015H./2,1);
% C452020HTO = polyval(TOE452020H,STPRE015);
% COC452020H = min(min(corrcoef(C45015H./2, C452020HTO)));
% %Autocorrelation length = 100 um
% TOE452100H = polyfit(STPRE100,C45100H./2,1);
% C452100HTO = polyval(TOE452100H,STPRE100);
% COC452100H = min(min(corrcoef(C45100H./2, C452100HTO)));
% %%
% %ToEC low frequency
% TOE220 = [TOE220010(1) TOE220200(1) TOE221000(1)];
% TOE110 = [TOE110010(1) TOE110200(1) TOE111000(1)];
% TOE4520 = [TOE4520010(1) TOE4520200(1) TOE4521000(1)];
% %ToEC High frequency
% TOE22H = [TOE22001H(1) TOE22020H(1) TOE22100H(1)];
% TOE11H = [TOE11001H(1) TOE11020H(1) TOE11100H(1)];
% TOE452H = [TOE452001H(1) TOE452020H(1) TOE452100H(1)];
% Auto = [1 20 100];
% %%
% %plot
% figure(142)
% plot(Auto,1000.*TOE220)
% hold on
% plot(Auto,1000.*TOE4520)
% hold on
% plot(Auto,1000.*TOE110)
% xlabel('Autocorrelation length (um)')
% ylabel('ToECs')
% legend('900','450','000')
% figure(143)
% plot(Auto,1000.*TOE22H)
% hold on
% plot(Auto,1000.*TOE452H)
% hold on
% plot(Auto,1000.*TOE11H)
% xlabel('Autocorrelation length (um)')
% ylabel('ToECs')
% legend('900','450','000')
% %%
% figure(144)
% plot(log10(k2a),TOE22009)
% hold on
% plot(log10(k2a),TOE22015)
% hold on
% plot(log10(k2a),TOE22100)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('ToECs')
% figure(145)
% plot(log10(k2a),TOE45009)
% hold on
% plot(log10(k2a),TOE45015)
% hold on
% plot(log10(k2a),TOE45100)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('ToECs')
% figure(146)
% plot(log10(k2a),TOE11009)
% hold on
% plot(log10(k2a),TOE11015)
% hold on
% plot(log10(k2a),TOE11100)
% legend('Autocorrelation length = 1um','Autocorrelation length = 20um','Autocorrelation length = 100um')
% xlabel('log10(k2a)')
% ylabel('ToECs')
%%
%Anisotropy
% figure(147)
% plot(log10(k2a),epsl009(1,:))
% hold on
% plot(log10(k2a),epsl009(4,:))
% hold on
% plot(log10(k2a),epsl009(8,:))
% hold on
% plot(log10(k2a),deltaVV009(1,:))
% hold on
% plot(log10(k2a),deltaVV009(4,:))
% hold on
% plot(log10(k2a),deltaVV009(8,:))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Anisotropy coefficient')
% figure(148)
% plot(log10(k2a),epsl015(1,:))
% hold on
% plot(log10(k2a),epsl015(4,:))
% hold on
% plot(log10(k2a),epsl015(8,:))
% hold on
% plot(log10(k2a),deltaVV015(1,:))
% hold on
% plot(log10(k2a),deltaVV015(4,:))
% hold on
% plot(log10(k2a),deltaVV015(8,:))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Anisotropy coefficient')
% figure(149)
% plot(log10(k2a),epsl100(1,:))
% hold on
% plot(log10(k2a),epsl100(4,:))
% hold on
% plot(log10(k2a),epsl100(8,:))
% hold on
% plot(log10(k2a),deltaVV100(1,:))
% hold on
% plot(log10(k2a),deltaVV100(4,:))
% hold on
% plot(log10(k2a),deltaVV100(8,:))
% legend('Low pressure','Middle pressure','High pressure')
% xlabel('log10(k2a)')
% ylabel('Anisotropy coefficient')
%close all
%%
% 
% figure(132)
% plot(log10(k2a),real(CCC22009M))
% hold on
% plot(log10(k2a),real(CCC22012M))
% hold on
% plot(log10(k2a),real(CCC22015M))
% hold on
% plot(log10(k2a),real(CCC22018M))
% legend('SSD = 09um','SSD = 12um','SSD = 15um','SSD = 18um')
% xlabel('log10(k2a)')
% ylabel('P-wave modulus (GPa)')
% %
% figure(133)
% plot(log10(k2a),log10(Q1C22009M))
% hold on
% plot(log10(k2a),log10(Q1C22012M))
% hold on
% plot(log10(k2a),log10(Q1C22015M))
% hold on
% plot(log10(k2a),log10(Q1C22018M))
% legend('SSD = 09um','SSD = 12um','SSD = 15um','SSD = 18um')
% xlabel('log10(k2a)')
% ylabel('Attenuation (Log)')
%%
%Plot the 3D variation of the 3oECs
figure(134)
mesh(SSD,PPD,TOELF)
hold on
mesh(SSD,PPD,TOEHF)
xlabel('SSD (um)')
ylabel('Pressure (MPa)')
zlabel('3oECs')
%legend('Low frequency','High frequency')
figure(135)
mesh(SSD,PPD,TOESLF)
hold on
mesh(SSD,PPD,TOESHF)
xlabel('SSD (um)')
ylabel('Pressure (MPa)')
zlabel('3oECs')
%legend('Low frequency','High frequency')
% hold on
% plot3(SD,LP,TOESLFLP)
% hold on
% plot3(SD,HP,TOESLFHP)