% Modified from Peter K. Kang's main_flow_transport_MC_final.m
% intended to do different realizations of fracture distributions
% by Joseph H.Y. Ma @ NUS, last updated: 16 August 2017

clear all; 
close all;
SCALE=1e-05;
diary('testflow_frac_fuboye_2019_stressinfl.txt')
tic;
%To record the simuluation diary
%%% Define Newtork Dimension and Heterogeniety

Nx = 128; Ny = 128;          % grid numbers ,
Lx = 100.*SCALE; Ly = 100.*SCALE;          % domain lengths m
Seed = [1]';
DX = Lx./Nx.*(1:Nx)./1e-06;
DY = Ly./Ny.*(1:Ny)./1e-06;
% clx_frac = [100 50 20]';%The autocorrelation length dimensionless value
clx_frac = [100]';%The autocorrelation length dimensionless value
% Var_S = [0.01 0.04 0.08]';%The perturbation
Var_S = [0.01]';%The perturbation
%The apt can be approximated by H=exp(-Var_S.^(1/2))  (-ln(H)).^2=Var_S
dist = 8;                                     % 1: Whitte-A,  2: Guassian, 3: Exponential 4 Gaussian 5 von Karman 6 Gaussian 7 exponential 8 Guassian 9 Von Kaman
distdis = 3;%2 log-normal distribution 3 power law distribution 4 exponential distribution 6 Test
RJJJ = 2;%2 Homogennous 1 heterogenenous
mss = 1;
SDS = 3;% 1 log-normal distribution, 2 power law distribution 3 exponential distribution
Nsqure = 10;%The square number of every tier
nsq = 5;%the tier number
b = 2.37;%The scale ratio
EEHH = 1.5*SCALE;
% EX = (-2:0.2:0);
VarH=0.01*SCALE;
kappa = 1/10;%The parameter used in von Karman correlation
Offset_ratio = [0 0.2 0.2 0.2 0.2 0.3 0.3 0.4 0.4 0.2 0.2]';    % no. of SD compression %The compression location dimensionless value
Pressure = 0;
VVA = 0;
for L = 1:length(Seed)
    run_count = 0;
    Displa = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The displacement of the flat surface
    Stressstore = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store stress
    PERMEAB = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store permeability
    APTMEAN = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store APTmean
    S2MEAN = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store mean value of S2
    FLOW = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store mean value of flow
    EMPTVOLUM = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space can store water
    HEIGHAVR = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The average apt
%     SURFAC = zeros(length(Offset_ratio),Ny);
%     SURFACNR = zeros(length(Offset_ratio),Ny);
%     SURFAC3D = zeros(Nx,Ny,length(Offset_ratio));
%     SURFACup = zeros(length(Offset_ratio),Ny);
%     SURFACup3D = zeros(Nx,Ny,length(Offset_ratio));
    DJD = zeros(length(Offset_ratio),1);
    DJDJ = zeros(length(Offset_ratio),1);
    seed = Seed(L);
    for I = 1:length(clx_frac)%We have confirm the autocorrelation length
    for J = 1:length(VarH)%confirm the perturbation
	S0 = zeros(Nx,Ny);
    Disp0 = 0;
       for K = 1:length(Offset_ratio)%Confirm the loction of compression
                Clx_frac = clx_frac(I)%The autocorrelation length
                CLx = Lx/Clx_frac; CLy = CLx;% autocorrelation length unit [m]
                var_S = Var_S%The perturbation
                offset_ratio = Offset_ratio(K);
                run_count = run_count + 1;%The time for iteration
        
%%% Define Flow & Transport Simulation Parameters 

mu  = 1e-03;                    % dynamic viscosity of water [Pa.s]
rho = 1000;                    % density of water [kg/m^3]
g = 9.8;                    % gravitatinoal constant [m/s^2] In this simulation, I think this value is useless
% P_L = 1e06;                    % pressure at the left boundary (Pa)
P_L = rho*g*Lx;                    % pressure at the left boundary (Pa)
P_R = 0;                    % pressure at the right boundary
h = Lx/(Nx-1);              % size of each gridblock [m]
fluxweighted = 1;           % 1 ???
INJ_section = 0;            % where we inject - 0: line injection / i: ith section
nomixing = 0;               % 0: complete mixing, 1: no mixing This is Kang's code
E=14e09;                    % The Young's modulus 
vvmu = 0.25;                %Poson's ratio
EH = EEHH(1);
varH = VarH(J);
% Generate Random Aperature from Permeability Field

[S2, sigma0, apt, sufa, sufanr, sufaup, PRE, Disp, str, DJDD, DJDDJ] = gen_aperture(K, dist, distdis, Nx, Ny, Lx, Ly, CLx, CLy, var_S, offset_ratio, kappa, EH, varH, seed, S0, Nsqure, nsq, b, E,vvmu, mss, Disp0, SDS, RJJJ, K, Pressure, VVA);
S0 = S2;
Disp0 = Disp;
apt_mean = mean(apt(:));%The mean aperture
apt_var = var(apt(:));%The variance of aperture
APTMEAN(I,J,K) = apt_mean;%This added by Bo-Ye Fu
S2MEAN(I,J,K) = mean(S2(:));%This is added by Bo-Ye Fu
QQ=apt.*h.^2;
EMPTVOLUM(I,J,K) = sum(QQ(:))./1e-18;
if K == 1
Displa(I,J,K)=Disp;%This is added by Bo-Ye Fu
else
    Displa(I,J,K)=Disp+Displa(I,J,K-1);%This is added by Bo-Ye Fu
end
perm = (1/12)*apt.^2;%                   % By kapa = d^2/12 in parallel plates%permeability of each node m^2
perm_var = var(perm(:));%The variance of permeability
if K ==1
Stressstore(I,J,K)=PRE./1e06;%To store the pressure
else
    Stressstore(I,J,K)=PRE./1e06+Stressstore(I,J,K-1);%To store the pressure
end
Pressure = Stressstore(I,J,K);
perm_nozero = perm;
perm_nozero(apt == 0) = NaN;            % neglet closed aperture in statistics
 
perm_geomean = geomean(perm(~isnan(perm_nozero))); % geometric mean of compressed permeability
logperm_var = nanvar(log(perm_nozero(:)));         % variance of log(compressed permeability)

if offset_ratio == 0
   apt0max = max(apt(:));
end

fig = figure('Visible','off');
imagesc(DX,DY,apt);
xlabel('Length (um)')
ylabel('Length (um)')
axis square; cob=colorbar; colormap('hot'); caxis([min(apt(:)) max(apt(:))]);set(get(cob,'title'),'string','m');
%title({'Aperature Field of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('Apt_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure,CLx*1e06, EH/1e-06, varH/1e-06));
close(fig);

fig = figure('Visible','off'); 
imagesc(DX,DY,log10(perm./1e-15)); 
xlabel('Length (um)')
ylabel('Length (um)')
axis square; cobb=colorbar; colormap('hot');set(get(cobb,'title'),'string','Log[mD]');%unit mD 
title({'log(Permeability) Field of Fracture Surfaces with',[' Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Perm_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure, CLx*1e06, EH/1e-06, varH/1e-06));
close(fig);

fig = figure('Visible','off'); 
imagesc(DX,DY,S2); 
xlabel('Length (um)')
ylabel('Length (um)')
axis square; cob=colorbar; colormap('hot'); caxis([min(S2(:)) max(S2(:))]);set(get(cob,'title'),'string','m');
%title({'Height of theb rough surface',['Autocorrelation length = ',num2str(Lx./Clx_frac.*1e06),'']});
saveas(fig, sprintf('Autocorrelationlength%d_L%d_Pressure%d_Exp%d_Var%d.png', Lx./Clx_frac.*1e06, Lx, Pressure, EH/1e-06, varH/1e-06));
close(fig);
%%
%Save the roughness surface
% SURFAC(K,:) = sufa(floor(Nx/2),:);
% SURFACNR(K,:) = sufanr(floor(Nx/2),:);
% SURFACup(K,:) = sufaup(floor(Nx/2),:);
% SURFAC3D(:,:,K) = sufa(:,:);
% SURFACup3D(:,:,K) = sufaup(:,:);
if K == 1
DJD(K) = 0;
DJDJ(K) = 0;
else
    if isempty(DJDD)==1
        DJD(K)=NaN;
    else
    DJD(K) = min(DJDD);
    end
    if isempty(DJDDJ)==1
        DJDJ(K) = NaN;
    else
    DJDJ(K) = DJDDJ;
    end
end
%%
% SOLVE FOR ELECTRIC (assume normalized potential difference)
%%
%This part can be comment
% K_electric = zeros(Ny,Nx);          % bulk resistivity = inf
% rho = 0.2;                          % brine resistivity = 0.2 ohm.m
% K_electric(apt(:) > 0) = 1/rho;     % formation factor = 1;
% V_L = 1; V_R = 0;                   % boundary electric potential
% 
% [Epmat, fx, fy, Jx, Jy] = flow_solver(Lx, Nx, Ny, K_electric);  % solve for current density J = -1/(F.rho)*grad V%Maybe I can neglect this
% 
% Ix = Jx.*apt.*h;      
% Iy = Jy.*apt.*h;                       % By I = JA
% 
% Itot = abs(Ix)+abs(Iy);
% Iout = sum(Ix(:,end));                 % total outgoing current
% Iout_var = var(Ix(:,end));             % variance of current
% Rsst_apparent = (V_L-V_R)/Iout;        % Resistance of network
% ele_apt = rho*Iout/((V_L-V_R)*Ly/Lx);  % electric aperture, from Brown 1989
% rho_eff = Rsst_apparent/Lx;            % Effective Resistivity
% 
% fname_electric = sprintf('electric_solution_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed);
% save(fname_electric, 'K_electric', 'Epmat', 'Ix', 'Iy', 'Itot', 'Rsst_apparent', 'ele_apt');
% 
% fig = figure('Visible','off'); 
% imagesc(Itot);
% axis square;  colorbar; 
% title({'Electric Current in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Itot_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
% 
% fig = figure('Visible','off'); 
% imagesc(K_electric);
% axis square;  colorbar; 
% title({'Electric Conductivity in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Ek_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
% 
% fig = figure('Visible','off'); 
% imagesc(Epmat);
% axis square;  colorbar; 
% title({'Electric Potential in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
% saveas(fig, sprintf('Epmat_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
% close(fig); 
%%
% SOLVE FOR FLOW

eff_poro = 1.00*ones(Ny,Nx); % fracture The porosity of crack is 100%                

[pmat, fx, fy, qx, qy] = flow_solver(Lx, Nx, Ny, perm.*rho.*g/mu);  % solve for Darcy velocity from q = -(k/mu)*grad P%In the flower_solver, K is the conductivity 
 
qtot = abs(qx)+abs(qy);                            % velocity magnitude [m/s]
Qout = sum(qx(:,end).*apt(:,end)*h);               % total out horizontal flux [m^3/s]
Qoutn = sum(sum(qx(:,:).*apt(:,:)*h))./Nx*(Nx-1);               % total out horizontal flux [m^3/s]
qout_var = var(qx(:,end));                         % variance of outgoing velocity
%Perm_apparent = mu*Qout/((P_L-P_R)/Lx);            % overall permeability of netwrok
%%
%This is added by Bo-Ye Fu
if Qout == 0 || isnan(Qout);
    Qout = 0;
end
%%
hyd_apt = (12*mu*Qout/(Ly*(P_L-P_R)/Lx))^(1/3)    % hydraulic aperture, from Brown 1989 [m]
hyd_aptn = (12*mu*Qoutn/(Ly*rho*g))^(1/3)    % hydraulic aperture, from Brown 1989 [m]
HEIGHAVR(I,J,K) = hyd_aptn;
%%
%This part added by Bo-Ye Fu
% if hyd_apt == 0 || isnan(hyd_apt);
%     hyd_apt = 0;
% end
%%
Perm_apparent = hyd_apt^2/12./1e-15                      % overall netwrok permeability, inverse of Darcy [m^2]/[mD]
Flow_avr = Qout./Ly;%This is added by Bo-Ye Fu
PERMEAB(I,J,K) = Perm_apparent;%This is added by Bo-Ye Fu
FLOW(I,J,K) = Flow_avr;%This is added by Bo-Ye Fu
%%  
fname_flow = sprintf('flow_solution_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Exp%d_Var%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed, EH/1e-06, varH/1e-06); 
save(fname_flow, 'perm', 'pmat', 'fx', 'fy', 'Qout','Perm_apparent','hyd_apt');

fig = figure('Visible','off'); 
imagesc(DX,DY,pmat);
xlabel('Length (um)')
ylabel('Length (um)')
%This is pressure gradient
axis square; colorbar;
%title({'Pressure Field in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Pmat_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure,CLx*1e06, EH/1e-06, varH/1e-06));
close(fig);

%%% Generate Total Outgoing Fluxes and Residence Time at Each Node %%%

Qtot = (abs(fx(:,1:end-1))+abs(fx(:,2:end))+abs(fy(1:end-1,:))+abs(fy(2:end,:)))/2;%This is an mean value

% residence_T = h^2*eff_poro./Qtot;%It is h^3/(Qtot.*h)unit s
residence_T = h*eff_poro./Qtot;%It is h^3/(Qtot.*h)unit s
residence_T(isnan(residence_T)) = 0;
residence_T(residence_T==inf) = 0;
Qtot_ud = flipud(Qtot);                           % flip if needed for consistency

fname_Qtot = sprintf('Qtot_residenceT_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Exp%d_Var%d.mat',Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed, EH/1e-06, varH/1e-06);
save(fname_Qtot, 'Qtot', 'eff_poro','residence_T');

fig = figure('Visible','off'); 
imagesc(DX,DY,residence_T); 
xlabel('Length (um)')
ylabel('Length (um)')
axis square;  colorbar; 
%title({'Residence Time of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('resT_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure, CLx, EH/1e-06, varH/1e-06));
close(fig);

fig = figure('Visible','off'); 
imagesc(DX,DY,Qtot); 
xlabel('Length (um)')
ylabel('Length (um)')
axis square;  colorbar; 
%title({'Total Fluxes in Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']}); 
saveas(fig, sprintf('Qtot_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure, CLx*1e06, EH/1e-06, varH/1e-06));
close(fig);

% SOLVE FOR TRANSPORT

try
   [node_xy, neighwithpositiveflux, PositiveFluxVector, link_Ttime, node_connectivity] = transport_param_gen(Nx, Ny, fname_flow, fname_Qtot);
   fname_TPparam = sprintf('transport_param_gen_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Exp%d_Var%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed, EH/1e-06, varH/1e-06);
   save(fname_TPparam, 'node_xy', 'Nx', 'Ny', 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime', 'node_connectivity');

   [TIME, NODEINDEX, BT_nodes] = Transport_cal(fluxweighted, INJ_section, nomixing, fname_TPparam, Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed);
   fname_TP = sprintf('Transport_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Exp%d_Var%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed, EH/1e-06, varH/1e-06);
   save(fname_TP, 'TIME', 'NODEINDEX', 'BT_nodes');

   [peak_time_modeling, q01, q05, q50, q80, q95, q99, tail_slope, Rsq] = transport_stat(fname_TP, Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist, seed, Pressure, hyd_aptn, EH, varH); 
   TPerror = 0;

catch exception
   disp(exception.getReport);
   TPerror = 1;
   q01 = NaN;
   q05 = NaN;
   q25 = NaN;
   q75 = NaN;
   q95 = NaN;
   q99 = NaN;
   tailslope = NaN;
   peak_time_modeling = NaN;
end
%%
%This part is used to calculate the influence of stress
%[mS2,nS2] = size(S2);% To obtain the line number and row number in S2;
% S2peak = sparse(mS2,nS2);% The space to store peak
%S2peak = zeros(mS2,nS2);% The space to store peak
%MMS2=mS2-1; NNS2=nS2-1;% In the S2peak, we use the medial MMS2 line and NNS2 line to store the results
%%

% for i=2:MMS2;
%     for j=2:NNS2;
%         if S2(i,j)>S2(i-1,j) &&  S2(i,j)>S2(i+1,j) && S2(i,j)>S2(i,j-1) && S2(i,j)>S2(i,j+1) && S2(i,j)>S2(i+1,j+1) && S2(i,j)>S2(i+1,j-1) && S2(i,j)>S2(i-1,j-1) && S2(i,j)>S2(i-1,j+1);
%             S2peak(i,j) = S2(i,j);
%         end
%     end
% end
% In this part, we have neglect the element in the boundary, we add it in
% this step is to input the element on the boundary
%%
%first, we calculate the four peaks in the boundary angle
% if S2(1,1)>S2(1,2) && S2(1,1)>S2(2,1) && S2(1,1)>S2(2,2);
%     S2peak(1,1) = S2(1,1);
% end
% if S2(1,nS2)>S2(1,nS2-1) && S2(1,nS2)>S2(2,nS2-1) && S2(1,nS2)>S2(1,nS2-1);
%     S2peak(1,nS2) = S2(1,nS2);
% end
% if S2(mS2,1)>S2(mS2,2) && S2(mS2,1)>S2(mS2-1,1) && S2(mS2,1)>S2(mS2-1,2);
%     S2peak(mS2,1)=S2(mS2,1);
% end
% if S2(mS2,nS2)>S2(mS2,nS2-1) && S2(mS2,nS2)>S2(mS2-1,nS2) && S2(mS2,nS2)>S2(mS2-1,nS2-1);
%     S2peak(mS2,nS2)=S2(mS2,nS2);
% end
%%
%Now, we think about the upper and lower boundry
% for i = 2:NNS2;
%     if S2(1,i)>S2(1,i+1) && S2(1,i)>S2(1,i-1) && S2(1,i)>S2(2,i) && S2(1,i)>S2(2,i+1) && S2(1,i)>S2(2,i-1);
%         S2peak(1,i)=S2(1,i);
%     end
%     if S2(mS2,i)>S2(mS2,i+1) && S2(mS2,i)>S2(mS2,i-1) && S2(mS2,i)>S2(mS2,i-1) && S2(mS2,i)>S2(mS2-1,i+1) && S2(mS2,i)>S2(mS2-1,i-1);
%         S2peak(mS2,i)=S2(mS2,i);
%     end
% end
%%
%Now, we think about the left and right boundry
% for j=2:MMS2;
%     if S2(j,1)>S2(j-1,1) && S2(j,1)>S2(j+1,1) && S2(j,1)>S2(j,2) && S2(j,1)>S2(j+1,2) && S2(j,1)>S2(j-1,2);
%     S2peak(j,1) = S2(j,1);
%     end
%     if S2(j,nS2)>S2(j-1,nS2) && S2(j,nS2)>S2(j+1,nS2) && S2(j,nS2)>S2(j,nS2-1) && S2(j,nS2)>S2(j+1,nS2-1) && S2(j,nS2)>S2(j-1,nS2-1);
%         S2peak(j,nS2)=S2(j,nS2);
%     end
% end
%%
% Now, we will peak up the peak higher than Offset_ratio
%The  ratio for the decrease of the surface in the upper sphere
% HHcut = sigma0.*offset_ratio;% 
% Highflatt = max(S2(:)) - offset_ratio*sigma0; % first contact at S2 maxima, and this is the location of the flat surface
% Highflat = max(0,Highflatt);
% % Now we calculate the contact peak of the roughness surface
% S2peakhH=zeros(mS2,nS2);%The space to store the peak compressed value, if the peak is higher than Highflatpeak 
% for i=1:mS2;
%     for j=1:nS2;
%      if S2peak(i,j)>=Highflat;
%          S2peakhH(i,j)=S2peak(i,j)-Highflat;
%      end
%     end
% end
% Stressone=4./3.*E.*ARR.^(-1/2).*S2peakhH.^(3/2);%The force loaded on each peak
% Pres=sum(Stressone(:))./Lx./Ly/1e06;%The pressure loaded on the crack unit [MPa]
% %Stressstore=zeros(length(clx_frac),length(Var_S),length(Offset_ratio))
% Stressstore(I,J,K)=Pres;%To store the pressure
%%
%This is about electricity, I think can be annotated
% Current(run_count)      = Iout;
% Current_Var(run_count)  = Iout_var;
% OverallResist(run_count)= Rsst_apparent;
% ElectricApt(run_count)  = ele_apt;
% OverallRho(run_count)   = rho_eff;
%%
CorrLen_frac(run_count) = Clx_frac;
VarS2(run_count)        = var_S;
Offset(run_count)       = offset_ratio;
Sigma0(run_count)       = sigma0;
Apt_mean(run_count)     = apt_mean;
Apt_Var(run_count)      = apt_var;
Flux(run_count)         = Qout;
Outvel_Var(run_count)   = qout_var;
Perm_Var(run_count)     = perm_var;
OverallPerm(run_count)  = Perm_apparent;
HydraulicApt(run_count) = hyd_apt;
Q01(run_count)		= q01;
Q05(run_count)          = q05;
Q50(run_count)          = q50;
Q80(run_count)          = q80;
Q95(run_count)          = q95;
Q99(run_count)		= q99;
TailSlope(run_count)	= tail_slope;
PeakBTtime(run_count)	= peak_time_modeling;
TransportErr(run_count) = TPerror;           
        end
    end
    end


%%
%This is about electricity, I think can be annotate
% Current = Current';
% Current_Var = Current_Var';
% OverallResist = OverallResist';
% OverallRho = OverallRho';
% ElectricApt = ElectricApt';
%%
CorrLen_frac = CorrLen_frac';
VarS2 = VarS2';
Offset = Offset';
Sigma0 = Sigma0';
Apt_mean = Apt_mean';
Apt_Var = Apt_Var';
Perm_Var = Perm_Var';
OverallPerm = OverallPerm';
Flux = Flux';
Outvel_Var = Outvel_Var';
HydraulicApt = HydraulicApt';
Q01 = Q01';
Q05 = Q05';
Q50 = Q50';
Q80 = Q80';
Q95 = Q95';
Q99 = Q99';
TailSlope = TailSlope';
PeakBTtime = PeakBTtime';
TransportErr = TransportErr';

fname = sprintf('paper2017_seed%d.mat',seed);
%%
%In this part, there are something about electricity, I will neglected
% save(fname,'VarS2','CorrLen_frac','Offset','Sigma0','Apt_mean','Apt_Var','Current','Current_Var','OverallResist','OverallRho','ElectricApt','Flux','Outvel_Var','Perm_Var','OverallPerm','HydraulicApt','TransportErr','Q01','Q05','Q50','Q80','Q95','Q99','TailSlope','PeakBTtime','str','seed');
%%
save(fname,'VarS2','CorrLen_frac','Offset','Sigma0','Apt_mean','Apt_Var','Flux','Outvel_Var','Perm_Var','OverallPerm','HydraulicApt','TransportErr','Q01','Q05','Q50','Q80','Q95','Q99','TailSlope','PeakBTtime','str','seed');
end
%%
%Also a part for stress influence
NP = length(Stressstore(1,1,:));%To obtain the scale of pressure
ND = length(Displa(1,1,:));%To obtain the scale of displacement
NPR = length(PERMEAB(1,1,:));%To obtain the scale of premeability
NFL = length(FLOW(1,1,:));%To obtain the scale of premeability
NEP = length(EMPTVOLUM(1,1,:));%To obtain the scale of empty space
NHA = length(HEIGHAVR(1,1,:));
Pressure = zeros(1,NP);
Displace = zeros(1,ND);
PERMEABLITY = zeros(1,NPR);
FLOWAVR = zeros(1,NFL);
EPTVO = zeros(1,NEP);
HEIGHMEA = zeros(1,NHA);
for i = 1:NP
Pressure(i) = Stressstore(1,1,i);%To store the pressure
Displace(i) = Displa(1,1,i);%To store the displacement
PERMEABLITY(i) = PERMEAB(1,1,i);
FLOWAVR(i) = FLOW(1,1,i);
EPTVO(i) = EMPTVOLUM(1,1,i);
HEIGHMEA(i) = HEIGHAVR(1,1,i);
end
%%
%Use some experiment data
%The left line is stress and the right line is flow
%The unit of pressure is MPa
DatE32 = load('E32.txt');
PREE32 = DatE32(:,1);
FLOWE32 = DatE32(:,2);
%%
DatE35 = load('E35.txt');
PREE35 = DatE35(:,1);
FLOWE35 = DatE35(:,2);
%%
DatS10 = load('S10.txt');
PRES10 = DatS10(:,1);
FLOWS10 = DatS10(:,2);
%%
DatSTR2 = load('STR2.txt');
PRESTR2 = DatSTR2(:,1);
FLOWSTR2 = DatSTR2(:,2);
%%
DatGran = load('Granite.txt');
PREGran = DatGran(:,1);
FLOWGran = DatGran(:,2);
%%
% figure(1)
% plot(Pressure,Displace/1e-06) 
% xlabel('Pressure (MPa)')
% ylabel('Displacement (um)')
%%
% figure(2)
% plot(Lx./clx_frac./1e-06,PERMEABLITY) 
% xlabel('Autocorrelation length (um) (exponential distribution)')
% ylabel('Permeability (mD)')
figure(2)
plot(Pressure,PERMEABLITY/1e03) 
xlabel('Pressure (MPa)')
ylabel('Permeability (D)')
figure(3)
plot(Pressure,FLOWAVR) 
hold on
plot(PREE32,FLOWE32)
hold on
plot(PREE35,FLOWE35)
hold on
plot(PRES10,FLOWS10)
hold on
plot(PRESTR2,FLOWSTR2)
hold on
plot(PREGran,FLOWGran)
xlabel('Pressure (MPa)')
ylabel('Flow (m^2/s)')
legend('Numerical solution','Sample E32','Sample E35','Sample S10','Sample STR2','Sample Granite')
%figure(4)
% for K = 1:length(Offset_ratio)
%     figure(3+K)
%     plot(DY,SURFAC(K,:)./1e-06)
% %     hold on
% %     plot(DY,SURFACup(K,:)./1e-06)
%     hold on
%     plot(DY,SURFACNR(K,:)./1e-06)
% %     hold on
%     legend('Real','Wrong')
%     xlabel('Length (um)')
%     ylabel('Height (um)')
%     figure(3+length(Offset_ratio)+K)
%     surf(DDX,DDY,SURFAC3D(:,:,K)./1e-06)
%     hold on
%     surf(DDX,DDY,SURFACup3D(:,:,K)./1e-06)
%     hold on
%     surf(DDX,DDY,S2./1e-06)
%     xlabel('Length (um)')
%     ylabel('Height (um)')
%     zlabel('Height (um)')
% end
% figure(5)
% plot(Lx./clx_frac./1e-06,EPTVO) 
% xlabel('Autocorrelation length (um)')
% ylabel('Empty volume (um^3)')
% figure(6)
% plot(Lx./clx_frac./1e-06,HEIGHMEA) 
% xlabel('Autocorrelation length (um)')
% ylabel('Average apt (um)')
diary off
toc;
