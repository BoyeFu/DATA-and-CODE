%%
% The code is used to model the surface
clear
%%
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
SCALE = 1e-06;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./Nx.*(1:Nx)./SCALE;
DY = Ly./Ny.*(1:Ny)./SCALE;
[DDX, DDY] = meshgrid(DX,DY);
%%
SURF009P00 = load('S2009.txt');
SURF009P00UP = max(max(SURF009P00)).*ones(Ny,Nx);
SURF009P89 = load('S2009P90.txt');
SURF009P89UP = max(max(SURF009P89)).*ones(Ny,Nx);
SURF018P00 = load('S2018.txt');
SURF018P00UP = max(max(SURF018P00)).*ones(Ny,Nx);
SURF018P89 = load('S2018P90.txt');
SURF018P89UP = max(max(SURF018P89)).*ones(Ny,Nx);
APTF009P00 = max(max(SURF009P00))-SURF009P00;
APTF009P89 = max(max(SURF009P89))-SURF009P89;
APTF018P00 = max(max(SURF018P00))-SURF018P00;
APTF018P89 = max(max(SURF018P89))-SURF018P89;
S009P00 = 0;
S018P00 = 0;
S009P89 = 0;
S018P89 = 0;
%%
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF009P00(I,J)) <= 0.1e-07
            S009P00 = S009P00+1;
        end
    end
end
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF018P00(I,J)) <= 0.1e-07
            S018P00 = S018P00+1;
        end
    end
end
%%
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF009P89(I,J)) <= 0.1e-07
            S009P89 = S009P89+1;
        end
    end
end
for I = 1:Ny
    for J = 1:Nx
        if abs(APTF018P89(I,J)) <= 0.1e-07
            S018P89 = S018P89+1;
        end
    end
end
%%
figure(1)
surf(DDX,DDY,SURF009P00./1e-06)
% hold on
% surf(DDX,DDY,SURF009P00UP./1e-06)
xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Height (um)')
figure(2)
imagesc(DX,DY,APTF009P00./1e-06);
xlabel('Length (um)')
ylabel('Length (um)')
axis square
figure(3)
surf(DDX,DDY,SURF018P00./1e-06)
% hold on
% surf(DDX,DDY,SURF018P00UP./1e-06)
xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Height (um)')
figure(4)
imagesc(DX,DY,APTF018P00./1e-06);
xlabel('Length (um)')
ylabel('Length (um)')
axis square
%%
figure(5)
surf(DDX,DDY,SURF009P89./1e-06)
% hold on
% surf(DDX,DDY,SURF009P89UP./1e-06)
xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Height (um)')
figure(6)
imagesc(DX,DY,APTF009P89./1e-06);
xlabel('Length (um)')
ylabel('Length (um)')
axis square
figure(7)
surf(DDX,DDY,SURF018P89./1e-06)
% hold on
% surf(DDX,DDY,SURF018P89UP./1e-06)
xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Height (um)')
figure(8)
imagesc(DX,DY,APTF018P89./1e-06);
xlabel('Length (um)')
ylabel('Length (um)')
axis square