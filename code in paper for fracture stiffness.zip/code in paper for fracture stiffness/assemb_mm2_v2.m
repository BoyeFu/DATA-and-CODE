function [Amat, bvec, Txmat, Tymat] = assemb_mm2_v2(Nx, Ny, Kx, Ky, h)
%General a transmissivity matrix
Lx = Kx.^(-1);%What is this???
Ly = Ky.^(-1);
tx = 2*h/h; 
ty = 2*h/h; 
%Transmissibility in x-direction: Nx+1 to give transmissibility at boundaries
Txmat = zeros(Ny,Nx+1); 
Tymat = zeros(Ny+1,Nx);

% Calculate transmissibilities at interfaces (general case- homo, hetero)
Tymat(2:Ny,:) = ty./(Ly(1:Ny-1,:)+Ly(2:Ny,:)); % Take harmonic mean -- No flow boundary condition: 0 for 1 and Nx+1 -> therefore 2:Nx
Txmat(:,2:Nx) = tx./(Lx(:,1:Nx-1)+Lx(:,2:Nx)); % Take harmonic mean-- No flow boundary condition: 0 for 1 and Nx+1 -> therefore 2:Nx
%In the first two line, we don't consider the boundary condition
%Tymat(2:Ny,:) = tx./(L(2,1:Ny-1,:)+L(2,2:Ny,:)); % Take harmonic mean -- No flow boundary condition: 0 for 1 and Nx+1 -> therefore 2:Nx
%Txmat(:,2:Nx) = ty./(L(1,:,1:Nx-1)+L(1,:,2:Nx)); % Take harmonic mean

% Impose B.C at X edges.
Txmat(:,1) = tx./(Lx(:,1)+Lx(:,1)); 
Txmat(:,Nx+1) = tx./(Lx(:,Nx)+Lx(:,Nx));
%Txmat(:,1) = 2*tx./(L(1,:,1)+L(1,:,1)); 
%Txmat(:,Nx+1) = 2*tx./(L(1,:,Nx)+L(1,:,Nx));
% Txmat(:,1)  = 0; 
% Txmat(:,Nx+1)= 0;

% Impose no flow B.C at Y edges.
% Tymat(1,:) = ty./(Ly(1,:)+Ly(1,:)); 
% Tymat(Ny+1,:)= ty./(Ly(Ny,:)+Ly(Ny,:));
Tymat(1,:) = 0; 
Tymat(Ny+1,:) = 0;

% Off-diagonal vectors of the system
% by reshaping transmissibility matrices
Txvec1 = reshape(Txmat(:,1:Nx), Nx*Ny, 1);%The element of the first Nx row in Txmat, there is a boundary value in the first Ny element/This is also to transform the matrix Txmat to a column vector
Tyvec1 = reshape(Tymat(1:Ny,:), Nx*Ny, 1);%The element of the first Ny line in Tymat, there is a boundary value in the first Nx element/This is also to transform the matrix Tymat to a column vector
Txvec2 = reshape(Txmat(:,2:Nx+1), Nx*Ny, 1);%The element of the last Nx row in Txmat, there is a boundary value in the last Ny element/This is also to transform the matrix Txmat to a column vector
Tyvec2 = reshape(Tymat(2:Ny+1,:), Nx*Ny, 1);%The element of the last Ny line in Tymat, there is a boundary value in the last Nx element/This is also to transform the matrix Tymat to a column vector
Txvec11 = Txvec1;
Txvec11(1:Ny) = 0;
Tyvec11 = Tyvec1;
Tyvec11(1:Ny:Ny*(Nx-1)+1)=0;
% Matrix of the system
Amat = spdiags([-Txvec1,-Tyvec1,Txvec1+Tyvec1+Txvec2+Tyvec2,-Tyvec2,-Txvec2],[Ny,1,0,-1,-Ny],Nx*Ny,Nx*Ny);%The first row is the the element of the Nyth  diag of Amat, the second row is the first diag of Amat
%The third row is the zeroth diag element of Amt, the fourth row is the negative first diag of Amat, the fifth row is the negative Nyth diag of Amat
%Amat(1,1) = Txvec2(1)+Tyvec2(1);

% RHS vector with injection at (0,0)
bvec = zeros(Nx*Ny,1); %The boundary condition
% bvec(1) = 1;
bvec(1:Ny) = Txmat(:,1)*1; % Constant pressure boundary condition on left (1) and right edge (0)%The
%     bvec(1:Ny:Ny*(Nx-1)+1) = Tyvec1(1:Ny:Ny*(Nx-1)+1) + bvec(1:Ny:Ny*(Nx-1)+1);
end