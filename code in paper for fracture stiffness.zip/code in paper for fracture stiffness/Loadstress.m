% Modified from oseph H.Y. Ma's testflow_frac_2017paper.m
% intended to do calculate the stress loaded on the sample
% by Boye Fu @ NUS, last updated: 19 December 2019
%%
clear all;
close all;

diary('Loadstress.txt')
tic;
%To record the simuluation diary, and caculate the simulation time
%%% Define Newtork Dimension and Heterogeniety
%In this code, all the parameters should be same as the parameters in the
%code testflow_frac_2017paper.m
Nx = 128; Ny = 128;          % grid numbers 
Lx = 100; Ly = 100;          % domain lengths m
ARR=0.01;%We assume the radius of curvature is a constant for all peak
Seed = [1]';
clx_frac = [100 50 20]';%The autocorrelation length dimensionless value
Var_S = [0.1 0.4 0.8]';%The perturbation
%The apt can be approximated by H=exp(-Var_S.^(1/2))  (-ln(H)).^2=Var_S
dist = 4;                                     % 1: Whitte-A,  2: Guassian, 3: Exponential
Offset_ratio = [0 0.5 1.5 2]';    % no. of SD compression %The compression location dimensionless value
Displa=zeros(length(clx_frac),length(Var_S),length(Offset_ratio));%The displacement of the flat surface
Stressstore=zeros(length(clx_frac),length(Var_S),length(Offset_ratio));%The space to store stress
for L = 1:length(Seed)
    run_count = 0;
    seed = Seed(L);
    for I = 1:length(clx_frac)%We have confirm the autocorrelation length
    for J = 1:length(Var_S)%confirm the perturbation
    for K = 1:length(Offset_ratio)%Confirm the loction of compression
                 Clx_frac = clx_frac(I);%The autocorrelation length
                 CLx = Lx/Clx_frac; CLy = CLx;% autocorrelation length unit [m]
                 var_S = Var_S(J);%The perturbation
                 run_count = run_count + 1;%The time for iteration
%%% Define Flow & Transport Simulation Parameters 

mu  = 1e-03;                    % dynamic viscosity of water [Pa.s]
rho = 1000;                    % density of water [kg/m^3]
g = 9.8;                    % gravitatinoal constant [m/s^2] In this simulation, I think this value is useless
P_L = 1e06;                    % pressure at the left boundary (Pa)
P_R = 0;                    % pressure at the right boundary
h = Lx/(Nx-1);              % size of each gridblock [m]
fluxweighted = 1;           % 1 ???
INJ_section = 0;            % where we inject - 0: line injection / i: ith section
nomixing = 0;               % 0: complete mixing, 1: no mixing This is Kang's code
E=14e09;                    % The Young's modulus 
% Generate Random Aperature from Permeability Field
offset_ratio = Offset_ratio(K);
[S2, sigma0, apt, str] = gen_aperture(dist, Nx, Ny, Lx, Ly, CLx, CLy, var_S, offset_ratio, seed);
% The S2 is the highth value of the surface
% first, I should pick up the peak in S2
[mS2,nS2] = size(S2);% To obtain the line number and row number in S2;
% S2peak = sparse(mS2,nS2);% The space to store peak
S2peak = zeros(mS2,nS2);% The space to store peak
MMS2=mS2-1; NNS2=nS2-1;% In the S2peak, we use the medial MMS2 line and NNS2 line to store the results
%%

for i=2:MMS2;
    for j=2:NNS2;
        if S2(i,j)>S2(i-1,j) &&  S2(i,j)>S2(i+1,j) && S2(i,j)>S2(i,j-1) && S2(i,j)>S2(i,j+1) && S2(i,j)>S2(i+1,j+1) && S2(i,j)>S2(i+1,j-1) && S2(i,j)>S2(i-1,j-1) && S2(i,j)>S2(i-1,j+1);
            S2peak(i,j) = S2(i,j);
        end
    end
end
% In this part, we have neglect the element in the boundary, we add it in
% this step is to input the element on the boundary
%%
%first, we calculate the four peaks in the boundary angle
if S2(1,1)>S2(1,2) && S2(1,1)>S(2,1) && S2(1,1)>S2(2,2);
    S2peak(1,1) = S2(1,1);
end
if S2(1,nS2)>S2(1,nS2-1) && S2(1,nS2)>S2(2,nS2-1) && S2(1,nS2)>S2(1,nS2-1);
    S2peak(1,nS2) = S2(1,nS2);
end
if S2(mS2,1)>S2(mS2,2) && S2(mS2,1)>S2(mS2-1,1) && S2(mS2,1)>S2(mS2-1,2);
    S2peak(mS2,1)=S2(mS2,1);
end
if S2(mS2,nS2)>S2(mS2,nS2-1) && S2(mS2,nS2)>S2(mS2-1,nS2) && S2(mS2,nS2)>S2(mS2-1,nS2-1);
    S2peak(mS2,nS2)=S2(mS2,nS2);
end
%%
%Now, we think about the upper and lower boundry
for i = 2:NNS2;
    if S2(1,i)>S2(1,i+1) && S2(1,i)>S2(1,i-1) && S2(1,i)>S2(2,i) && S2(1,i)>S2(2,i+1) && S2(1,i)>S2(2,i-1);
        S2peak(1,i)=S2(1,i);
    end
    if S2(mS2,i)>S2(mS2,i+1) && S2(mS2,i)>S2(mS2,i-1) && S2(mS2,i)>S2(mS2,i-1) && S2(mS2,i)>S2(mS2-1,i+1) && S2(mS2,i)>S2(mS2-1,i-1);
        S2peak(mS2,i)=S2(mS2,i);
    end
end
%%
%Now, we think about the left and right boundry
for j=2:MMS2;
    if S2(j,1)>S2(j-1,1) && S2(j,1)>S2(j+1,1) && S2(j,1)>S2(j,2) && S2(j,1)>S2(j+1,2) && S2(j,1)>S2(j-1,2);
    S2peak(j,1) = S2(j,1);
    end
    if S2(j,nS2)>S2(j-1,nS2) && S2(j,nS2)>S2(j+1,nS2) && S2(j,nS2)>S2(j,nS2-1) && S2(j,nS2)>S2(j+1,nS2-1) && S2(j,nS2)>S2(j-1,nS2-1);
        S2peak(j,nS2)=S2(j,nS2);
    end
end
%%
% Now, we will peak up the peak higher than Offset_ratio
%The  ratio for the decrease of the surface in the upper sphere
HHcut = sigma0.*offset_ratio;% 
Highflat = max(S2(:)) - offset_ratio*sigma0; % first contact at S2 maxima, and this is the location of the flat surface
if Highflat <=0;
    Highflat=0;
end
% Now we calculate the contact peak of the roughness surface
S2peakhH=zeros(mS2,nS2);%The space to store the peak compressed value, if the peak is higher than Highflatpeak 
for i=1:mS2;
    for j=1:nS2;
     if S2peak(i,j)>=Highflat;
         S2peakhH(i,j)=S2peak(i,j)-Highflat;
     end
    end
end
%%
%We calculate the apt distribution
if offset_ratio == 0
   apt0max = max(apt(:));
end
fig = figure('Visible','off');
imagesc(apt);
axis square; cob=colorbar; colormap('hot'); caxis([0 apt0max]);set(get(cob,'title'),'string','m');
title({'Aperature Field of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('Apt_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
close(fig);
%%
%Calculate the stress at each node
Stressone=4./3.*E.*ARR.^(-1/2).*S2peakhH.^(3/2);%The force loaded on each peak
Pres=sum(Stressone(:))./Lx./Ly/1e06;%The pressure loaded on the crack unit [MPa]
%Stressstore=zeros(length(clx_frac),length(Var_S),length(Offset_ratio))
Stressstore(I,J,K)=Pres;%To store the pressure
Displa(I,J,K)=HHcut;
    end
    end
    end
end
NP=length(Stressstore(1,1,:));%To obtain the scale of pressure
ND=length(Displa(1,1,:));%To obtain the scale of displacement
Pressure=zeros(1,NP);
Displace=zeros(1,ND);
for i=1:NP
Pressure(i)=Stressstore(1,end,i);%To store the pressure
Displace(i)=Displa(1,end,i);%To store the displacement
end
plot(Pressure,Displace)        