%%
clear all
%This function is to claculate the stress and displacement
S2 = load('S2.txt');
Lx = 100*1e-05;
Ly = 100*1e-05;
E = 14e9;
vvmu = 0.25;
offset_ratio = 0.6;
sigma0 = mean(S2(:));
SS2 = S2;
D0 = max(SS2(:));
[NX,NY] = size(SS2);
Disflat = offset_ratio*D0;%The displacement of 

Heighflat = D0 - Disflat;
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
sufanr = zeros(NX,NY);
%%
while 1
SSTOR = zeros(NX*NY,3);%To store the peak higher than flat
SSTORL = zeros(NX*NY,3);%To store the peak lower than the flat
sufa = zeros(NX,NY);
w = 1;
DH = Lx./NX;
for I = 1:NX;
    for J = 1:NY;
    if SS2(I,J) >= Heighflat;  
        SSTOR(w,1) = I;
        SSTOR(w,2) = J;
        SSTOR(w,3) = SS2(I,J);
        w = w+1;
    end
    end
end
%%
w = 1;
for I = 1:NX;
    for J = 1:NY;
    if SS2(I,J) < Heighflat;  
        SSTORL(w,1) = I;
        SSTORL(w,2) = J;
        SSTORL(w,3) = SS2(I,J);
        w = w+1;
    end
    end
end
%%
if max(SSTOR) == 0
    apt = max(0, S1-S2); 
    PRE = 0;
    Disp = 0;
    return
else 
    NSS = sum(sum(SSTOR(:,1)~=0));
end
SNOD = zeros(NSS,3);
w = 1;
for K = 1:NX*NY;
    if SSTOR(K,1)>0;
        SNOD(w,:) = SSTOR(K,:);
        w = w+1;
    end
end
SSW = zeros(NSS,NSS);
for i = 1:NSS;
    SSW(i,i) = 32.*(1-vvmu.^2)./pi.^2./E./(DH./2)./3+SNOD(i,3)./E./pi./(DH./2).^2;
end
for i = 1:NSS;
    for j = 1:NSS;
        if i~=j
            RR = sqrt((SNOD(i,1)-SNOD(j,1)).^2+(SNOD(i,2)-SNOD(j,2)).^2).*DH;
            SSW(i,j) = 2.*(1-vvmu.^2)./pi./E./RR;
        end
    end
end
LL = SNOD(:,3)-Heighflat;
F = SSW\LL;
PRE = sum(F)./Lx./Ly;
DLC = F.*SNOD(:,3)./(E.*pi.*(DH./2).^2);
%%
%added by Bo-Ye Fu
%DLC = min(SNOD(:,3), DLC);
%%
DLCC = DLC+D0-SNOD(:,3);
%%
%This part is also added by Bo-Ye Fu which should be delete
% for I = 1:length(DLCC)
% DLCC(I) = min(D0, DLCC(I));
% end
%%
%
SOLC = [SNOD,F];
%%
%To store the non-zero value in SSTORL
 NSSL = sum(sum(SSTORL(:,1)~=0));
 SNODL = zeros(NSSL,3);
w = 1;
for K = 1:NX*NY;
    if SSTORL(K,1)>0;
        SNODL(w,:) = SSTORL(K,:);
        w = w+1;
    end
end
%%
%To calculate the displacement for the piont did not contact
DLCL = zeros(NSSL,1);
WW = zeros(NSSL,1);
%WW = zeros(NSSL,1);
for i = 1:NSSL;
    R = sqrt((SOLC(:,1)-SNODL(i,1)).^2+(SOLC(:,2)-SNODL(i,2)).^2).*DH;
    W = F.*2.*(1-vvmu.^2)./pi./E./R;
    WW(i) = sum(W);
    DLCL(i) = D0 - Heighflat + WW(i);
    %%
    %This part is added by Bo-Ye Fu, which should be delete
%     if D0 - DLCL(i) < SNODL(i,3)
%         DLCL(i) = D0 - SNODL(i,3);
%     end
    %%
end
DJDD = D0 - DLCL -SNODL(:,3);
DJDDJ = min(DJDD);
% if abs(min(DJDD))>=0
%%
%%
%This should also be deleted 
if isempty(DJDD)==1;
break
end
%%
% if (min(DJDD(:)))>=0
% if (min(DJDD(:)))>=0 || abs(min(DJDD(:)))<=0.01*D0
DNME = sum(sum(DJDD<0));
DNMEDJ = max(size(DJDD));
if DNME/DNMEDJ<=0.01
    break
elseif DJDDJ>=0 || abs(DJDDJ)<=1e-06
%%
%This is wrong, should be deleted
% if  abs(min(DJDD))>=0
%%
    break
end
Heighflat = Heighflat + 0.1*abs(min(DJDD));
while (Heighflat <= min(S2(:)))
    Heighflat = Heighflat + 0.1*abs(min(DJDD));
end
end
%%
%This part is added by Bo-Ye Fu, which should be deleted
% DLCL = min(D0, DLCL);
% DLCL = max(max(DLCC), DLCL);
%%
%%
%DLNCC = sparse(SNODL(:,1),SNODL(:,2),DLCL,NX,NY);
WAPT1 = sparse(SNODL(:,1),SNODL(:,2),DLCL,NX,NY);
WAPT2 = sparse(SNOD(:,1),SNOD(:,2),DLCC,NX,NY);
WAPT3 = WAPT1 + WAPT2;
%WAPT = sparse(SNODL(:,1),SNODL(:,2),WW,NX,NY);
%DISCP =
for i = 1:NX;
for j = 1:NY;
if  D0 - WAPT3(i,j) >= S2(i,j) && WAPT3(i,j) >= (D0-Heighflat);
sufa(i,j) = S2(i,j) + WAPT3(i,j)-(D0-Heighflat);
else
sufa(i,j) = Heighflat;
end
end
end
%%
%for sufanr
for i = 1:NX;
for j = 1:NY;
if  Heighflat >= S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j) = Heighflat;
end
end
end
%%
%Disp = Disflat-(sum(DLCL(:))+sum(DLC(:)))./NX./NY;
if Disflat>=D0;
Disp = Disp0;
else
Disp = (sum(DLCL(:))+sum(DLCC(:)))./NX./NY;
end
%if Disp>=D0;
    %Disp = Disp0;
%end
%if Disp<Disp0;
 %   Disp = Disp0;
%end
apt = max(0, D0-WAPT3-S2);
sufaup = Heighflat.*ones(NX,NY);
figure(1)
surf(sufa./1e-06)
hold on
surf(sufaup./1e-06)
xlabel('Length (um)')
ylabel('Height (um)')
zlabel('Height (um)')
sufadd=sufa(50,:);
sufadn=sufanr(50,:);
figure(2)
plot(sufadd./1e-06)
%     hold on
%     plot(DY,SURFACup(K,:)./1e-06)
hold on
plot(sufadn./1e-06)
%     hold on
legend('Real','Wrong')
xlabel('Length (um)')
ylabel('Height (um)')